FINAL EML FILES - MASKED
Folder structure mirrors "Mails from Athira"
=============================================================================

WHAT CHANGED
-----------------------------------------------------------------------------
The 35 masked .eml files used to sit flat in this folder. They are now filed
into the same folder tree as the original .msg files in "Mails from Athira",
so the two folders can be opened side by side and compared folder for folder.

All 30 folders from "Mails from Athira" exist here, with identical names -
including the ones that ended up empty. Nothing in "Mails from Athira" was
touched.

The files themselves were NOT modified by this step: same names, same bytes
(verified by MD5 before and after the move). Only their location changed.


HOW TO READ IT
-----------------------------------------------------------------------------
Open "VD 09 June" in both folders:

    Mails from Athira\VD 09 June\      Final EML Files - MASKED\VD 09 June\
      NFPSJPJTXXX NOMAGB2LXXX...msg      EML-0004.eml
      RE CGML - NOMURA - 9-Jun...msg     EML-0009.eml
      RE NFPSJPJTXXX NOMAGB2L...msg      EML-0014.eml

Which masked file corresponds to which original .msg is in EML_Masking_Legend.xlsx
(one level up, in the "eml" folder). The "Legend" sheet gives the pairing plus
the evidence behind it; the "Masked file path" column matches this new layout.


WHERE EVERYTHING SITS
-----------------------------------------------------------------------------
FOLDER            MASKED FILES
VD 02 Jul         EML-0015
VD 04 June        EML-0011, EML-0018, EML-0019
VD 05 June        EML-0010
VD 07 May(1)      EML-0026, EML-0027
VD 08 May         EML-0029
VD 09 Jul         EML-0017, EML-0028, EML-0035
VD 09 June        EML-0004, EML-0009, EML-0014
VD 10 Jul         EML-0032
VD 10 Jun         EML-0023
VD 11 Jun         EML-0022
VD 11 May         EML-0020, EML-0021
VD 13 May         EML-0001, EML-0003, EML-0006
VD 14 Jul         EML-0002
VD 15 Jul         EML-0033
VD 16 Jun         EML-0005, EML-0016, EML-0025, EML-0031
VD 19 Jul         EML-0013
VD 22 Apr         EML-0007
VD 24 Jul         EML-0024
VD 26 Jun         EML-0008, EML-0034
VD 30 June        EML-0030
(this folder)     EML-0012


TWO THINGS WORTH KNOWING
-----------------------------------------------------------------------------
1. EML-0012 sits at the top level, not in a VD folder. Its original,
   "RE High ValuePre-Confirmation  VD 23rd June 26Nomura.msg", also sits at the
   top level of "Mails from Athira" - there is no "VD 23 Jun" folder to put it
   in. Same placement here, so the mirror holds.

2. EML-0015 is filed under "VD 02 Jul". Its original exists TWICE in
   "Mails from Athira" - once at the top level and once in "VD 02 Jul" - and the
   two copies are byte-identical (md5 fbaa0086adf91dfba8d388cae13c5e97). Rather
   than duplicate the masked file, it is filed once, under the value-date folder.


EMPTY FOLDERS
-----------------------------------------------------------------------------
These 10 folders exist in "Mails from Athira" but have no masked counterpart.
They are kept empty so the two trees line up exactly - an empty folder here
means "these originals were not carried into the masked set":

    Matched Cashflows   (empty in "Mails from Athira" too)
    VD 03 Jul           Natixis EQD, amounts to confirm value 03/07/2026
    VD 08 Oct 25        NBC payment notice, Oct-08-2025 EUR
    VD 09 Jan           Schonfeld DMFI, settlement 09 Jan 26
    VD 12 Jun           (empty in "Mails from Athira" too)
    VD 15 May           Kommunalkredit Austria, IRS payment val. 15.05.26
    VD 17 Jul           Natixis equity-swap TRS advice, VD 17/07/2026
    VD 23 Jul           Shinhan Securities, VAL 23-Jul-26
    VD 28 Jul           HedgeServ / Kepos, settlement confirmation 07/28
    VD 30 Jul           NBC payment notice, Jul-30-2026

Five further originals have no masked counterpart but sit in folders that do
hold masked files, so those folders are not empty. The full list of 15 unmapped
originals is on the "Unmapped Originals" sheet of EML_Masking_Legend.xlsx.


ALSO IN THIS FOLDER
-----------------------------------------------------------------------------
_VERIFY_masking.html   The masking tool's own verification output. Left exactly
                       as produced, at the top level. Note it still refers to
                       2027 dates, whereas the .eml files were rolled back to
                       2026 on 4 Sep 2026.


BACKUP
-----------------------------------------------------------------------------
"Final EML Files - MASKED_backup_2027" alongside this folder holds the 35 files
as they were before the 2027 -> 2026 year change, flat and unstructured.
Safe to delete once you are happy with the current set.

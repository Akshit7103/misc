# Masked OTC settlement mail corpus

51 `.eml` messages, de-identified from a real inbound settlement mailbox.
Folder layout, message structure, table shapes and attachment types are unchanged;
every identity has been replaced with a stable synthetic alias.

## Alias conventions

Same conventions as the existing `Master Emails` corpus, so the two sets can be used together.

| Real-world thing | Alias |
|---|---|
| The subject firm (our side) | `BANK` — e.g. `BANK INTERNATIONAL PLC`, `BANK GLOBAL FINANCIAL PRODUCTS INC` |
| Subject-firm mailbox | `bank@settlements.com`, other roles `<role>@settlements.com` |
| Subject-firm BIC / entity codes | `BANKGB2L`, `BANKGBLON`, `BNKSJPJT`, `BNKG`, `BNKS`, `BNKP` … |
| External counterparties | `Counterparty1` … `Counterparty30` |
| Counterparty domains | `<word>.cp<N>.example` (e.g. `wexolt.cp7.example`) |
| Counterparty BICs | `CPTY<N>` padded to the original length (e.g. `CPTY24XXXXX`) |
| Correspondent / agent banks | `AGENT BANK <n>`, BICs `AG<letter>B……` (e.g. `AGABUS3N`) |
| People | Synthetic first/last names, consistent everywhere they appear |
| Person mailboxes | `first.last@<counterparty domain>` |
| Issuers / underlyings | `ISSUER ALPHA`, `ISSUER BRAVO`, … |
| Funds / books / house codes | Neutral codes (`HK-FUND1-2L`, `CPNA497`, `FUND-MASTER-0001-…`) |
| Offices / buildings / streets | `1 Example Street`, `Example Tower`, postcode `XX0 0XX` |

Aliases are deterministic: the same real entity always maps to the same alias, in every
message, header, spreadsheet cell and PDF.

## What was masked

- Sender/recipient names, display names, e-mail addresses and domains, including
  URL-encoded and whitespace-broken forms inside quoted replies and `mailto:` links
- Company names in every spelling seen, including abbreviations, spelling variants
  and forms glued to neighbouring words
- Signature blocks, job titles and escalation contact lists — including people who
  appear **only** in a signature or legal footer (name+phone lines, name+role lines,
  the line after "Regards,", and comma-separated board / management lists, with
  accented and middle-initial forms handled)
- BICs/SWIFT codes (curated plus a generic rule for unlisted ones), IBANs — unbroken
  or in four-character groups, including any bank code embedded in them — account
  numbers, sort/ABA/routing codes
- Phone, fax and mobile numbers
- Postal addresses in several languages, postcodes, office/building/campus names,
  and company registration numbers
- URLs (replaced with `https://example.com/disclaimer`)
- Full `Received` chains, `DKIM-Signature`, `Authentication-Results`, all `X-*`
  routing headers, internal hostnames, IPs and Message-IDs — replaced with a
  synthetic but structurally realistic 2-hop chain
- CJK names and Chinese/Japanese bank and department names
- Attachment **contents**: spreadsheet cells and sheet names, PDF text, embedded
  images, attachment filenames, document metadata (OOXML `dc:creator` /
  `cp:lastModifiedBy` / `Company`, OLE summary streams, PDF `/Info`), and binary
  package parts such as `printerSettings*.bin` (kept but zeroed so relationships
  stay valid)

## What was deliberately preserved

- **Trade amounts, cash-flow values and reference numbers** — unchanged
- **Value dates, trade dates and payment dates** — unchanged, including compact
  forms such as `17082026` and `20260818`
- Message structure: MIME tree, plain-text *and* HTML alternatives, inline `cid:`
  images, attachment count and file types
- Table layouts, column headers, SWIFT MT-style blocks, quote depth in forwarded
  chains, the external-sender banner markers, and the original language
  (EN / 中文 / 日本語)

## The legend (re-identification key)

`..\New folder (2)\MASKING-LEGEND.xlsx` maps every alias back to the original.
Sheets: Messages (one row per email: original → masked filename, subject and sender),
Attachments, Organisations, People, Email addresses, BICs and codes, Numbers.

**Keep it separate from this folder.** Whoever holds both can undo the masking.

## Known limitations

1. **Inline images are placeholders.** All 29 embedded images (logos, signature
   graphics, and a few screenshots of cash-flow tables) are replaced by grey
   placeholder PNGs of the original pixel dimensions. Figures that existed only
   inside an image are gone.
2. **Two scanned PDFs are placeholders.** The two image-only PDFs had no extractable
   text layer, so they could not be re-masked and were replaced with a one-page
   notice. All other PDFs were re-rendered from their masked text.
3. **One password-protected workbook was replaced.** `encrypted_…xlsx` could not be
   opened, so a small synthetic workbook stands in — it is no longer encrypted.
4. **The legacy `.xls` was patched in place.** Sensitive strings were overwritten
   with equal-length aliases, so a few masked strings are truncated (e.g. a mailbox
   reads `CouASDCRU@…`). The file still opens and parses correctly.
5. Re-rendered PDFs keep the text and reading order of the originals but not their
   original layout, fonts or logos.

## Verification performed on the final build

- **Leakage:** 1,335 known real literals searched across headers, plain text, HTML,
  PDF text, spreadsheet XML and raw `.xls` bytes — **0 hits**; five independent regex
  sweeps (firm name, real TLDs, URL-defense wrappers, DKIM remnants, internal
  hostnames) — **0 hits**
- **Raw bytes:** every attachment blob scanned in latin-1 and utf-16-le — **0 hits**
- **Structure:** 51/51 paired via an explicit mapping, **0** part-count mismatches,
  all 53 attachments re-open with their parsers
- **Fidelity:** **0/51** messages lost an amount or a date — in bodies, attachments,
  subjects or filenames
- **Consistency:** no alias collisions; byte-identical output across repeated runs
- **Definitive probe:** all 822 real values listed in the legend searched as whole
  strings across every surface of the masked corpus — **none present**

﻿import os
from pathlib import Path
from typing import Literal

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field


BASE_DIR = Path(__file__).resolve().parent
GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODELS_URL = "https://api.groq.com/openai/v1/models"
DEFAULT_MODEL = "llama-3.1-8b-instant"
CHAT_MODEL_OPTIONS = [
    {
        "id": "llama-3.1-8b-instant",
        "label": "Llama 3.1 8B Instant",
    },
    {
        "id": "llama-3.3-70b-versatile",
        "label": "Llama 3.3 70B Versatile",
    },
    {
        "id": "openai/gpt-oss-20b",
        "label": "GPT OSS 20B",
    },
    {
        "id": "openai/gpt-oss-120b",
        "label": "GPT OSS 120B",
    },
    {
        "id": "qwen/qwen3-32b",
        "label": "Qwen3 32B",
    },
    {
        "id": "qwen/qwen3.6-27b",
        "label": "Qwen3.6 27B",
    },
    {
        "id": "meta-llama/llama-4-scout-17b-16e-instruct",
        "label": "Llama 4 Scout 17B",
    },
]

app = FastAPI(title="Groq Chatbot")


def load_env_files() -> None:
    for filename in (".env", ".env.local"):
        env_path = BASE_DIR / filename
        if not env_path.exists():
            continue

        for line in env_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue

            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if value in {"", "your_groq_api_key_here"}:
                continue
            os.environ.setdefault(key, value)


load_env_files()


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=20000)


class ChatRequest(BaseModel):
    model: str = Field(default=DEFAULT_MODEL, min_length=1, max_length=120)
    messages: list[ChatMessage] = Field(min_length=1, max_length=60)
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_completion_tokens: int = Field(default=1024, ge=1, le=8192)


class ChatResponse(BaseModel):
    message: str


class ModelOption(BaseModel):
    id: str
    label: str
    default: bool = False


def model_options_for_ids(model_ids: set[str] | None = None) -> list[ModelOption]:
    options = []
    for model in CHAT_MODEL_OPTIONS:
        if model_ids is not None and model["id"] not in model_ids:
            continue

        options.append(
            ModelOption(
                id=model["id"],
                label=model["label"],
                default=model["id"] == DEFAULT_MODEL,
            )
        )

    return options or model_options_for_ids()


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(BASE_DIR / "index.html")


@app.get("/styles.css")
async def styles() -> FileResponse:
    return FileResponse(BASE_DIR / "styles.css")


@app.get("/script.js")
async def script() -> FileResponse:
    return FileResponse(BASE_DIR / "script.js")


@app.get("/api/models", response_model=list[ModelOption])
async def models() -> list[ModelOption]:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        return model_options_for_ids()

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(GROQ_MODELS_URL, headers=headers)
            response.raise_for_status()
    except httpx.HTTPError:
        return model_options_for_ids()

    data = response.json()
    available_ids = {
        item.get("id")
        for item in data.get("data", [])
        if isinstance(item, dict) and item.get("id")
    }

    return model_options_for_ids(available_ids)


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="GROQ_API_KEY is not set on the server.",
        )

    payload = {
        "model": request.model,
        "messages": [message.dict() for message in request.messages],
        "temperature": request.temperature,
        "max_completion_tokens": request.max_completion_tokens,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=45) as client:
            response = await client.post(GROQ_CHAT_URL, headers=headers, json=payload)
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=502,
            detail="Could not connect to Groq.",
        ) from exc

    data = response.json()
    if response.status_code >= 400:
        detail = data.get("error", {}).get("message", "Groq request failed.")
        raise HTTPException(status_code=response.status_code, detail=detail)

    content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
    content = content.strip()
    if not content:
        raise HTTPException(status_code=502, detail="Groq returned an empty response.")

    return ChatResponse(message=content)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)


const CHAT_URL = "/api/chat";
const MODELS_URL = "/api/models";
const SETTINGS_KEY = "groq-chat-settings";

const elements = {
  model: document.querySelector("#model"),
  systemPrompt: document.querySelector("#systemPrompt"),
  messages: document.querySelector("#messages"),
  statusText: document.querySelector("#statusText"),
  chatForm: document.querySelector("#chatForm"),
  messageInput: document.querySelector("#messageInput"),
  sendButton: document.querySelector("#sendButton"),
  clearChat: document.querySelector("#clearChat"),
  newChat: document.querySelector("#newChat"),
  copyLast: document.querySelector("#copyLast"),
};

let messages = [];
let isSending = false;

const defaultSettings = {
  model: "llama-3.1-8b-instant",
  systemPrompt: "You are a helpful, concise assistant.",
};

const fallbackModels = [
  { id: "llama-3.1-8b-instant", label: "Llama 3.1 8B Instant", default: true },
  { id: "llama-3.3-70b-versatile", label: "Llama 3.3 70B Versatile" },
  { id: "openai/gpt-oss-20b", label: "GPT OSS 20B" },
  { id: "openai/gpt-oss-120b", label: "GPT OSS 120B" },
  { id: "qwen/qwen3-32b", label: "Qwen3 32B" },
  { id: "qwen/qwen3.6-27b", label: "Qwen3.6 27B" },
  {
    id: "meta-llama/llama-4-scout-17b-16e-instruct",
    label: "Llama 4 Scout 17B",
  },
];

let currentSettings = { ...defaultSettings };

function loadSettings() {
  let savedSettings = {};
  try {
    savedSettings = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
  } catch {
    savedSettings = {};
  }

  currentSettings = { ...defaultSettings, ...savedSettings };
  elements.systemPrompt.value = currentSettings.systemPrompt;
}

function saveSettings() {
  currentSettings = {
    model: elements.model.value || defaultSettings.model,
    systemPrompt: elements.systemPrompt.value.trim() || defaultSettings.systemPrompt,
  };

  localStorage.setItem(
    SETTINGS_KEY,
    JSON.stringify(currentSettings)
  );
}

function setModelOptions(models) {
  const selectedModel = currentSettings.model || defaultSettings.model;
  const modelIds = new Set(models.map((model) => model.id));
  const fallbackDefault =
    models.find((model) => model.default)?.id || models[0]?.id || defaultSettings.model;

  elements.model.innerHTML = "";

  models.forEach((model) => {
    const option = document.createElement("option");
    option.value = model.id;
    option.textContent = model.label || model.id;
    elements.model.append(option);
  });

  elements.model.value = modelIds.has(selectedModel) ? selectedModel : fallbackDefault;
  saveSettings();
}

async function loadModels() {
  setStatus("Loading models");

  try {
    const response = await fetch(MODELS_URL);
    const data = await response.json().catch(() => []);

    if (!response.ok || !Array.isArray(data) || data.length === 0) {
      throw new Error("Model list unavailable.");
    }

    setModelOptions(data);
    setStatus("Ready");
  } catch {
    setModelOptions(fallbackModels);
    setStatus("Ready");
  }
}

function setStatus(text) {
  elements.statusText.textContent = text;
}

function setSending(nextValue) {
  isSending = nextValue;
  elements.sendButton.disabled = nextValue;
  elements.messageInput.disabled = nextValue;
  elements.sendButton.textContent = nextValue ? "Wait" : "Send";
}

function createMessageElement(message) {
  const item = document.createElement("article");
  item.className = `message ${message.role}${message.error ? " error" : ""}`;

  const role = document.createElement("div");
  role.className = "message-role";
  role.textContent = message.role === "user" ? "You" : "Assistant";

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";
  bubble.textContent = message.content;

  item.append(role, bubble);
  return item;
}

function renderMessages() {
  elements.messages.innerHTML = "";

  if (!messages.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "Start a conversation";
    elements.messages.append(empty);
    return;
  }

  messages.forEach((message) => {
    elements.messages.append(createMessageElement(message));
  });

  elements.messages.scrollTop = elements.messages.scrollHeight;
}

function buildGroqMessages() {
  const systemPrompt = elements.systemPrompt.value.trim();
  const payloadMessages = [];

  if (systemPrompt) {
    payloadMessages.push({ role: "system", content: systemPrompt });
  }

  messages
    .filter((message) => !message.error && !message.pending)
    .forEach((message) => {
      payloadMessages.push({
        role: message.role,
        content: message.content,
      });
    });

  return payloadMessages;
}

async function askGroq() {
  const model = elements.model.value || defaultSettings.model;

  let response;
  try {
    response = await fetch(CHAT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: buildGroqMessages(),
        temperature: 0.7,
        max_completion_tokens: 1024,
      }),
    });
  } catch {
    throw new Error(
      "Could not reach the FastAPI server. Make sure it is running."
    );
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message = data?.detail || `Request failed with status ${response.status}.`;
    throw new Error(message);
  }

  const content = data?.message?.trim();
  if (!content) {
    throw new Error("The server returned an empty response.");
  }

  return content;
}

async function handleSubmit(event) {
  event.preventDefault();

  const text = elements.messageInput.value.trim();
  if (!text || isSending) return;

  saveSettings();
  messages.push({ role: "user", content: text });
  elements.messageInput.value = "";
  renderMessages();

  const loadingMessage = {
    role: "assistant",
    content: "Thinking...",
    pending: true,
  };
  messages.push(loadingMessage);
  renderMessages();

  setSending(true);
  setStatus("Sending to Groq");

  try {
    loadingMessage.content = await askGroq();
    loadingMessage.pending = false;
    setStatus("Ready");
  } catch (error) {
    loadingMessage.content = error.message;
    loadingMessage.pending = false;
    loadingMessage.error = true;
    setStatus("Error");
  } finally {
    setSending(false);
    saveSettings();
    renderMessages();
    elements.messageInput.focus();
  }
}

function clearConversation() {
  messages = [];
  setStatus("Ready");
  renderMessages();
  elements.messageInput.focus();
}

async function copyLastAssistantMessage() {
  const lastAssistant = [...messages]
    .reverse()
    .find((message) => message.role === "assistant" && !message.error);

  if (!lastAssistant) {
    setStatus("Nothing to copy");
    return;
  }

  try {
    await navigator.clipboard.writeText(lastAssistant.content);
    setStatus("Copied");
  } catch {
    setStatus("Copy blocked");
  }
}

elements.chatForm.addEventListener("submit", handleSubmit);
elements.clearChat.addEventListener("click", clearConversation);
elements.newChat.addEventListener("click", clearConversation);
elements.copyLast.addEventListener("click", copyLastAssistantMessage);

elements.messageInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    elements.chatForm.requestSubmit();
  }
});

["change", "input"].forEach((eventName) => {
  elements.model.addEventListener(eventName, saveSettings);
  elements.systemPrompt.addEventListener(eventName, saveSettings);
});

loadSettings();
loadModels();
renderMessages();

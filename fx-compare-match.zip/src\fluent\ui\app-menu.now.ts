import { ApplicationMenu, Record } from '@servicenow/sdk/core'

/**
 * Navigator menu for the app — gives a clean left-nav ("FX Compare & Match")
 * with links to the pipeline tables and the configuration tables, so the app
 * is demoable without hunting through the All menu.
 * (Now.ID keys must be static literals, so each module is written explicitly.)
 */
// Coloured navigator section for the app (subtle navy accent).
const fxcmCategory = Record({
    $id: Now.ID['fxcm-category'],
    table: 'sys_app_category',
    data: { name: 'FX Compare & Match', style: 'border-color:#C8102E; background-color:#fdeef0;' },
})

const menu = ApplicationMenu({
    $id: Now.ID['fxcm-menu'],
    title: 'FX Compare & Match',
    hint: 'FX/OTC settlement triage, extraction and reconciliation',
    description: 'Triage settlement emails, extract trades, and reconcile against the golden source.',
    category: fxcmCategory,
    roles: ['admin'],
    active: true,
})

// -- FX Console (Service Portal app — opens in a new tab) --
Record({ $id: Now.ID['mod-portal'], table: 'sys_app_module', data: { title: 'Open FX Console', application: menu, link_type: 'DIRECT', query: '/fxcm?id=fxcm-console', window_name: '_blank', roles: ['admin'], active: true, order: 40 } })

// -- Overview (landing page) --
Record({ $id: Now.ID['mod-overview'], table: 'sys_app_module', data: { title: 'Overview', application: menu, link_type: 'DIRECT', query: 'x_2112826_fxcm_overview.do', roles: ['admin'], active: true, order: 50 } })

// -- Pipeline --
Record({ $id: Now.ID['mod-cases'], table: 'sys_app_module', data: { title: 'FX Cases', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_case', roles: ['admin'], active: true, order: 100 } })
Record({ $id: Now.ID['mod-trades'], table: 'sys_app_module', data: { title: 'FX Trades', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_trade', roles: ['admin'], active: true, order: 200 } })
Record({ $id: Now.ID['mod-matches'], table: 'sys_app_module', data: { title: 'Match Results', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_match_result', roles: ['admin'], active: true, order: 300 } })
Record({ $id: Now.ID['mod-golden'], table: 'sys_app_module', data: { title: 'Golden Trades', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_golden_trade', roles: ['admin'], active: true, order: 400 } })

// -- Configuration --
Record({ $id: Now.ID['sep-config'], table: 'sys_app_module', data: { title: 'Configuration', application: menu, link_type: 'SEPARATOR', roles: ['admin'], active: true, order: 500 } })
Record({ $id: Now.ID['mod-keywords'], table: 'sys_app_module', data: { title: 'Classifier Keywords', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_keyword', roles: ['admin'], active: true, order: 600 } })
Record({ $id: Now.ID['mod-patterns'], table: 'sys_app_module', data: { title: 'Trade ID Patterns', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_trade_id_pattern', roles: ['admin'], active: true, order: 700 } })
Record({ $id: Now.ID['mod-settings'], table: 'sys_app_module', data: { title: 'FX Settings', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_settings', roles: ['admin'], active: true, order: 800 } })

// -- Audit --
Record({ $id: Now.ID['sep-audit'], table: 'sys_app_module', data: { title: 'Audit', application: menu, link_type: 'SEPARATOR', roles: ['admin'], active: true, order: 900 } })
Record({ $id: Now.ID['mod-audit'], table: 'sys_app_module', data: { title: 'Audit Events', application: menu, link_type: 'LIST', name: 'x_2112826_fxcm_audit_event', roles: ['admin'], active: true, order: 1000 } })

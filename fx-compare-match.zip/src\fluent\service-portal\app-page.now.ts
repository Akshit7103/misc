import { SPPage } from '@servicenow/sdk/core'
import { consoleWidget } from './console-widget.now'

/**
 * The single application page — one full-width container holding the console
 * widget. Page CSS strips Service Portal's default padding so the widget fills
 * the viewport like the original SPA.
 */
export const appPage = SPPage({
    pageId: 'fxcm-console',
    title: 'FX Compare & Match',
    css: `
        html, body { margin: 0 !important; padding: 0 !important; height: 100%; overflow: hidden !important; }
        #sp-page-root, .sp-page-root, main { padding: 0 !important; margin: 0 !important; height: 100%; }
        .container-fluid, .container { padding: 0 !important; margin: 0 !important; max-width: 100% !important; width: 100% !important; }
        .row, .sp-row { margin: 0 !important; }
        [class^="col-"], [class*=" col-"] { padding: 0 !important; }
        sp-notifications, sn-banner { display: none !important; }
    `,
    containers: [
        {
            $id: Now.ID['fxcm_app_container'],
            name: 'App',
            width: 'container-fluid',
            order: 1,
            rows: [
                {
                    $id: Now.ID['fxcm_app_row'],
                    order: 1,
                    columns: [
                        {
                            $id: Now.ID['fxcm_app_col'],
                            size: 12,
                            order: 1,
                            instances: [
                                {
                                    $id: Now.ID['fxcm_app_instance'],
                                    widget: consoleWidget,
                                    order: 1,
                                },
                            ],
                        },
                    ],
                },
            ],
        },
    ],
})

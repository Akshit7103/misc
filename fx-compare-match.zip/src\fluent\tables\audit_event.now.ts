import {
    Table,
    StringColumn,
    ChoiceColumn,
    DateTimeColumn,
} from '@servicenow/sdk/core'

/**
 * Audit Event — append-only compliance log, one row per business action.
 * Replaces utils/audit.py. (ACLs in the security phase make it create+read
 * only — no update/delete — for WORM-style integrity.)
 */
export const x_2112826_fxcm_audit_event = Table({
    name: 'x_2112826_fxcm_audit_event',
    label: 'Audit Event',
    display: 'action',
    schema: {
        action: StringColumn({ label: 'Action', maxLength: 100 }),
        outcome: ChoiceColumn({
            label: 'Outcome',
            choices: { success: 'Success', failure: 'Failure', skipped: 'Skipped' },
        }),
        actor: StringColumn({ label: 'Actor', maxLength: 100 }),
        resource: StringColumn({ label: 'Resource', maxLength: 100 }),
        correlation_id: StringColumn({ label: 'Correlation ID', maxLength: 40 }),
        details: StringColumn({ label: 'Details', maxLength: 4000 }),
        event_time: DateTimeColumn({ label: 'Event Time' }),
    },
})

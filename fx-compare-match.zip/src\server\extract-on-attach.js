/**
 * Business Rule (after insert) on sys_attachment.
 * When a blotter (or any file) is attached to an FX Case, re-run extraction so
 * attachments added during/after case creation are parsed into FX Trade rows.
 * Filtered to our case table; the extractor itself ignores unsupported files.
 * Classic server script — `current` and the scope namespace are global.
 */
(function executeRule(current, previous /*null when async*/) {
    if (current.getValue('table_name') !== 'x_2112826_fxcm_case') return;
    var caseId = current.getValue('table_sys_id');
    new x_2112826_fxcm.TradeExtractor().extractForCase(caseId);
    var n = new GlideAggregate('x_2112826_fxcm_trade');
    n.addQuery('case', caseId);
    n.addAggregate('COUNT');
    n.query();
    var cnt = n.next() ? parseInt(n.getAggregate('COUNT'), 10) : 0;
    new x_2112826_fxcm.AuditService().log('trades.extracted', {
        resource: current.getValue('file_name'),
        correlation_id: caseId,
        details: cnt + ' trade(s) extracted from attachment ' + current.getValue('file_name')
    });
})(current, previous);

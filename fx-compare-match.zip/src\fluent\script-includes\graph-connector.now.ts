import { ScriptInclude } from '@servicenow/sdk/core'

/** GraphConnector — pull Microsoft Graph inbox mail into the pipeline (delegated OAuth). */
ScriptInclude({
    $id: Now.ID['si-graph-connector'],
    name: 'GraphConnector',
    active: true,
    apiName: 'x_2112826_fxcm.GraphConnector',
    description: 'Sync Microsoft Graph inbox messages into FX Cases (raw MIME -> EmlParser -> pipeline).',
    script: Now.include('../../server/GraphConnector.server.js'),
})

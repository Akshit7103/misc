import { Record } from '@servicenow/sdk/core'

/**
 * Seed configuration — mirrors EmailAgentConfig from the agentic-workflows app.
 * Installs the asset/subject/negative keyword lists, the trade-id regex
 * patterns, and a single default settings record. Editable at runtime; these
 * are the defaults the classifier reads on each run.
 */

const KW = 'x_2112826_fxcm_keyword'
const PAT = 'x_2112826_fxcm_trade_id_pattern'

// -- Asset keywords (specific FX-settlement phrases; +asset_weight) --
Record({ $id: Now.ID['kw-a-1'], table: KW, data: { value: 'fx trade settlement', type: 'asset' } })
Record({ $id: Now.ID['kw-a-2'], table: KW, data: { value: 'fx settlement', type: 'asset' } })
Record({ $id: Now.ID['kw-a-3'], table: KW, data: { value: 'settlement instructions', type: 'asset' } })
Record({ $id: Now.ID['kw-a-4'], table: KW, data: { value: 'deal reference', type: 'asset' } })
Record({ $id: Now.ID['kw-a-5'], table: KW, data: { value: 'fx trade', type: 'asset' } })
Record({ $id: Now.ID['kw-a-6'], table: KW, data: { value: 'currency pair', type: 'asset' } })

// -- Subject keywords (matched in subject; +subject_weight) --
Record({ $id: Now.ID['kw-s-1'], table: KW, data: { value: 'settlement', type: 'subject' } })
Record({ $id: Now.ID['kw-s-2'], table: KW, data: { value: 'confirm', type: 'subject' } })
Record({ $id: Now.ID['kw-s-3'], table: KW, data: { value: 'trade', type: 'subject' } })
Record({ $id: Now.ID['kw-s-4'], table: KW, data: { value: 'swift', type: 'subject' } })
Record({ $id: Now.ID['kw-s-5'], table: KW, data: { value: 'counterparty', type: 'subject' } })
Record({ $id: Now.ID['kw-s-6'], table: KW, data: { value: 'value date', type: 'subject' } })
Record({ $id: Now.ID['kw-s-7'], table: KW, data: { value: 'transaction', type: 'subject' } })
Record({ $id: Now.ID['kw-s-8'], table: KW, data: { value: 'allege', type: 'subject' } })
Record({ $id: Now.ID['kw-s-9'], table: KW, data: { value: 'dk', type: 'subject' } })
Record({ $id: Now.ID['kw-s-10'], table: KW, data: { value: 'fx', type: 'subject' } })

// -- Negative keywords (hard-negative early exit when no asset keyword) --
Record({ $id: Now.ID['kw-n-1'], table: KW, data: { value: 'happy birthday', type: 'negative' } })
Record({ $id: Now.ID['kw-n-2'], table: KW, data: { value: 'birthday', type: 'negative' } })
Record({ $id: Now.ID['kw-n-3'], table: KW, data: { value: 'anniversary', type: 'negative' } })
Record({ $id: Now.ID['kw-n-4'], table: KW, data: { value: 'congratulations', type: 'negative' } })
Record({ $id: Now.ID['kw-n-5'], table: KW, data: { value: 'congrats', type: 'negative' } })
Record({ $id: Now.ID['kw-n-6'], table: KW, data: { value: 'it support', type: 'negative' } })
Record({ $id: Now.ID['kw-n-7'], table: KW, data: { value: 'ticket', type: 'negative' } })
Record({ $id: Now.ID['kw-n-8'], table: KW, data: { value: 'password', type: 'negative' } })
Record({ $id: Now.ID['kw-n-9'], table: KW, data: { value: 'vpn', type: 'negative' } })
Record({ $id: Now.ID['kw-n-10'], table: KW, data: { value: 'policy', type: 'negative' } })
Record({ $id: Now.ID['kw-n-11'], table: KW, data: { value: 'remote work', type: 'negative' } })
Record({ $id: Now.ID['kw-n-12'], table: KW, data: { value: 'newsletter', type: 'negative' } })
Record({ $id: Now.ID['kw-n-13'], table: KW, data: { value: 'monthly update', type: 'negative' } })
Record({ $id: Now.ID['kw-n-14'], table: KW, data: { value: 'out of office', type: 'negative' } })
Record({ $id: Now.ID['kw-n-15'], table: KW, data: { value: 'team sync', type: 'negative' } })
Record({ $id: Now.ID['kw-n-16'], table: KW, data: { value: 'lunch', type: 'negative' } })
Record({ $id: Now.ID['kw-n-17'], table: KW, data: { value: 'calendar invite', type: 'negative' } })

// -- Trade-ID regex patterns (tried in order; primary = ground-truth format) --
Record({ $id: Now.ID['pat-1'], table: PAT, data: { pattern: 'FXOPT-\\d{4}-\\d{5}', order: 1 } })
Record({ $id: Now.ID['pat-2'], table: PAT, data: { pattern: '[A-Z]{2,5}-\\d{4}-\\d{4,6}', order: 2 } })
Record({ $id: Now.ID['pat-3'], table: PAT, data: { pattern: '\\b[A-Z]{2,4}\\d{6,12}\\b', order: 3 } })

// -- Single default settings record (weights / thresholds / match tuning) --
export const fxcmSettings = Record({
    $id: Now.ID['settings-default'],
    table: 'x_2112826_fxcm_settings',
    data: {
        asset_weight: 0.5,
        subject_weight: 0.3,
        trade_id_weight: 0.2,
        relevant_threshold: 0.7,
        ambiguous_threshold: 0.3,
        default_asset_class: 'FX Settlement',
        max_body_scan_chars: 2000,
        sync_frequency_hours: 24,
        match_numeric_tolerance: 0.01,
        match_break_threshold: 0.6,
        match_enrich_enabled: true,
        match_fields: 'currency_pair,buy_sell,notional_amount,counterparty,settlement_date,strike_rate',
    },
})

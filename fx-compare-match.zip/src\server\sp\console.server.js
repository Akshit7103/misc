/**
 * FX Compare & Match Console — Service Portal widget server script.
 * Reads the pipeline tables (case / trade / match_result / settings / keyword)
 * and returns a single payload the AngularJS controller renders across the
 * Sync / Classify / Extract / Recon steps plus the Schedules & Settings views.
 * Mirrors the agentic-workflows FastAPI responses, sourced from ServiceNow.
 */
(function () {
    var T_CASE = 'x_2112826_fxcm_case';
    var T_TRADE = 'x_2112826_fxcm_trade';
    var T_MATCH = 'x_2112826_fxcm_match_result';
    var T_SET = 'x_2112826_fxcm_settings';
    var T_KW = 'x_2112826_fxcm_keyword';
    var T_AUDIT = 'x_2112826_fxcm_audit_event';

    function count(table, field, value) {
        var ga = new GlideAggregate(table);
        if (field) ga.addQuery(field, value);
        ga.addAggregate('COUNT');
        ga.query();
        return ga.next() ? parseInt(ga.getAggregate('COUNT'), 10) : 0;
    }

    function fmtNum(v) {
        if (v === null || v === undefined || v === '') return '';
        var n = parseFloat(v);
        if (isNaN(n)) return '' + v;
        var parts = n.toFixed(2).split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return parts[1] === '00' ? parts[0] : parts.join('.');
    }

    function confClass(pct) {
        return pct >= 70 ? 'hi' : (pct >= 30 ? 'mid' : 'lo');
    }

    // Format a stored UTC datetime as IST (UTC+5:30) wall-clock. The display TZ
    // otherwise follows the PDI default (US Pacific), which inverts the times.
    function fmtIST(rawUtc) {
        if (!rawUtc) return '';
        try {
            var g = new GlideDateTime('' + rawUtc);
            g.add(19800000); // +5h30m
            return g.getValue();
        } catch (e) { return '' + rawUtc; }
    }

    /* ---- inbound actions (HITL approve / decline) ---- */
    if (input && input.action === 'review' && input.sys_id) {
        var cr = new GlideRecord(T_CASE);
        if (cr.get(input.sys_id)) {
            cr.setValue('review_decision', input.decision === 'approve' ? 'approve' : 'decline');
            if (input.decision === 'approve') cr.setValue('classification_label', 'RELEVANT');
            cr.setValue('reviewed_at', new GlideDateTime());
            cr.update();
            new x_2112826_fxcm.AuditService().log('case.reviewed', {
                resource: cr.getValue('trade_id') || cr.getValue('subject'),
                correlation_id: input.sys_id,
                details: 'Human review: ' + (input.decision === 'approve' ? 'APPROVED as Relevant' : 'DECLINED')
            });
        }
    }

    /* ---- ingest an uploaded .eml (Option A) — parse → case → pipeline fires ---- */
    if (input && input.action === 'ingest_eml' && input.content) {
        try {
            var parsed = new x_2112826_fxcm.EmlParser().parse(input.content);
            var nc = new GlideRecord(T_CASE);
            nc.initialize();
            nc.setValue('subject', parsed.subject || input.filename || 'Untitled');
            nc.setValue('sender', parsed.sender || '');
            nc.setValue('body', parsed.body || '');
            if (parsed.date) nc.setValue('received_at', parsed.date);
            nc.setValue('source', 'local');
            var newId = nc.insert();
            var nAtt = 0;
            if (newId && parsed.attachments && parsed.attachments.length) {
                var caseGr = new GlideRecord(T_CASE);
                if (caseGr.get(newId)) {
                    var sa = new GlideSysAttachment();
                    for (var ai = 0; ai < parsed.attachments.length; ai++) {
                        var at = parsed.attachments[ai];
                        var ctype = at.contentType || 'application/octet-stream';
                        var fn = at.filename || ('attachment-' + (ai + 1));
                        if (at.base64) { sa.writeBase64(caseGr, fn, ctype, at.base64); nAtt++; }
                        else if (at.text) { sa.write(caseGr, fn, ctype, at.text); nAtt++; }
                    }
                    if (nAtt) { caseGr.setValue('attachment_count', nAtt); caseGr.update(); }
                }
            }
            new x_2112826_fxcm.AuditService().log('email.ingested', {
                resource: parsed.subject || input.filename || '',
                correlation_id: newId,
                details: 'Imported "' + (input.filename || '') + '" — ' + nAtt + ' attachment(s)'
            });
            data.ingest = { ok: true, subject: parsed.subject || input.filename || '', attachments: nAtt };
        } catch (e) {
            gs.error('FXCM eml ingest error: ' + e);
            data.ingest = { ok: false, error: '' + e };
        }
    }

    /* ---- delete all emails (and cascade trades + matches) ---- */
    if (input && input.action === 'delete_all') {
        var dm = new GlideRecord(T_MATCH); dm.deleteMultiple();
        var dt2 = new GlideRecord(T_TRADE); dt2.deleteMultiple();
        var dc = new GlideRecord(T_CASE); dc.deleteMultiple();
        data.deleted = true;
        new x_2112826_fxcm.AuditService().log('data.purged', { resource: 'all', details: 'Deleted all emails, trades and reconciliations' });
    }

    /* ---- re-run reconciliation for every trade against the current golden ---- */
    if (input && input.action === 'rematch') {
        var cm = new x_2112826_fxcm.CompareMatcher();
        var tg = new GlideRecord(T_TRADE);
        tg.query();
        var rcnt = 0;
        while (tg.next()) { cm.matchByTradeSysId(tg.getUniqueValue()); rcnt++; }
        data.rematched = true;
        new x_2112826_fxcm.AuditService().log('recon.rerun', { details: 'Reconciliation re-run across ' + rcnt + ' trade(s)' });
    }

    /* ---- on-demand Graph mailbox sync — fire a background event. A Service
           Portal widget runs interactively and scoped apps can't do synchronous
           outbound HTTP here, so the actual pull runs in the Script Action that
           handles this event (same background context as the daily job). ---- */
    if (input && input.action === 'sync_mailbox') {
        try {
            gs.eventQueue('x_2112826_fxcm.graph_sync', null, gs.getUserID(), 'console');
            data.sync_queued = true;
            new x_2112826_fxcm.AuditService().log('mailbox.sync_requested', { resource: 'Microsoft Graph inbox', details: 'On-demand sync queued from the console' });
        } catch (e) {
            data.sync_error = '' + e;
        }
    }

    /* ---- save classifier/match settings ---- */
    if (input && input.action === 'save_settings' && input.cfg) {
        var ss = new GlideRecord(T_SET);
        ss.orderByDesc('sys_created_on');
        ss.setLimit(1);
        ss.query();
        if (ss.next()) {
            var cf = input.cfg;
            function setIf(field, v) { if (v !== undefined && v !== null && ('' + v) !== '') ss.setValue(field, v); }
            setIf('asset_weight', cf.asset_weight);
            setIf('subject_weight', cf.subject_weight);
            setIf('trade_id_weight', cf.trade_id_weight);
            setIf('relevant_threshold', cf.relevant_threshold);
            setIf('ambiguous_threshold', cf.ambiguous_threshold);
            setIf('match_numeric_tolerance', cf.tolerance);
            setIf('match_break_threshold', cf.break_threshold);
            if (cf.match_fields !== undefined) ss.setValue('match_fields', cf.match_fields);
            ss.update();
        }
    }

    /* ---- add a classifier keyword ---- */
    if (input && input.action === 'add_keyword' && input.kw_value && input.kw_type) {
        var kv = ('' + input.kw_value).trim().toLowerCase();
        if (kv) {
            var dup = new GlideRecord(T_KW);
            dup.addQuery('type', input.kw_type);
            dup.addQuery('value', kv);
            dup.setLimit(1);
            dup.query();
            if (!dup.next()) {
                var nk = new GlideRecord(T_KW);
                nk.initialize();
                nk.setValue('value', kv);
                nk.setValue('type', input.kw_type);
                nk.insert();
            }
        }
    }

    /* ---- delete a classifier keyword ---- */
    if (input && input.action === 'del_keyword' && input.sys_id) {
        var dkw = new GlideRecord(T_KW);
        if (dkw.get(input.sys_id)) dkw.deleteRecord();
    }

    /* ---- drawer detail (classify / extract / recon) — lightweight on-demand ---- */
    if (input && input.action === 'detail' && input.sys_id && input.kind) {
        var LBL = {
            trade_id: 'Trade ID', uti: 'UTI', trade_date: 'Trade Date', counterparty: 'Counterparty',
            counterparty_code: 'Counterparty Code', currency_pair: 'Currency Pair', base_currency: 'Base Ccy',
            quote_currency: 'Quote Ccy', option_type: 'Option Type', exercise_style: 'Exercise Style',
            buy_sell: 'Buy / Sell', notional_amount: 'Notional Amount', notional_currency: 'Notional Ccy',
            strike_rate: 'Strike Rate', expiry_date: 'Expiry Date', settlement_date: 'Settlement Date',
            premium_amount: 'Premium', premium_currency: 'Premium Ccy', premium_settle_date: 'Premium Settle',
            delta: 'Delta', implied_vol: 'Implied Vol', settlement_status: 'Sett. Status',
            portfolio: 'Portfolio', trader: 'Trader', book: 'Book'
        };
        var DATEF = { trade_date: 1, expiry_date: 1, settlement_date: 1, premium_settle_date: 1 };
        function splitTrim(s) { return ('' + (s || '')).split(',').map(function (x) { return x.trim(); }).filter(function (x) { return x; }); }
        function cellVal(gr, f) { return DATEF[f] ? gr.getDisplayValue(f) : ((f === 'notional_amount' || f === 'premium_amount') ? fmtNum(gr.getValue(f)) : gr.getValue(f)); }

        if (input.kind === 'classify') {
            var cg = new GlideRecord(T_CASE);
            if (cg.get(input.sys_id)) {
                var ma = splitTrim(cg.getValue('matched_asset'));
                var ms = splitTrim(cg.getValue('matched_subject'));
                var reason = cg.getValue('classification_reason') || '';
                var tid = cg.getValue('trade_id') || '';
                var aS = ma.length ? 0.5 : 0, sS = ms.length ? 0.3 : 0, tS = tid ? 0.2 : 0;
                var raw = aS + sS + tS, fin = Math.min(raw, 0.95);
                data.detail = {
                    kind: 'classify', sys_id: input.sys_id,
                    label: cg.getValue('classification_label') || 'IRRELEVANT',
                    conf: Math.round(parseFloat(cg.getValue('classification_confidence') || '0') * 100),
                    trade_id: tid, subject: cg.getValue('subject') || '(no subject)',
                    sender: cg.getValue('sender') || '—',
                    received: cg.getDisplayValue('received_at') || cg.getDisplayValue('sys_created_on'),
                    asset_class: cg.getValue('asset_class') || '—',
                    attachment_count: parseInt(cg.getValue('attachment_count') || '0', 10),
                    message_id: cg.getValue('message_id') || '—',
                    skip_reason: cg.getValue('skip_reason') || '',
                    reviewed: cg.getValue('review_decision') || '',
                    reason: reason, asset_kws: ma, subject_kws: ms,
                    is_negative: /negative keyword/i.test(reason),
                    a_score: aS, s_score: sS, t_score: tS, raw_score: raw, final_score: fin, capped: raw > 0.95
                };
            }
        } else if (input.kind === 'extract') {
            var tr = new GlideRecord(T_TRADE);
            if (tr.get(input.sys_id)) {
                var critical = { trade_id: 1, counterparty: 1, currency_pair: 1, buy_sell: 1, notional_amount: 1, settlement_date: 1 };
                var secondary = { uti: 1, trade_date: 1, notional_currency: 1 };
                var order = ['trade_id', 'uti', 'trade_date', 'counterparty', 'currency_pair', 'buy_sell', 'option_type', 'exercise_style', 'notional_amount', 'notional_currency', 'strike_rate', 'expiry_date', 'settlement_date', 'settlement_status', 'premium_amount', 'trader', 'book'];
                var monoF = { trade_id: 1, uti: 1, currency_pair: 1, notional_amount: 1, notional_currency: 1, strike_rate: 1 };
                var fields = [], critMiss = [], secMiss = [];
                for (var fi = 0; fi < order.length; fi++) {
                    var f = order[fi];
                    var v = cellVal(tr, f);
                    var flag = critical[f] ? 'critical' : (secondary[f] ? 'secondary' : '');
                    var miss = !v;
                    if (miss && flag === 'critical') critMiss.push(LBL[f]);
                    if (miss && flag === 'secondary') secMiss.push(LBL[f]);
                    fields.push({ label: LBL[f] || f, value: v || '', mono: !!monoF[f], flag: flag, missing: miss });
                }
                data.detail = {
                    kind: 'extract', sys_id: input.sys_id,
                    trade_id: tr.getValue('trade_id') || '', currency_pair: tr.getValue('currency_pair') || '',
                    subject: [tr.getValue('buy_sell'), tr.getValue('currency_pair'), tr.getValue('option_type')].filter(function (x) { return x; }).join(' '),
                    source: tr.getValue('source') || 'Body', source_file: tr.getValue('source_file') || '',
                    fields: fields, level: critMiss.length ? 'break' : (secMiss.length ? 'review' : 'complete'),
                    crit_missing: critMiss, sec_missing: secMiss
                };
            }
        } else if (input.kind === 'recon') {
            var mrr = new GlideRecord(T_MATCH);
            if (mrr.get(input.sys_id)) {
                var filled = splitTrim(mrr.getValue('filled_fields'));
                var core = ['trade_id', 'uti', 'trade_date', 'counterparty', 'currency_pair', 'buy_sell', 'notional_amount', 'notional_currency', 'strike_rate', 'expiry_date', 'settlement_date', 'option_type', 'premium_amount', 'settlement_status', 'trader', 'book'];
                var monoR = { trade_id: 1, uti: 1, currency_pair: 1, strike_rate: 1, notional_amount: 1 };
                var grid = [], cpair = '', srcv = '—';
                var trr = new GlideRecord(T_TRADE);
                if (trr.get(mrr.getValue('trade'))) {
                    cpair = trr.getValue('currency_pair') || '';
                    srcv = trr.getValue('source') || '—';
                    for (var gi = 0; gi < core.length; gi++) {
                        var cf = core[gi];
                        grid.push({ label: LBL[cf] || cf, value: cellVal(trr, cf) || '', mono: !!monoR[cf], filled: filled.indexOf(cf) > -1 });
                    }
                }
                var diffs = [];
                var fd = new GlideRecord('x_2112826_fxcm_field_diff');
                fd.addQuery('match_result', input.sys_id);
                fd.query();
                while (fd.next()) {
                    var ff = fd.getValue('field');
                    diffs.push({ label: LBL[ff] || ff, extracted: fd.getValue('extracted_value'), golden: fd.getValue('golden_value'), agree: (fd.getValue('agree') == '1' || fd.getValue('agree') === 'true') });
                }
                data.detail = {
                    kind: 'recon', sys_id: input.sys_id,
                    status: mrr.getValue('status') || 'UNMATCHED',
                    conf: Math.round(parseFloat(mrr.getValue('confidence') || '0') * 100),
                    agreed: parseInt(mrr.getValue('agreed_fields') || '0', 10),
                    compared: parseInt(mrr.getValue('compared_fields') || '0', 10),
                    filled_count: parseInt(mrr.getValue('filled_count') || '0', 10),
                    golden_found: (mrr.getValue('golden_found') == '1' || mrr.getValue('golden_found') === 'true'),
                    trade_id: mrr.getValue('trade_id') || '', currency_pair: cpair, source: srcv,
                    grid: grid, filled_labels: filled.map(function (x) { return LBL[x] || x; }), diffs: diffs,
                    golden_file: 'FX_Options_Trade_masterDataset.xlsx'
                };
            }
        }
        return; // detail is a lightweight fetch — skip the full dashboard recompute
    }

    /* ---- KPI stats ---- */
    var casesTotal = count(T_CASE);
    var relevant = count(T_CASE, 'classification_label', 'RELEVANT');
    var ambiguous = count(T_CASE, 'classification_label', 'AMBIGUOUS');
    var irrelevant = count(T_CASE, 'classification_label', 'IRRELEVANT');
    var duplicates = count(T_CASE, 'skip_reason', 'duplicate');
    var tradesTotal = count(T_TRADE);

    var withAtt = 0;
    var gaAtt = new GlideAggregate(T_CASE);
    gaAtt.addQuery('attachment_count', '>', 0);
    gaAtt.addAggregate('COUNT');
    gaAtt.query();
    if (gaAtt.next()) withAtt = parseInt(gaAtt.getAggregate('COUNT'), 10);

    /* ---- emails (Sync tab) + classify rows (Classify tab) ---- */
    data.emails = [];
    data.classify = [];
    var i = 1;
    var ec = new GlideRecord(T_CASE);
    ec.orderByDesc('received_at');
    ec.setLimit(200);
    ec.query();
    while (ec.next()) {
        var att = parseInt(ec.getValue('attachment_count') || '0', 10);
        var recv = ec.getValue('received_at') || fmtIST(ec.getValue('sys_created_on'));
        data.emails.push({
            n: i++,
            subject: ec.getValue('subject') || '(no subject)',
            sender: ec.getValue('sender') || '—',
            received: recv,
            att: att
        });
        var cpct = Math.round(parseFloat(ec.getValue('classification_confidence') || '0') * 100);
        var lbl = ec.getValue('classification_label') || 'IRRELEVANT';
        data.classify.push({
            sys_id: ec.getUniqueValue(),
            trade_id: ec.getValue('trade_id') || '',
            subject: ec.getValue('subject') || '(no subject)',
            sender: ec.getValue('sender') || '—',
            label: lbl,
            conf: cpct,
            conf_class: confClass(cpct),
            asset_class: ec.getValue('asset_class') || (lbl === 'RELEVANT' ? 'FX Settlement' : (lbl === 'AMBIGUOUS' ? 'Unknown' : 'Not Relevant')),
            reason: ec.getValue('classification_reason') || '',
            att: att,
            reviewed: ec.getValue('review_decision') || ''
        });
    }

    /* ---- trades (Extract tab) + sys_id map for Recon join ---- */
    data.trades = [];
    var tradeMap = {};
    var critical = ['trade_id', 'counterparty', 'currency_pair', 'notional_amount', 'settlement_date', 'buy_sell'];
    var complete = 0, breaks = 0;
    var tr = new GlideRecord(T_TRADE);
    tr.orderBy('trade_id');
    tr.setLimit(500);
    tr.query();
    while (tr.next()) {
        var missing = 0, k;
        for (k = 0; k < critical.length; k++) {
            if (!tr.getValue(critical[k])) missing++;
        }
        var st = missing > 0 ? 'Break' : 'Complete';
        if (missing > 0) breaks++; else complete++;
        var row = {
            sys_id: tr.getUniqueValue(),
            status: st,
            missing: missing,
            trade_id: tr.getValue('trade_id') || '',
            uti: tr.getValue('uti') || '',
            trade_date: tr.getDisplayValue('trade_date') || '',
            counterparty: tr.getValue('counterparty') || '',
            currency_pair: tr.getValue('currency_pair') || '',
            buy_sell: tr.getValue('buy_sell') || '',
            notional: fmtNum(tr.getValue('notional_amount')),
            notional_ccy: tr.getValue('notional_currency') || '',
            settle: tr.getDisplayValue('settlement_date') || '',
            source: tr.getValue('source') || 'Body'
        };
        data.trades.push(row);
        tradeMap[tr.getUniqueValue()] = row;
    }

    /* ---- matches (Recon tab) ---- */
    data.matches = [];
    var matched = 0, enriched = 0, near = 0, mbreak = 0, unmatched = 0;
    var fieldsFilled = 0, confSum = 0, confN = 0;
    var mr = new GlideRecord(T_MATCH);
    mr.orderBy('trade_id');
    mr.setLimit(500);
    mr.query();
    while (mr.next()) {
        var status = mr.getValue('status') || 'UNMATCHED';
        if (status === 'MATCHED') matched++;
        else if (status === 'ENRICHED') enriched++;
        else if (status === 'NEAR_MATCH') near++;
        else if (status === 'BREAK') mbreak++;
        else unmatched++;
        var fc = parseInt(mr.getValue('filled_count') || '0', 10);
        fieldsFilled += fc;
        var mc = Math.round(parseFloat(mr.getValue('confidence') || '0') * 100);
        confSum += mc; confN++;
        var t = tradeMap[mr.getValue('trade')] || {};
        data.matches.push({
            sys_id: mr.getUniqueValue(),
            trade_id: mr.getValue('trade_id') || '',
            status: status,
            conf: mc,
            conf_class: confClass(mc),
            filled: fc,
            counterparty: t.counterparty || '—',
            currency_pair: t.currency_pair || '—',
            notional: t.notional || '—',
            settle: t.settle || '—',
            source: t.source ? (t.source === 'Attachment' ? 'Attachment (xlsx)' : 'Body') : '—'
        });
    }

    var avgConf = confN ? Math.round(confSum / confN) : 0;

    data.stats = {
        cases_total: casesTotal,
        relevant: relevant,
        ambiguous: ambiguous,
        irrelevant: irrelevant,
        duplicates: duplicates,
        trades: tradesTotal,
        with_att: withAtt,
        complete: complete,
        breaks_extract: breaks,
        matched: matched,
        enriched: enriched,
        near: near,
        breaks: mbreak,
        unmatched: unmatched,
        fields_filled: fieldsFilled,
        avg_conf: avgConf,
        recon_total: matched + enriched + near + mbreak + unmatched
    };

    data.last_sync = fmtIST(new GlideDateTime().getValue());

    /* ---- settings + keywords (Settings view) ---- */
    var cfg = {};
    var sr = new GlideRecord(T_SET);
    sr.orderByDesc('sys_created_on');
    sr.setLimit(1);
    sr.query();
    if (sr.next()) {
        cfg = {
            asset_weight: +sr.getValue('asset_weight'),
            subject_weight: +sr.getValue('subject_weight'),
            trade_id_weight: +sr.getValue('trade_id_weight'),
            relevant_threshold: +sr.getValue('relevant_threshold'),
            ambiguous_threshold: +sr.getValue('ambiguous_threshold'),
            tolerance: +sr.getValue('match_numeric_tolerance'),
            break_threshold: +sr.getValue('match_break_threshold'),
            match_fields: sr.getValue('match_fields')
        };
    }
    data.config = cfg;
    data.kw = { asset: [], subject: [], negative: [] };
    var kr = new GlideRecord(T_KW);
    kr.orderBy('value');
    kr.setLimit(300);
    kr.query();
    while (kr.next()) {
        var ty = kr.getValue('type');
        if (data.kw[ty]) data.kw[ty].push({ sys_id: kr.getUniqueValue(), value: kr.getValue('value') });
    }

    /* ---- current logged-in user (sidebar + avatars) ---- */
    var uname = gs.getUserDisplayName() || 'User';
    var uparts = ('' + uname).trim().split(/\s+/);
    var uinit = (uparts.length >= 2 ? (uparts[0].charAt(0) + uparts[1].charAt(0)) : ('' + uname).substring(0, 2)).toUpperCase();
    var utitle = 'SSG Operations';
    var ug = new GlideRecord('sys_user');
    if (ug.get(gs.getUserID())) {
        utitle = ug.getValue('title') || ug.getDisplayValue('department') || 'SSG Operations';
    }
    data.user = { name: uname, initials: uinit, title: utitle };

    /* ---- audit trail (most recent 200 events) ---- */
    data.audit = [];
    var aq = new GlideRecord('x_2112826_fxcm_audit_event');
    aq.orderByDesc('event_time');
    aq.setLimit(200);
    aq.query();
    while (aq.next()) {
        data.audit.push({
            time: fmtIST(aq.getValue('event_time') || aq.getValue('sys_created_on')),
            actor: aq.getValue('actor'),
            action: aq.getValue('action'),
            outcome: aq.getValue('outcome') || 'success',
            resource: aq.getValue('resource'),
            details: aq.getValue('details')
        });
    }
    data.audit_total = count(T_AUDIT);

    /* ---- schedules (Configure Workflows view) ---- */
    data.schedules = [{
        name: 'FX Trade Settlement',
        desc: 'Sync mailboxes, shortlist FX settlement emails',
        frequency: 'Every 24 hours',
        last: data.last_sync,
        active: true
    }];
})();

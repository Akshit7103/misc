import { SPWidget } from '@servicenow/sdk/core'

/**
 * Nomura login widget — a custom branded split-screen sign-in. The client
 * authenticates through the same endpoint the OOTB Service Portal login widget
 * uses, so it is a real working login (not a mock).
 */
export const loginWidget = SPWidget({
    $id: Now.ID['fxcm_login_widget'],
    name: 'FX Compare & Match Login',
    id: 'fxcm-login',
    clientScript: Now.include('../../server/sp/login.client.js'),
    htmlTemplate: Now.include('../../server/sp/login.html'),
    customCss: Now.include('../../server/sp/login.css'),
    public: true,
    hasPreview: false,
})

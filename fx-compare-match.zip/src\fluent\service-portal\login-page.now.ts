import { SPPage } from '@servicenow/sdk/core'
import { loginWidget } from './login-widget.now'

/**
 * Public login page — full-bleed split-screen Nomura sign-in. Set as the
 * portal's loginPage so unauthenticated users land here.
 */
export const loginPage = SPPage({
    pageId: 'fxcm-login',
    title: 'Sign in · FX Compare & Match',
    public: true,
    css: `
        html, body { margin: 0 !important; padding: 0 !important; height: 100%; overflow: hidden !important; }
        #sp-page-root, .sp-page-root, main { padding: 0 !important; margin: 0 !important; }
        .container-fluid, .container { padding: 0 !important; margin: 0 !important; max-width: 100% !important; width: 100% !important; }
        .row, .sp-row { margin: 0 !important; }
        [class^="col-"], [class*=" col-"] { padding: 0 !important; }
        sp-notifications, sn-banner { display: none !important; }
    `,
    containers: [
        {
            $id: Now.ID['fxcm_login_container'],
            name: 'Login',
            width: 'container-fluid',
            order: 1,
            rows: [
                {
                    $id: Now.ID['fxcm_login_row'],
                    order: 1,
                    columns: [
                        {
                            $id: Now.ID['fxcm_login_col'],
                            size: 12,
                            order: 1,
                            instances: [
                                {
                                    $id: Now.ID['fxcm_login_instance'],
                                    widget: loginWidget,
                                    order: 1,
                                },
                            ],
                        },
                    ],
                },
            ],
        },
    ],
})

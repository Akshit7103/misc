import { BusinessRule } from '@servicenow/sdk/core'

/**
 * Reconcile Trade — after-insert rule that runs Compare & Match for each
 * extracted FX Trade, populating Match Results + Field Diffs.
 */
BusinessRule({
    $id: Now.ID['br-match-trade'],
    name: 'Reconcile Trade (Compare & Match)',
    table: 'x_2112826_fxcm_trade',
    when: 'after',
    action: ['insert'],
    order: 100,
    active: true,
    script: Now.include('../../server/match-trade.js'),
})

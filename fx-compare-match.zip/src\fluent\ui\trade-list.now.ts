import { List, default_view } from '@servicenow/sdk/core'

/** FX Trades default list — the key trade fields in a sensible order. */
export const tradeList = List({
    table: 'x_2112826_fxcm_trade',
    view: default_view,
    columns: [
        'trade_id', 'currency_pair', 'buy_sell', 'notional_amount', 'notional_currency',
        'counterparty', 'settlement_date', 'strike_rate', 'source', 'case',
    ],
})

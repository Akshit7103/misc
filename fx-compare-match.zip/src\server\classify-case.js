/**
 * Business Rule script (before insert) on x_2112826_fxcm_case.
 * 1) auto-fills the dedup key (message_id) for manual cases,
 * 2) classifies via the RuleClassifier, and
 * 3) applies the idempotency guards (message_id_exists / trade_id_exists).
 * The ServiceNow equivalent of EmailAgentRunner's per-email step.
 * Classic (non-module) server script: `current`, `previous` and the scope
 * namespace are globally available.
 */
(function executeRule(current, previous /*null when async*/) {
    // Auto-generate a message id for manually-created cases so the dedup key is
    // always populated (real ingestion supplies the email's Message-ID).
    if (!current.getValue('message_id')) {
        current.setValue('message_id', 'manual-' + gs.generateGUID());
    }

    // --- Classify ---
    var rc = new x_2112826_fxcm.RuleClassifier();
    var result = rc.classify(current.getValue('subject'), current.getValue('body'));

    current.setValue('classification_label', result.label);
    current.setValue('classification_confidence', result.confidence);
    current.setValue('classification_reason', result.reason);
    current.setValue('matched_asset', result.matched_asset);
    current.setValue('matched_subject', result.matched_subject);
    current.setValue('asset_class', result.asset_class);
    if (result.trade_id) {
        current.setValue('trade_id', result.trade_id);
    }

    // --- Audit: the classification decision ---
    var audit = new x_2112826_fxcm.AuditService();
    var cid = current.getUniqueValue();
    audit.log('email.classified', {
        resource: result.trade_id || current.getValue('subject'),
        correlation_id: cid,
        details: result.label + ' · ' + Math.round((result.confidence || 0) * 100) + '% · trade ' + (result.trade_id || '—')
    });

    // --- Dedup guard #1: this exact email was already processed ---
    if (_exists('message_id', current.getValue('message_id'))) {
        current.setValue('skip_reason', 'already_processed');
        current.setValue('state', 'closed');
        audit.log('email.skipped', { outcome: 'skipped', resource: current.getValue('message_id'), correlation_id: cid, details: 'Already processed — message_id exists' });
        return;
    }

    // --- Dedup guard #2: this trade was already captured by another case ---
    if (result.label === 'RELEVANT' && result.trade_id && _exists('trade_id', result.trade_id)) {
        current.setValue('skip_reason', 'duplicate');
        current.setValue('state', 'closed');
        audit.log('trade.duplicate', { outcome: 'skipped', resource: result.trade_id, correlation_id: cid, details: 'Duplicate trade_id — not stored for extraction' });
        return;
    }

    current.setValue('state', 'classified');

    // Does another (already-saved) case carry this field value? `current` is not
    // inserted yet, so this only matches prior records — never itself.
    function _exists(field, value) {
        if (!value) return false;
        var gr = new GlideRecord('x_2112826_fxcm_case');
        gr.addQuery(field, value);
        gr.setLimit(1);
        gr.query();
        return gr.hasNext();
    }
})(current, previous);

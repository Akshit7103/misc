/**
 * Scheduled Job — FX Graph Mailbox Sync. Runs in the background (outbound HTTP
 * permitted) and pulls new inbox mail via the GraphConnector. Also runnable
 * on-demand via "Execute Now" while testing.
 */
(function () {
    var res = new x_2112826_fxcm.GraphConnector().syncInbox(25);
    gs.info('[FXCM] Graph mailbox sync — created=' + res.created + ' skipped=' + res.skipped + ' errors=' + res.errors);
})();

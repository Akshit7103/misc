import { SPTheme } from '@servicenow/sdk/core'

/**
 * Nomura theme for the FX Compare & Match portal. The console widget draws its
 * own full-screen chrome, so the theme only sets the page background and omits a
 * header/footer (no default Service Portal navbar).
 */
export const nomuraTheme = SPTheme({
    $id: Now.ID['fxcm_theme'],
    name: 'Nomura FX Theme',
    customCss: `
        $brand-primary: #C8102E !default;
        $body-bg:       #f4f6fa !default;
        $link-color:    #C8102E !default;
    `,
})

/**
 * Script Action — runs the Graph mailbox sync in the BACKGROUND when the
 * console "Sync mailbox" button fires the x_2112826_fxcm.graph_sync event.
 *
 * Why an event/script-action rather than calling the connector straight from
 * the widget: a Service Portal widget runs in an interactive transaction, and
 * scoped apps may NOT make synchronous outbound HTTP there. Event processing
 * runs in the background, where outbound HTTP is permitted (same context the
 * daily scheduled job uses).
 *
 * `event` (the sysevent GlideRecord) and `current` are in scope here but unused.
 */
(function () {
    var res = new x_2112826_fxcm.GraphConnector().syncInbox(25);
    gs.info('[FXCM] Graph mailbox sync (on-demand) — created=' + res.created +
        ' skipped=' + res.skipped + ' errors=' + res.errors);
})();

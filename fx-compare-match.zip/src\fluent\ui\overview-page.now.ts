import { UiPage } from '@servicenow/sdk/core'

/**
 * Overview — a code-built landing page (UI Page / Jelly) with live KPI tiles
 * across the pipeline (triage · extraction · reconciliation). Acts as the app's
 * "main page", linked first in the navigator menu.
 */
UiPage({
    $id: Now.ID['ui-overview'],
    category: 'general',
    endpoint: 'x_2112826_fxcm_overview.do',
    description: 'FX Compare & Match overview dashboard (KPI tiles).',
    html: Now.include('../../server/ui-overview.html'),
})

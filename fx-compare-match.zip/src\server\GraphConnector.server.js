/**
 * GraphConnector — pulls mail from Microsoft Graph (delegated OAuth) and feeds
 * each new message through the same pipeline as a manual .eml upload.
 *
 * Auth: every Graph call is issued THROUGH the defined REST Message named
 * REST_MSG ("FX Graph Token Helper" — OAuth 2.0, profile "Microsoft Graph
 * Outlook default_profile"). The consented delegated token is stored by
 * ServiceNow against that REST Message as its OAuth "requestor", so issuing our
 * calls through the same message is what lets the platform attach + auto-refresh
 * the token. An ad-hoc `new RESTMessageV2()` + setAuthenticationProfile() uses a
 * different requestor and gets an EMPTY token (401) — hence the named message.
 *
 * Constraints: MUST run from a background context (scheduled job / event script
 * action) — scoped apps can't do synchronous outbound HTTP interactively. The
 * scheduled job's "Run as" user must be the SAME user that consented (the token
 * is also keyed to that user); see the "FX Graph Mailbox Sync" job.
 *
 * Flow: GET /me/mailFolders/inbox/messages -> for each NEW message (dedup by
 * internetMessageId) GET /me/messages/{id}/$value (raw MIME) -> EmlParser -> case
 * (+ attachments) -> classify/extract/match business rules fire automatically.
 */
var GraphConnector = Class.create();
GraphConnector.prototype = {
    initialize: function () {
        this.GRAPH = 'https://graph.microsoft.com/v1.0';
        this.T_CASE = 'x_2112826_fxcm_case';
        this.REST_MSG = 'FX Graph Mailbox'; // in-scope REST Message; holds OAuth profile + (repointed) consented token
        this.REST_FN = 'GET';
    },

    // Build a RESTMessageV2 bound to the token-holding REST Message, pointed at `url`.
    // Auth (OAuth2 + profile + stored token) is inherited from the named message.
    _rest: function (url) {
        var r = new sn_ws.RESTMessageV2(this.REST_MSG, this.REST_FN);
        r.setHttpMethod('get');
        r.setEndpoint(url);
        return r;
    },

    // Pull up to `top` most-recent inbox messages; returns {created, skipped, errors}.
    syncInbox: function (top) {
        top = top || 25;
        var out = { created: 0, skipped: 0, errors: 0 };

        var listBody;
        try {
            var r = this._rest(this.GRAPH + '/me/mailFolders/inbox/messages?$top=' + top +
                '&$select=id,internetMessageId,subject,hasAttachments,receivedDateTime&$orderby=receivedDateTime%20desc');
            r.setRequestHeader('Accept', 'application/json');
            var resp = r.execute();
            var code = resp.getStatusCode();
            if (code != 200) {
                gs.error('[FXCM Graph] inbox list HTTP ' + code + ': ' + resp.getBody());
                this._audit('failure', 'Graph inbox list returned HTTP ' + code);
                out.errors++;
                return out;
            }
            listBody = resp.getBody();
        } catch (e) {
            gs.error('[FXCM Graph] inbox list call failed: ' + e);
            this._audit('failure', 'Inbox list call failed: ' + e);
            out.errors++;
            return out;
        }

        var msgs;
        try { msgs = (JSON.parse(listBody).value) || []; }
        catch (e2) { gs.error('[FXCM Graph] bad inbox JSON: ' + e2); out.errors++; return out; }

        for (var i = 0; i < msgs.length; i++) {
            var m = msgs[i];
            var imid = m.internetMessageId || m.id;
            if (this._caseExists(imid)) { out.skipped++; continue; }
            try {
                var rr = this._rest(this.GRAPH + '/me/messages/' + encodeURIComponent(m.id) + '/$value');
                var mimeResp = rr.execute();
                if (mimeResp.getStatusCode() != 200) {
                    gs.warn('[FXCM Graph] message ' + m.id + ' $value HTTP ' + mimeResp.getStatusCode());
                    out.errors++;
                    continue;
                }
                if (this._ingestEml(mimeResp.getBody(), imid, m.subject)) out.created++;
            } catch (e3) {
                gs.error('[FXCM Graph] message ' + m.id + ' ingest failed: ' + e3);
                out.errors++;
            }
        }

        this._audit(out.errors ? 'failure' : 'success',
            out.created + ' new, ' + out.skipped + ' already present, ' + out.errors + ' error(s)');
        return out;
    },

    // Parse raw MIME -> create a case (+ attachments). Mirrors the upload ingest.
    _ingestEml: function (eml, messageId, fallbackSubject) {
        var parsed = new x_2112826_fxcm.EmlParser().parse(eml);
        var c = new GlideRecord(this.T_CASE);
        c.initialize();
        c.setValue('subject', parsed.subject || fallbackSubject || 'Untitled');
        c.setValue('sender', parsed.sender || '');
        c.setValue('body', parsed.body || '');
        if (parsed.date) c.setValue('received_at', parsed.date);
        c.setValue('source', 'graph');
        if (messageId) c.setValue('message_id', messageId); // dedup key
        var newId = c.insert();
        if (newId && parsed.attachments && parsed.attachments.length) {
            var cg = new GlideRecord(this.T_CASE);
            if (cg.get(newId)) {
                var sa = new GlideSysAttachment();
                for (var ai = 0; ai < parsed.attachments.length; ai++) {
                    var at = parsed.attachments[ai];
                    var ct = at.contentType || 'application/octet-stream';
                    var fn = at.filename || ('attachment-' + (ai + 1));
                    if (at.base64) sa.writeBase64(cg, fn, ct, at.base64);
                    else if (at.text) sa.write(cg, fn, ct, at.text);
                }
                cg.setValue('attachment_count', parsed.attachments.length);
                cg.update();
            }
        }
        return newId;
    },

    _caseExists: function (mid) {
        if (!mid) return false;
        var g = new GlideRecord(this.T_CASE);
        g.addQuery('message_id', mid);
        g.setLimit(1);
        g.query();
        return g.hasNext();
    },

    _audit: function (outcome, details) {
        try {
            new x_2112826_fxcm.AuditService().log('mailbox.synced', { outcome: outcome, resource: 'Microsoft Graph inbox', details: details });
        } catch (e) { /* audit must never break sync */ }
    },

    type: 'GraphConnector'
};

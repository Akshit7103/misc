import { Form, default_view } from '@servicenow/sdk/core'

/**
 * Clean form layout for FX Case — inputs grouped at the top, the
 * auto-classified result fields in their own (note-flagged) section, and the
 * human-in-the-loop review fields separated out. Makes the record demoable.
 */
export const caseForm = Form({
    table: 'x_2112826_fxcm_case',
    view: default_view,
    sections: [
        {
            caption: 'Email',
            content: [
                {
                    layout: 'two-column',
                    leftElements: [
                        { field: 'subject', type: 'table_field' },
                        { field: 'sender', type: 'table_field' },
                        { field: 'source', type: 'table_field' },
                    ],
                    rightElements: [
                        { field: 'message_id', type: 'table_field' },
                        { field: 'received_at', type: 'table_field' },
                        { field: 'attachment_count', type: 'table_field' },
                    ],
                },
                {
                    layout: 'one-column',
                    elements: [{ field: 'body', type: 'table_field' }],
                },
            ],
        },
        {
            caption: 'Classification (set automatically on save)',
            content: [
                {
                    layout: 'one-column',
                    elements: [
                        {
                            type: 'annotation',
                            annotationId: Now.ID['ann-classification'],
                            text: 'These fields are populated automatically by the RuleClassifier when the case is saved. Leave them blank when creating a new case.',
                            annotationType: 'Info_Box_Blue',
                        },
                    ],
                },
                {
                    layout: 'two-column',
                    leftElements: [
                        { field: 'classification_label', type: 'table_field' },
                        { field: 'classification_confidence', type: 'table_field' },
                        { field: 'trade_id', type: 'table_field' },
                        { field: 'asset_class', type: 'table_field' },
                    ],
                    rightElements: [
                        { field: 'state', type: 'table_field' },
                        { field: 'matched_asset', type: 'table_field' },
                        { field: 'matched_subject', type: 'table_field' },
                    ],
                },
                {
                    layout: 'one-column',
                    elements: [{ field: 'classification_reason', type: 'table_field' }],
                },
            ],
        },
        {
            caption: 'Review (Human-in-the-loop)',
            content: [
                {
                    layout: 'two-column',
                    leftElements: [
                        { field: 'review_decision', type: 'table_field' },
                        { field: 'reviewed_by', type: 'table_field' },
                        { field: 'reviewed_at', type: 'table_field' },
                    ],
                    rightElements: [
                        { field: 'original_label', type: 'table_field' },
                        { field: 'skip_reason', type: 'table_field' },
                        { field: 'correlation_id', type: 'table_field' },
                    ],
                },
            ],
        },
    ],
})

import {
    Table,
    StringColumn,
    DecimalColumn,
    IntegerColumn,
    BooleanColumn,
} from '@servicenow/sdk/core'

/**
 * FX Settings — single configuration record holding the classifier weights /
 * thresholds and the compare-match tuning. Replaces the scalar fields of
 * EmailAgentConfig and the /config API. Admin-editable; read by the classifier
 * and matcher on each run.
 */
export const x_2112826_fxcm_settings = Table({
    name: 'x_2112826_fxcm_settings',
    label: 'FX Settings',
    display: 'default_asset_class',
    schema: {
        asset_weight: DecimalColumn({ label: 'Asset Weight', default: '0.5' }),
        subject_weight: DecimalColumn({ label: 'Subject Weight', default: '0.3' }),
        trade_id_weight: DecimalColumn({ label: 'Trade ID Weight', default: '0.2' }),
        relevant_threshold: DecimalColumn({ label: 'Relevant Threshold', default: '0.7' }),
        ambiguous_threshold: DecimalColumn({ label: 'Ambiguous Threshold', default: '0.3' }),
        default_asset_class: StringColumn({ label: 'Default Asset Class', maxLength: 60, default: 'FX Settlement' }),
        max_body_scan_chars: IntegerColumn({ label: 'Max Body Scan Chars', default: '2000' }),
        sync_frequency_hours: IntegerColumn({ label: 'Sync Frequency (hours)', default: '24' }),
        match_numeric_tolerance: DecimalColumn({ label: 'Match Numeric Tolerance', default: '0.01' }),
        match_break_threshold: DecimalColumn({ label: 'Match Break Threshold', default: '0.6' }),
        match_enrich_enabled: BooleanColumn({ label: 'Match Enrich Enabled', default: true }),
        match_fields: StringColumn({
            label: 'Match Fields',
            maxLength: 500,
            default: 'currency_pair,buy_sell,notional_amount,counterparty,settlement_date,strike_rate',
        }),
    },
})

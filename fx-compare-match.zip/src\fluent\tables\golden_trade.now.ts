import {
    Table,
    StringColumn,
    ChoiceColumn,
    DecimalColumn,
    FloatColumn,
    DateColumn,
} from '@servicenow/sdk/core'

/**
 * Golden Trade — the trusted master blotter the extracted trades are
 * reconciled against. Replaces FX_Options_Trade_masterDataset.xlsx; stands in
 * for GLOSS / OBI / FO. Keyed on trade_id. Populated via Import Set.
 */
export const x_2112826_fxcm_golden_trade = Table({
    name: 'x_2112826_fxcm_golden_trade',
    label: 'Golden Trade',
    display: 'trade_id',
    schema: {
        trade_id: StringColumn({ label: 'Trade ID', maxLength: 40, mandatory: true }),
        uti: StringColumn({ label: 'UTI', maxLength: 60 }),
        trade_date: DateColumn({ label: 'Trade Date' }),
        counterparty: StringColumn({ label: 'Counterparty', maxLength: 120 }),
        counterparty_code: StringColumn({ label: 'Counterparty Code', maxLength: 60 }),
        currency_pair: StringColumn({ label: 'Currency Pair', maxLength: 10 }),
        base_currency: StringColumn({ label: 'Base Currency', maxLength: 5 }),
        quote_currency: StringColumn({ label: 'Quote Currency', maxLength: 5 }),
        option_type: StringColumn({ label: 'Option Type', maxLength: 30 }),
        exercise_style: StringColumn({ label: 'Exercise Style', maxLength: 30 }),
        buy_sell: ChoiceColumn({ label: 'Buy / Sell', choices: { Buy: 'Buy', Sell: 'Sell' } }),
        notional_amount: DecimalColumn({ label: 'Notional Amount' }),
        notional_currency: StringColumn({ label: 'Notional Currency', maxLength: 5 }),
        strike_rate: FloatColumn({ label: 'Strike Rate' }),
        expiry_date: DateColumn({ label: 'Expiry Date' }),
        settlement_date: DateColumn({ label: 'Settlement Date' }),
        premium_amount: DecimalColumn({ label: 'Premium Amount' }),
        premium_currency: StringColumn({ label: 'Premium Currency', maxLength: 5 }),
        premium_settle_date: DateColumn({ label: 'Premium Settle Date' }),
        delta: FloatColumn({ label: 'Delta' }),
        implied_vol: FloatColumn({ label: 'Implied Vol' }),
        settlement_status: StringColumn({ label: 'Settlement Status', maxLength: 40 }),
        portfolio: StringColumn({ label: 'Portfolio', maxLength: 60 }),
        trader: StringColumn({ label: 'Trader', maxLength: 60 }),
        book: StringColumn({ label: 'Book', maxLength: 60 }),
    },
})

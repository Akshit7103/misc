import { Table, StringColumn, IntegerColumn } from '@servicenow/sdk/core'

/**
 * Trade ID Pattern — ordered regex patterns the classifier tries to extract a
 * trade id. Replaces EmailAgentConfig.trade_id_patterns.
 */
export const x_2112826_fxcm_trade_id_pattern = Table({
    name: 'x_2112826_fxcm_trade_id_pattern',
    label: 'Trade ID Pattern',
    display: 'pattern',
    schema: {
        pattern: StringColumn({ label: 'Regex Pattern', maxLength: 200, mandatory: true }),
        order: IntegerColumn({ label: 'Order' }),
    },
})

import { ScriptInclude } from '@servicenow/sdk/core'

/** EmlParser — parse a raw .eml (MIME) string into subject/sender/body/attachments. */
ScriptInclude({
    $id: Now.ID['si-eml-parser'],
    name: 'EmlParser',
    active: true,
    apiName: 'x_2112826_fxcm.EmlParser',
    description: 'Parse uploaded .eml (RFC-822/MIME) files into structured emails for ingestion.',
    script: Now.include('../../server/EmlParser.server.js'),
})

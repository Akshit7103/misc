/**
 * TradeExtractor — orchestrates extraction for a case (ServiceNow equivalent of
 * EmailAgentRunner's _store_case extraction step). For a RELEVANT, non-duplicate
 * case it parses trades and writes x_2112826_fxcm_trade rows, then sets the case
 * state to 'extracted'.
 *
 * Attachment-first: if the case carries .xlsx/.csv blotters, one trade per row;
 * otherwise parse the single trade from the email body.
 * Script Include class file — Glide APIs auto-available; do not import.
 */
var TradeExtractor = Class.create();
TradeExtractor.prototype = {
    initialize: function () {},

    TRADE_FIELDS: [
        'trade_id', 'uti', 'trade_date', 'counterparty', 'counterparty_code',
        'currency_pair', 'base_currency', 'quote_currency', 'option_type',
        'exercise_style', 'buy_sell', 'notional_amount', 'notional_currency',
        'strike_rate', 'expiry_date', 'settlement_date', 'premium_amount',
        'premium_currency', 'premium_settle_date', 'delta', 'implied_vol',
        'settlement_status', 'portfolio', 'trader', 'book', 'source', 'source_file',
    ],

    // Extract trades for a case by sys_id. Returns number of trade rows created.
    extractForCase: function (caseSysId) {
        var c = new GlideRecord('x_2112826_fxcm_case');
        if (!c.get(caseSysId)) return 0;
        if (c.getValue('classification_label') !== 'RELEVANT') return 0;
        if (c.getValue('skip_reason')) return 0;

        // Idempotent: clear any trades previously extracted for this case.
        var existing = new GlideRecord('x_2112826_fxcm_trade');
        existing.addQuery('case', caseSysId);
        existing.deleteMultiple();

        var created = 0;
        var attCount = 0;
        var fromAttachment = false;

        // --- Attachment path (blotters: one trade per row) ---
        var ae = new x_2112826_fxcm.AttachmentExtractor();
        var att = new GlideRecord('sys_attachment');
        att.addQuery('table_name', 'x_2112826_fxcm_case');
        att.addQuery('table_sys_id', caseSysId);
        att.query();
        while (att.next()) {
            attCount++;
            var fn = att.getValue('file_name');
            if (!ae.isSupported(fn)) continue;
            var rows = ae.extractRows(att.getUniqueValue(), fn);
            for (var i = 0; i < rows.length; i++) {
                rows[i].source = 'Attachment';
                rows[i].source_file = fn;
                this._createTrade(caseSysId, rows[i]);
                created++;
                fromAttachment = true;
            }
        }

        // --- Body path (single-trade email, only if no blotter produced rows) ---
        if (!fromAttachment) {
            var tradeId = c.getValue('trade_id');
            if (tradeId && tradeId.indexOf('UNKNOWN') !== 0) {
                var be = new x_2112826_fxcm.BodyExtractor();
                var t = be.parse(c.getValue('subject'), c.getValue('body'), tradeId);
                if (t.trade_id) {
                    if (!t.counterparty) {
                        var sender = (c.getValue('sender') || '').split('<')[0].split('(')[0].trim();
                        if (sender) t.counterparty = sender;
                    }
                    t.source = 'Body';
                    this._createTrade(caseSysId, t);
                    created++;
                }
            }
        }

        c.setValue('state', 'extracted');
        c.setValue('attachment_count', attCount);
        c.update();
        return created;
    },

    _createTrade: function (caseSysId, t) {
        var gr = new GlideRecord('x_2112826_fxcm_trade');
        gr.initialize();
        gr.setValue('case', caseSysId);
        for (var i = 0; i < this.TRADE_FIELDS.length; i++) {
            var f = this.TRADE_FIELDS[i];
            if (t[f] !== undefined && t[f] !== null && t[f] !== '') {
                gr.setValue(f, String(t[f]));
            }
        }
        return gr.insert();
    },

    type: 'TradeExtractor',
};

/**
 * Business Rule (after insert) on x_2112826_fxcm_case.
 * For a RELEVANT, non-duplicate case, extract the trade(s) into FX Trade rows.
 * Runs after insert so the case sys_id (and any attachments) exist.
 * Classic server script — `current` and the scope namespace are global.
 */
(function executeRule(current, previous /*null when async*/) {
    var caseId = current.getUniqueValue();
    new x_2112826_fxcm.TradeExtractor().extractForCase(caseId);
    var n = new GlideAggregate('x_2112826_fxcm_trade');
    n.addQuery('case', caseId);
    n.addAggregate('COUNT');
    n.query();
    var cnt = n.next() ? parseInt(n.getAggregate('COUNT'), 10) : 0;
    if (cnt > 0) {
        new x_2112826_fxcm.AuditService().log('trades.extracted', {
            resource: current.getValue('trade_id') || current.getValue('subject'),
            correlation_id: caseId,
            details: cnt + ' trade(s) extracted from the email body'
        });
    }
})(current, previous);

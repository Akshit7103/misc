import { List, default_view } from '@servicenow/sdk/core'

/**
 * Default list view for FX Cases — the columns that matter for triage, in a
 * sensible order, so the list reads cleanly on screen.
 */
export const caseList = List({
    table: 'x_2112826_fxcm_case',
    view: default_view,
    columns: [
        'subject',
        'classification_label',
        'classification_confidence',
        'trade_id',
        'classification_reason',
        'source',
        'state',
        'message_id',
    ],
})

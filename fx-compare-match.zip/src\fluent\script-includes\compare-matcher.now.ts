import { ScriptInclude } from '@servicenow/sdk/core'

/** CompareMatcher — reconcile extracted trades against the golden source. */
ScriptInclude({
    $id: Now.ID['si-compare-matcher'],
    name: 'CompareMatcher',
    active: true,
    apiName: 'x_2112826_fxcm.CompareMatcher',
    description: 'Match -> enrich -> compare a trade vs the golden source (port of compare_match.py).',
    script: Now.include('../../server/CompareMatcher.server.js'),
})

import { Record } from '@servicenow/sdk/core'

/**
 * In-scope REST Message used by GraphConnector to call Microsoft Graph.
 *
 * Why in-scope: a scoped Script Include cannot construct a REST Message that
 * lives in the Global scope — sys_rest_message_fn has no "accessible from"
 * field, so the child GET method can never be made cross-scope-callable. The
 * message + method therefore have to be owned by THIS app. (Authoring them via
 * Fluent is also the only way to land them in the app scope; the Table API
 * forces new records to Global.)
 *
 * Auth: OAuth 2.0 against the global profile "Microsoft Graph Outlook
 * default_profile". The consented delegated token is repointed onto THIS
 * message's OAuth requestor (oauth_requestor_profile.requestor_id), so the
 * existing consent is reused — no re-consent needed.
 */
const OAUTH_PROFILE = 'e74f2f1d83f94310469fc4a6feaad3db' // global oauth_entity_profile sys_id

Record({
    $id: Now.ID['fx-graph-rest-msg'],
    table: 'sys_rest_message',
    data: {
        name: 'FX Graph Mailbox',
        rest_endpoint: 'https://graph.microsoft.com/v1.0/me/messages',
        authentication_type: 'oauth2',
        oauth2_profile: OAUTH_PROFILE,
    },
})

Record({
    $id: Now.ID['fx-graph-rest-fn'],
    table: 'sys_rest_message_fn',
    data: {
        // NB: a literal sys_id is required here — Now.ID['...'] does NOT resolve
        // to a sys_id inside a generic Record() data field (it stores the raw
        // key string, orphaning the method). This is the stable sys_id the SDK
        // assigns to $id 'fx-graph-rest-msg' (see generated/keys.ts).
        rest_message: '04bcd25d106e473e98f54ef4a2249ace',
        function_name: 'GET',
        http_method: 'get',
        rest_endpoint: 'https://graph.microsoft.com/v1.0/me/messages',
        authentication_type: 'inherit_from_parent',
    },
})

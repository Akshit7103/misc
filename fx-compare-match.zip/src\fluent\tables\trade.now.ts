import {
    Table,
    StringColumn,
    ChoiceColumn,
    DecimalColumn,
    FloatColumn,
    DateColumn,
    ReferenceColumn,
} from '@servicenow/sdk/core'

/**
 * FX Trade — one normalized trade row extracted from a relevant case
 * (email body or xlsx/csv attachment). Replaces extracted_trades.json.
 * Canonical field names match the golden source so they compare directly.
 * Rates use FloatColumn (full precision); money uses DecimalColumn (cents).
 */
export const x_2112826_fxcm_trade = Table({
    name: 'x_2112826_fxcm_trade',
    label: 'FX Trade',
    display: 'trade_id',
    audit: true,
    schema: {
        case: ReferenceColumn({
            label: 'Case',
            referenceTable: 'x_2112826_fxcm_case',
            cascadeRule: 'cascade',
        }),
        trade_id: StringColumn({ label: 'Trade ID', maxLength: 40, mandatory: true }),
        uti: StringColumn({ label: 'UTI', maxLength: 60 }),
        trade_date: DateColumn({ label: 'Trade Date' }),
        counterparty: StringColumn({ label: 'Counterparty', maxLength: 120 }),
        counterparty_code: StringColumn({ label: 'Counterparty Code', maxLength: 60 }),
        currency_pair: StringColumn({ label: 'Currency Pair', maxLength: 10 }),
        base_currency: StringColumn({ label: 'Base Currency', maxLength: 5 }),
        quote_currency: StringColumn({ label: 'Quote Currency', maxLength: 5 }),
        option_type: StringColumn({ label: 'Option Type', maxLength: 30 }),
        exercise_style: StringColumn({ label: 'Exercise Style', maxLength: 30 }),
        buy_sell: ChoiceColumn({ label: 'Buy / Sell', choices: { Buy: 'Buy', Sell: 'Sell' } }),
        notional_amount: DecimalColumn({ label: 'Notional Amount' }),
        notional_currency: StringColumn({ label: 'Notional Currency', maxLength: 5 }),
        strike_rate: FloatColumn({ label: 'Strike Rate' }),
        expiry_date: DateColumn({ label: 'Expiry Date' }),
        settlement_date: DateColumn({ label: 'Settlement Date' }),
        premium_amount: DecimalColumn({ label: 'Premium Amount' }),
        premium_currency: StringColumn({ label: 'Premium Currency', maxLength: 5 }),
        premium_settle_date: DateColumn({ label: 'Premium Settle Date' }),
        delta: FloatColumn({ label: 'Delta' }),
        implied_vol: FloatColumn({ label: 'Implied Vol' }),
        settlement_status: StringColumn({ label: 'Settlement Status', maxLength: 40 }),
        portfolio: StringColumn({ label: 'Portfolio', maxLength: 60 }),
        trader: StringColumn({ label: 'Trader', maxLength: 60 }),
        book: StringColumn({ label: 'Book', maxLength: 60 }),
        source: ChoiceColumn({
            label: 'Source',
            choices: { Body: 'Body', Attachment: 'Attachment' },
        }),
        source_file: StringColumn({ label: 'Source File', maxLength: 255 }),
    },
})

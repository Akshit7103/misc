import { List, default_view } from '@servicenow/sdk/core'

/** Match Results default list — status, confidence and the comparison counts. */
export const matchList = List({
    table: 'x_2112826_fxcm_match_result',
    view: default_view,
    columns: [
        'trade_id', 'status', 'confidence', 'golden_found',
        'compared_fields', 'agreed_fields', 'filled_count', 'trade',
    ],
})

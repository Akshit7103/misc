import '@servicenow/sdk/global'

declare global {
    namespace Now {
        namespace Internal {
            interface Keys extends KeysRegistry {
                explicit: {
                    'ann-classification': {
                        table: 'sys_ui_annotation'
                        id: '767b1378c39b4d67a5dca07492ed617a'
                    }
                    bom_json: {
                        table: 'sys_module'
                        id: '8e25402ed23045b2aa3d943c7e1130ab'
                    }
                    'br-classify-case': {
                        table: 'sys_script'
                        id: '0de892926da44bfab9385338b7f0c6c5'
                    }
                    'br-extract-on-attach': {
                        table: 'sys_script'
                        id: '49beb5a634a64dada4394be7f7a6d5a2'
                    }
                    'br-extract-trades': {
                        table: 'sys_script'
                        id: '8b828565646b49b1bb7ae2a58f6fabd8'
                    }
                    'br-match-trade': {
                        table: 'sys_script'
                        id: '704d6b260d3d479dbd289c432e7d382f'
                    }
                    'evt-graph-sync': {
                        table: 'sysevent_register'
                        id: '9bccde0238aa47138d017280259570d6'
                    }
                    'fs-label-ambiguous': {
                        table: 'sys_ui_style'
                        id: '2c8e238ebb5147a092901e02cbaa590a'
                    }
                    'fs-label-irrelevant': {
                        table: 'sys_ui_style'
                        id: '1b10630434bb440b8ec5b507ee653d97'
                    }
                    'fs-label-relevant': {
                        table: 'sys_ui_style'
                        id: '3bccb614941c4effb30325494422921b'
                    }
                    'fs-skip-duplicate': {
                        table: 'sys_ui_style'
                        id: '91b91d8cf7014db7979c3a71bfeb0418'
                    }
                    'fs-state-classified': {
                        table: 'sys_ui_style'
                        id: '53cf28ed3632460584143afdd8c65106'
                    }
                    'fs-state-closed': {
                        table: 'sys_ui_style'
                        id: '2d2b20e48af14aa9a3fc202dde0bd7b8'
                    }
                    'fs-state-matched': {
                        table: 'sys_ui_style'
                        id: '82214d8b42674cd68d96b34c77873f07'
                    }
                    'fsm-break': {
                        table: 'sys_ui_style'
                        id: '860c9c97882142ad80a82cb4c121781b'
                    }
                    'fsm-enriched': {
                        table: 'sys_ui_style'
                        id: '2b69a4c7199f4bf5abd7e7763edf532e'
                    }
                    'fsm-matched': {
                        table: 'sys_ui_style'
                        id: '428a415b73dd4857806d2daf860bf4ee'
                    }
                    'fsm-near': {
                        table: 'sys_ui_style'
                        id: '558fd10245f145a385451f32f3b97663'
                    }
                    'fsm-unmatched': {
                        table: 'sys_ui_style'
                        id: 'dc29ddb108c340aea8a659fa4eec548d'
                    }
                    'fx-graph-rest-msg': {
                        table: 'sys_rest_message'
                        id: '04bcd25d106e473e98f54ef4a2249ace'
                    }
                    fxcm_app_col: {
                        table: 'sp_column'
                        id: '4053444984d64e5da354872aca59c634'
                    }
                    fxcm_app_container: {
                        table: 'sp_container'
                        id: '670f5bf064d24f0f84901645bb2912dd'
                    }
                    fxcm_app_instance: {
                        table: 'sp_instance'
                        id: '31f2ec2608374bd5bf3bd41a36d8d773'
                    }
                    fxcm_app_row: {
                        table: 'sp_row'
                        id: '69e32c0438574c9b9b7c9c72f25f126b'
                    }
                    fxcm_console_widget: {
                        table: 'sp_widget'
                        id: 'b11059715c754b7fbf66b702942333b2'
                    }
                    fxcm_dir_filechange: {
                        table: 'sp_angular_provider'
                        id: '8e311a8a25134b97b29b566a66158858'
                    }
                    fxcm_dir_filedrop: {
                        table: 'sp_angular_provider'
                        id: 'ee3307e865e04ce887b40b40c7044c4a'
                    }
                    fxcm_login_col: {
                        table: 'sp_column'
                        id: '7a607871031a4fb7aca9318b705e71d8'
                    }
                    fxcm_login_container: {
                        table: 'sp_container'
                        id: '906de0c9a6794bea9f4478f5d95f8757'
                    }
                    fxcm_login_instance: {
                        table: 'sp_instance'
                        id: '142b6b3e924b4590a5257be06a48873c'
                    }
                    fxcm_login_row: {
                        table: 'sp_row'
                        id: '1bda392a43104b968de1fd4f14a6d82d'
                    }
                    fxcm_login_widget: {
                        table: 'sp_widget'
                        id: '5ec1454d773e454da8a2f652f824c4d5'
                    }
                    fxcm_portal: {
                        table: 'sp_portal'
                        id: '3ab3f8269a104fc8a21a73f2fe44d515'
                    }
                    fxcm_theme: {
                        table: 'sp_theme'
                        id: '0e14f2761ec64a9f83ef700a3ecaabfa'
                    }
                    'fxcm-category': {
                        table: 'sys_app_category'
                        id: '5318c37f7d3e490bb6c68b0ec15af232'
                    }
                    'fxcm-menu': {
                        table: 'sys_app_application'
                        id: 'bc0c8764c2c442aaabcde13eb8992d51'
                    }
                    'g-00001': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'd9b4f20d33324f4ab62ad7c5dd02651c'
                    }
                    'g-00002': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '6039ca952fbb423ba287da2d52bcf37f'
                    }
                    'g-00003': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '85636d2a590b45c6a25e115e523d6a28'
                    }
                    'g-00004': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'fd2b3cefa55e4704810cd918facacd2a'
                    }
                    'g-00005': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a7069fbda2114f35bec16a9c1d91b5c9'
                    }
                    'g-00006': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '305450214a0a4edea53281189028c8a7'
                    }
                    'g-00007': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '17598065b17743e6acd8c2bf6efb99da'
                    }
                    'g-00008': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '965831bf27524e07950ae4e47befb040'
                    }
                    'g-00009': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'fc3fb712a14e47218f52410582159a35'
                    }
                    'g-00010': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '3f76b0c276374c99977a259e2da9bdb7'
                    }
                    'g-00011': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '78b1dfb9212443f8bb110d5f11da3c38'
                    }
                    'g-00012': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'f1079dc32a274aec94f787bdff1a9a0f'
                    }
                    'g-00013': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '26156ef9f5674d319dcfc8af1d767f7b'
                    }
                    'g-00014': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '83ea2fd3be6642a1b2c10e96c792b0c2'
                    }
                    'g-00015': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'd15578f99f1744b7b2145055e1359ceb'
                    }
                    'g-00016': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'aa087dd039b94d82ba8095b50ede61c1'
                    }
                    'g-00017': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'f8fcc798d12f4ba489f8b22dfba7096b'
                    }
                    'g-00018': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '688b2bd074d643e3ba6224f8e849dd27'
                    }
                    'g-00019': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '587cd310bee8494a9d968d4d17522f2c'
                    }
                    'g-00020': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'affdbecff8ed47ba84380ee30b1ccd28'
                    }
                    'g-00021': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'db1f32a00e02415aaf04b137f3fd2eda'
                    }
                    'g-00022': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '5ced2ecc036146e4962ae4505ab93680'
                    }
                    'g-00023': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'c6c43fd2796d44459ac5dd7575413056'
                    }
                    'g-00024': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '63398cc5130a4188851d42068d498031'
                    }
                    'g-00025': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '63935d4d466649e5af24e534d70740c0'
                    }
                    'g-00026': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '8fd0bf5b4c1541d29dbe5f7ddbb90029'
                    }
                    'g-00027': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'd3aa38a887d542e49f452c92d776a8aa'
                    }
                    'g-00028': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '6ef4c971746c4082b24accf5a3c05d2c'
                    }
                    'g-00029': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'b28e89fa633248b592bcdb3693b1d931'
                    }
                    'g-00030': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'b44cb03ac8514e24b4e08c55f203927c'
                    }
                    'g-00031': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a958d7fbeee54a68b7bcc349de14acca'
                    }
                    'g-00032': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '978f9b00c7194ec88da14e6ed2800609'
                    }
                    'g-00033': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '04066e5aa6b44f279ad91d1b1dd1d415'
                    }
                    'g-00034': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '9ed4044f2ca1439eab28d1c8ba4a12c5'
                    }
                    'g-00035': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '37b7959f60b04d39baf4806861d0599d'
                    }
                    'g-00036': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'd4481f2e08834516b63c04fd426ff985'
                    }
                    'g-00037': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '69d2a6959a0b4973a46e7cafde527aa4'
                    }
                    'g-00038': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '62ff56ad7bcc4eaa94fc145acc4950d1'
                    }
                    'g-00039': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '8eeada48efb047f1a34ea46e2301a483'
                    }
                    'g-00040': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'ee365bd025a64ab287a121877271e6fb'
                    }
                    'g-00041': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '9f29ac7284ec495bad916d1c4d03d646'
                    }
                    'g-00042': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a33d024bae5849c3b6bc5af344f90b2b'
                    }
                    'g-00043': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '0906c05797134c0fa9eeff2a9408bf6c'
                    }
                    'g-00044': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '8a97d529ba9d4bc2aa06eff1761ff525'
                    }
                    'g-00045': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '9a87e54194d244ef9f0eeccbf5616b8a'
                    }
                    'g-00046': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '69dfd1c8fbe548088be23dcdef1c659e'
                    }
                    'g-00047': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a916d4b6aaf947a2b0b459ffa25f0cc1'
                    }
                    'g-00048': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'ff82d692c5ee416ba7f3a4f7fdd965f0'
                    }
                    'g-00049': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'e74e7ce77c254a058ed115923258cd34'
                    }
                    'g-00050': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '860e3fbf2f8243c1b15591b6d3ae1195'
                    }
                    'g-00051': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '947daea70ada4875bc5cbee61d756374'
                    }
                    'g-00052': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'b8588f6ed2c74dc8a20501be6787449a'
                    }
                    'g-00053': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '1e16f481411346cf8c8bb5a5c61f7366'
                    }
                    'g-00054': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '80d41d0784f8415abad4b71157169458'
                    }
                    'g-00055': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '345b88cab4f54e5490ed6be31a72e29f'
                    }
                    'g-00056': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '1c0348cca0e648a6b045f20dc7947c40'
                    }
                    'g-00057': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '37537e7a75364793aa08a4d9b24db7c8'
                    }
                    'g-00058': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '00ae57f1d52e42e89a5abbccdc545755'
                    }
                    'g-00059': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '1d6e40c465d0415b850bb6ece4d8db28'
                    }
                    'g-00060': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '92ecf0a42a284b209a474bc0d29ca988'
                    }
                    'g-00061': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '42f201801a1043e1856a141c3b3f96a7'
                    }
                    'g-00062': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '027ba6d927474333aaa234dac27cf58a'
                    }
                    'g-00063': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '6b4e09faa36849ceb7ed77bc888f6f5e'
                    }
                    'g-00064': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '2bf97493afd048e8b1e777999cfde96b'
                    }
                    'g-00065': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '63fbdeb13ee04a8781c504ead9a7b438'
                    }
                    'g-00066': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '0d42ab1816304ff59abafebe832272a0'
                    }
                    'g-00067': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'cbea90718c7e4758a3774ec5b7896933'
                    }
                    'g-00068': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '236684d26e97485e889e57722d5cfed2'
                    }
                    'g-00069': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '0a5df0a7645f40d8b1a62a6dfd9d934b'
                    }
                    'g-00070': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '9c7aaa0736764b3fb1785f9314bbc41c'
                    }
                    'g-00071': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '65e8fe97c9de4baeb84e3dcfb845de06'
                    }
                    'g-00072': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'e943e4aa3d3d44918326b5ff1bc16e73'
                    }
                    'g-00073': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '284dfdbe70fe43019d9fb4f4cd93daf3'
                    }
                    'g-00074': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '714ed6ed28364eef8adaee2408adff84'
                    }
                    'g-00075': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '760e70cf4ee3483698e3240393990d6a'
                    }
                    'g-00076': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '44c5e3d03f664639888de0123e3db05e'
                    }
                    'g-00077': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a45c00f5aac845db94d573a26e844826'
                    }
                    'g-00078': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'de48e9b1e926414d886d60ad255f5fa0'
                    }
                    'g-00079': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a056e7cd25ef4a7a8984d1c984ff9c41'
                    }
                    'g-00080': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '7447991ffb594ec0be4b264d13348a18'
                    }
                    'g-00081': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '877462558edb4382a4317ae56a5adb08'
                    }
                    'g-00082': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '066e1a97602c4025ad0285f96140b98d'
                    }
                    'g-00083': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '2d5d25e3220c4d6796bd6440399bd5ad'
                    }
                    'g-00084': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'a51e9176cf4f41e6b65d4890e79b68eb'
                    }
                    'g-00085': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'c8f1e2bbb8d04a318b72f42aec98aa06'
                    }
                    'g-00086': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '07cc72cf1e9c412dad5a39fb66b37d87'
                    }
                    'g-00087': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '0d0c766d1bdb42a6b0bd73a0cbd3809c'
                    }
                    'g-00088': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '5ef3971ea05740918073c75f0575e2c4'
                    }
                    'g-00089': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'df58b63ea5934bedb5e0743a924198ea'
                    }
                    'g-00090': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'e2b4c63f56c54564ae52c374b55b5fa4'
                    }
                    'g-00091': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'ff7b8b77fa7742dd993633f916dd22fc'
                    }
                    'g-00092': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'b0bf20b74d38476b83254e698f93638e'
                    }
                    'g-00093': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'be6d9f5942b04c91a4b4db8d1eff0c61'
                    }
                    'g-00094': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '890e5e65cb094cf9bfdbf655c32f8f1e'
                    }
                    'g-00095': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'd39c294fcab3429ca834748ba8e6d9ce'
                    }
                    'g-00096': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'bd0867b58d804bf78470f1bb03b28a84'
                    }
                    'g-00097': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'c9f8cecac37048508804fcbd5a75c7b7'
                    }
                    'g-00098': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '0e792c97c95f4efa9fd85e172571918c'
                    }
                    'g-00099': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '18236d789d1647bd803e803a8376a424'
                    }
                    'g-00100': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: 'af7ba28d9d264e60b9efaba0bf03c3a4'
                    }
                    'g-00500': {
                        table: 'x_2112826_fxcm_golden_trade'
                        id: '94b3759141cb4f078e1074406d0d1b21'
                        deleted: true
                    }
                    'kw-a-1': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'a2e1b5868b4e41908ab408df633d90de'
                    }
                    'kw-a-2': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'e278230a9bfc4c6ea65da5a779a07cf0'
                    }
                    'kw-a-3': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '827a526ca154442e82e0499599af5e25'
                    }
                    'kw-a-4': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '3ca387c650e948709c590ac4866a3a61'
                    }
                    'kw-a-5': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '77e32e0191f24625a7bd5fb714b9d657'
                    }
                    'kw-a-6': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'adc1361e384d4926a559ff29872fad93'
                    }
                    'kw-n-1': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '265ced9ff8cd408aa77b4f280f133065'
                    }
                    'kw-n-10': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '4bfed8f8db0040eb8d59ac960ff04ddc'
                    }
                    'kw-n-11': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '762b4586cd9d4eca929a126dbdc5bb5a'
                    }
                    'kw-n-12': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '351fae86179e4c49a11702a602f666d9'
                    }
                    'kw-n-13': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '8311e72be79a45f5b14eb9d33e01067d'
                    }
                    'kw-n-14': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '9b19152fc4a54ef1826381648a69faeb'
                    }
                    'kw-n-15': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'ef2ded03a7054458a45d6a2acad955e9'
                    }
                    'kw-n-16': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '652ace5a94d84e99b5f69eff72afcb3d'
                    }
                    'kw-n-17': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '012cf4e4e1ac4a5fa047b2f9a89e334c'
                    }
                    'kw-n-2': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'c42675315b9d4964abdd873cd0e76f39'
                    }
                    'kw-n-3': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '5f502f841acf4ce1ab77b63f3f1c5103'
                    }
                    'kw-n-4': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '194faf92009849b98620a91d2b2b46e1'
                    }
                    'kw-n-5': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '121b6bceede2448481bafdbed336b63f'
                    }
                    'kw-n-6': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'cbdb9df101664a64b61cc1f9731563fc'
                    }
                    'kw-n-7': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '876cceb734134c54be9ddd382e029dc7'
                    }
                    'kw-n-8': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '9451a5647e9f4d759ba84777a118a071'
                    }
                    'kw-n-9': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '19de13db6f65400eb93b9c413628c436'
                    }
                    'kw-s-1': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '2e3c2e35d05e47e0bc465a8545f995d5'
                    }
                    'kw-s-10': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'ec931380603549a8b36847ab6257c258'
                    }
                    'kw-s-2': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '363151ba9b7147f6813a45e4c25219fe'
                    }
                    'kw-s-3': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '35adaf36d37d4ab1b4e66e4c96d7412c'
                    }
                    'kw-s-4': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '32037e6e5dae431da323c47820151335'
                    }
                    'kw-s-5': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'd411eda95a734f539b6ae13f68acee80'
                    }
                    'kw-s-6': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'd9b63a99025140cd88e902461267f79e'
                    }
                    'kw-s-7': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '3491f310a71244de9267ff49b0a02fc8'
                    }
                    'kw-s-8': {
                        table: 'x_2112826_fxcm_keyword'
                        id: '7804323a21e4439daecf9e5d25e0d92f'
                    }
                    'kw-s-9': {
                        table: 'x_2112826_fxcm_keyword'
                        id: 'eb1e56f5ea164aed8697c1d4b8821904'
                    }
                    'mod-audit': {
                        table: 'sys_app_module'
                        id: '611aeb34e18e408fa1ba86d252bf44b1'
                    }
                    'mod-cases': {
                        table: 'sys_app_module'
                        id: '47966abc6e354a8281b27d17534bb26e'
                    }
                    'mod-golden': {
                        table: 'sys_app_module'
                        id: 'c1bc847deecb4b689448bdbb958d4705'
                    }
                    'mod-keywords': {
                        table: 'sys_app_module'
                        id: '4e8d1d8315ac409186fd6af57f881a66'
                    }
                    'mod-matches': {
                        table: 'sys_app_module'
                        id: 'd968f6c032da4c7cadcd9da4fe0902ca'
                    }
                    'mod-overview': {
                        table: 'sys_app_module'
                        id: '369c7fbdcde34d748b3d5ea848fa4c92'
                    }
                    'mod-patterns': {
                        table: 'sys_app_module'
                        id: '6d25b20820d844fda04d9f307c1e4b8f'
                    }
                    'mod-portal': {
                        table: 'sys_app_module'
                        id: '2c87bdd0796647a6a045205faf3396d7'
                    }
                    'mod-settings': {
                        table: 'sys_app_module'
                        id: '0dc657e6891a4cea9f1708a8719dcbcb'
                    }
                    'mod-trades': {
                        table: 'sys_app_module'
                        id: 'be7f0747f09b473a9b7baa1c64fa6d9e'
                    }
                    package_json: {
                        table: 'sys_module'
                        id: '32bad4eaf0174a0ea85370672a7d685f'
                    }
                    'pat-1': {
                        table: 'x_2112826_fxcm_trade_id_pattern'
                        id: 'f543a784afce48eb9927f10c006f8dea'
                    }
                    'pat-2': {
                        table: 'x_2112826_fxcm_trade_id_pattern'
                        id: 'be766670fc414f409fa2b1500d8283aa'
                    }
                    'pat-3': {
                        table: 'x_2112826_fxcm_trade_id_pattern'
                        id: '70948b23ecd04cdba2be9e0c105879f1'
                    }
                    'rpt-by-classification': {
                        table: 'sys_report'
                        id: '969c0396ce4648a9a666aa3a57c72fbb'
                    }
                    'rpt-by-source': {
                        table: 'sys_report'
                        id: 'c198a08488bd4dc0b8701edece616c5e'
                    }
                    'rpt-by-state': {
                        table: 'sys_report'
                        id: '74a7a4f77bb7406784a0a729aace3ffb'
                    }
                    'rpt-match-status': {
                        table: 'sys_report'
                        id: '67cab1178ba246e786ac9c475cc31eb7'
                    }
                    'rpt-trades-by-cpty': {
                        table: 'sys_report'
                        id: '225a89a2e0d34db0991e48acd38675f8'
                    }
                    'rpt-trades-by-source': {
                        table: 'sys_report'
                        id: '893328ccf47f494e8b65f2f8187ab7e8'
                    }
                    'sa-graph-sync': {
                        table: 'sysevent_script_action'
                        id: 'a39e6cee78254a62ad32de8a0bb25507'
                    }
                    'sched-graph-sync': {
                        table: 'sysauto_script'
                        id: '6db1712f6a7742ccbaba7364189a9d82'
                    }
                    'sep-audit': {
                        table: 'sys_app_module'
                        id: '5e4f3579502a433cb8e2e1e6a95dd86f'
                    }
                    'sep-config': {
                        table: 'sys_app_module'
                        id: '748666f101654f4b877976aa39f1866f'
                    }
                    'settings-default': {
                        table: 'x_2112826_fxcm_settings'
                        id: '9f6290ef4a4c493381b8642fe8d66657'
                    }
                    'si-attachment-extractor': {
                        table: 'sys_script_include'
                        id: '00effeb9332f4487a48c321e6598fe6f'
                    }
                    'si-audit-service': {
                        table: 'sys_script_include'
                        id: 'fbdd5079b42b4fa1b1b91aac3f8ac1a0'
                    }
                    'si-body-extractor': {
                        table: 'sys_script_include'
                        id: 'dcd6bede1ed04dafa0d5ffd432d6187e'
                    }
                    'si-coercers': {
                        table: 'sys_script_include'
                        id: '72c2db92b1fb481a9b2991945ee063e0'
                    }
                    'si-compare-matcher': {
                        table: 'sys_script_include'
                        id: 'd995633562bd430f98c42cd06350e466'
                    }
                    'si-eml-parser': {
                        table: 'sys_script_include'
                        id: 'fe8acd60f4a64b26bed083fecb9ca8ba'
                    }
                    'si-graph-connector': {
                        table: 'sys_script_include'
                        id: '383ce60dde2c493ea0d92561a712d2d5'
                    }
                    'si-rule-classifier': {
                        table: 'sys_script_include'
                        id: '3229d745d0f24de4800321b75bc2ba7b'
                    }
                    'si-trade-extractor': {
                        table: 'sys_script_include'
                        id: 'ba001370ec5747d2a4daf3480f05f991'
                    }
                    src_server_AttachmentExtractor_server_js: {
                        table: 'sys_module'
                        id: 'd2f932ec89144859a3172f3187f932ba'
                    }
                    src_server_AuditService_server_js: {
                        table: 'sys_module'
                        id: '933e34984eae4c2da4b84ebd64a4ea36'
                    }
                    src_server_BodyExtractor_server_js: {
                        table: 'sys_module'
                        id: '58ff13f868434423828b3b12e3298aba'
                    }
                    'src_server_classify-case_js': {
                        table: 'sys_module'
                        id: 'a6fcc55b69474c228625f04499acd859'
                    }
                    src_server_Coercers_server_js: {
                        table: 'sys_module'
                        id: '9ad0c69b4778428683d85b1b11d82339'
                    }
                    src_server_CompareMatcher_server_js: {
                        table: 'sys_module'
                        id: '840ebcd89f354b0d8039e8b4d043f4d5'
                    }
                    src_server_EmlParser_server_js: {
                        table: 'sys_module'
                        id: 'f160fe00b7774e4e9b5a268f0fb4afad'
                    }
                    'src_server_extract-on-attach_js': {
                        table: 'sys_module'
                        id: '790a308d7e0046efba43f14684cbe4e5'
                    }
                    'src_server_extract-trades_js': {
                        table: 'sys_module'
                        id: '401bc8f86e5d4ce3b097633fd3aeb868'
                    }
                    'src_server_graph-sync_job_js': {
                        table: 'sys_module'
                        id: '4b3e0ef968494138bfc5d3410e8d440f'
                    }
                    'src_server_graph-sync-action_js': {
                        table: 'sys_module'
                        id: 'b9c26a517ab2429aacdaba96490d3f12'
                    }
                    src_server_GraphConnector_server_js: {
                        table: 'sys_module'
                        id: '107f1faca5994e1787c85dbef8ef0245'
                    }
                    'src_server_match-trade_js': {
                        table: 'sys_module'
                        id: '404fe267b5b5451d977dbfe5b167981c'
                    }
                    src_server_RuleClassifier_server_js: {
                        table: 'sys_module'
                        id: '1e819d764f1349acbc51a093a84e7913'
                    }
                    src_server_sp_console_client_js: {
                        table: 'sys_module'
                        id: '4451bfdd346045b3b0381a27f796b83a'
                    }
                    src_server_sp_console_server_js: {
                        table: 'sys_module'
                        id: '215a890d1ee64ff4b27285127adbd8de'
                    }
                    src_server_sp_login_client_js: {
                        table: 'sys_module'
                        id: '2f93f57888d1428ea9f7ebc013ae1fd9'
                    }
                    src_server_TradeExtractor_server_js: {
                        table: 'sys_module'
                        id: '636eda526e374ba3a3556cc97e3a9b9e'
                    }
                }
                composite: [
                    {
                        table: 'sys_dictionary'
                        id: '0034973a80cf41a5a6146de0f2476a55'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_amount'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: '00cbd097f046452f82823c56c1e4eb5e'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'buy_sell'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '029d7d70d4994d749b5731baef186a0d'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'filled_fields'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '036190ddf45546f1826521e458bffeeb'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '03a54edbf019444496f1cbcdd8574c6e'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'order'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '0478c023c5ee4042a162882ca10e9b3d'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'implied_vol'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_section'
                        id: '06ff7c91391d4a1fa25c509809363800'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            caption: 'Classification (set automatically on save)'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '0728da2ca6f64c029df1c85fb7a6199c'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'option_type'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '079ea8329b3848ab8376c64588685dbd'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '07aadfd5d3c54fc78e0835eacbd393d4'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_settle_date'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '09b308d1e2dd4d14a1f720dbd0917c47'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_reason'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '09c275d0a9484f1ba4ea0f330e95b6b5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '0e930ac7597e4e3cbb2c201ca9183d33'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'subject'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '0f6fb0ad68774834bc8b0efdbfcf6a4a'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '103267e1761d4b8b952b5be548f76e7e'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'golden_value'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '12fcb81367434b058617267ba80021f2'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'expiry_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '1324553f13d04f728fbea2d41d2a3827'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'currency_pair'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '13a16e938e5243f6872be18f1c020cc6'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'buy_sell'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '1419789c25cb446994d8e69d57d025f0'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'notional_currency'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '14b79ebb133a47f0875ae57a51b97284'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '15050beb85274bbda3b6e05b2993d516'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'counterparty'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '16a7b8ec59774ab19b0c59802b4d21b6'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'asset_weight'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '16ff18282b954beb962440a0a39ba0d5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '176ece835ff24b159dad7a874e84ca29'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'matched'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '1785635e03424cb2925ad03431f08e73'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'ambiguous_threshold'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '17f33df36b014d83b3cef2999a3ddb42'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'confidence'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '182b9927108c47bc9ee6e328badd8493'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: '18397655fa124d7aa91b7b7456054a15'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '1957a466e5db40188913a57bdae68a0b'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'matched_subject'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '1984b873ebb54446b1498023e6863b9b'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'event_time'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '19eda77330244cc49efe3767683f2604'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'skip_reason'
                            value: 'already_processed'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '1cd0664a63614dc0b09233b28dee82cf'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'trade'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '1d8d11ef39744d0c9ac9b61431219d51'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'notional_amount'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '1dfe65cc63454591bf22f117edb98f43'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trade_date'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '1e1191b935cb47cf85d1faeb5e79bc04'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'skip_reason'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '1e151e20c398448abd27da38d1e8320d'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'sync_frequency_hours'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: '1eaf3ea16c294c8c9d9d355e2b335bb5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '202037d734784bcfbeb35d37bf9ab7fc'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.begin_split'
                            position: '1'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '206b9339f70e4024963de1bf2013d894'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_settle_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '20a2099732544b4286fc838535eba931'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_settle_date'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '20ace28189054f97b385a70fb3864755'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            value: 'ENRICHED'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '20ddca3831ad4a1ab3b9066dadef2e88'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'exercise_style'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '210a74c461a0458fbd81682c47fb8abe'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'exercise_style'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: '219eb3a6cf8c4628a7b755cddf04aee5'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '220e2e45e3d448888da7feab76a3b3df'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '225e9cc99b6442b299da4d6ea34d1f32'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_break_threshold'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '245315375dc9410b87cb931c656546e3'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'classification_reason'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '2598f36d7e454971938a00190caa2f49'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'uti'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '2617f59a6f944fcaaa952607f085adc6'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'currency_pair'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_form_section'
                        id: '2630c1c17fe8477598f8b27808095cde'
                        key: {
                            sys_ui_form: {
                                id: '33f9a2a77f8e48b79fad883a1397d9a4'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '26fe9aa7f55645b89e9b762c39570561'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '272448e952f54dd590f6a87ed450a4fe'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_numeric_tolerance'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '27ad00b9ad374aeba4084756c43a1a67'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'expiry_date'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '27b14d32c3ce4eb99db8ad8d90eaa1d5'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'currency_pair'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '283f4b161b6841a59c3e5cee9f3c546c'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trade_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '29bb330d6b934505be7728454fb84a18'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'source'
                            position: '3'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '29c25d58937648daa556f54fbbef24f6'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'golden_value'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '2a9f3483203c4ad3b760bbba70b8d4c3'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'compared_fields'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '2aa19d905efd4f02963595595a4cdf93'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'book'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '2ae19b964e1240109f72622994851e3a'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'original_label'
                            position: '5'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '2b1e6af9ed9d4aa1a322926597c894db'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                            value: 'IRRELEVANT'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '2d30c2d2878b4ca983a4ec7805c5e284'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'counterparty_code'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '2ef989311036470da231b4987907cea4'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                            value: 'AMBIGUOUS'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '2f32a030a4c0466991611c72d5c036e7'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list'
                        id: '305064260ac34539ab314a78e4732e0a'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                            element: 'NULL'
                            relationship: 'NULL'
                            parent: 'NULL'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '305478a99c8040088260eddcb9edc14b'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'agreed_fields'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '324bbaee7ae3477bb132605236a3709c'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'action'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '3384cdb7713d4a5f8eb69e50aba3d96e'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_ui_form'
                        id: '33f9a2a77f8e48b79fad883a1397d9a4'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '34361e6f3d8a4275aab5c6a3fd22f623'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '348a42c4507c4f7a85d4c4b075c9ed49'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'correlation_id'
                            position: '7'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: '34ab76ff045c4d5298f5108fe00c4782'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '3546a594d95c403f8fdb40793ffc1f84'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            value: 'UNMATCHED'
                        }
                    },
                    {
                        table: 'sys_ui_page'
                        id: '354b1dc97f7b4b42bd3599f05c1f122a'
                        key: {
                            endpoint: 'x_2112826_fxcm_overview.do'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '388e24d36fa64dd5b42d02e5eb2342c0'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_enrich_enabled'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '38a6375314b045138ec93cb5d9e7788a'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'subject_weight'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '38ba18175bad4c2483a9aa2e412017d5'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'settlement_date'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '39481613aa1d4b1dba23516385ae9162'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '39a2101f5f654da3bdde0562464b190c'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'new'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '39c01d36fac04a3986dde9b882e67042'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '3c1976e958e349e786d74ac7229e2276'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'source'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '3c340d4e45db4287806fbe32915715e2'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'extracted_value'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '3daaff4ae14d4e40b0716a8a8dd4cb5a'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'asset_class'
                            position: '5'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '3daf848261f649a38754a605b7f1fa20'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'filled_count'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '3f032bbc841445c2a9dd5fcaf068c578'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'trade_id_weight'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '3fb4204f65f947c092446ea1eb9fef26'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'settlement_status'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '40619f877e064e16b866416a374579b8'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'classification_confidence'
                            position: '3'
                        }
                    },
                    {
                        table: 'sys_rest_message_fn'
                        id: '40aab5809e1548ac90db0f98306fdafb'
                        key: {
                            rest_message: '04bcd25d106e473e98f54ef4a2249ace'
                            function_name: 'GET'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '413bab52a5a845ac86daeac728266989'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'skip_reason'
                            value: 'duplicate'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '4291394a4b9f469fa01a1a367e752fb0'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '767b1378c39b4d67a5dca07492ed617a'
                            position: '0'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '432617fed5f34ca4a28ca7d6b789048a'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                            value: 'success'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '43a80f7cc5d94b07b309bc37828b706c'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'value'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '43c4b00f52d54a84b467948fa674a3c4'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'buy_sell'
                            value: 'Sell'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '45f8b2cbc7914d559bb7da3f99a35062'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_amount'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '466bd649c6fd428abb6cce79c945a303'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source_file'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '468b3208c02c48ec9f74e486969a0fc3'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'delta'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '48025d083d9c4012983efa41eadaeca2'
                        key: {
                            name: 'x_2112826_fxcm_case'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '480897e0420f48319e5929a5f334ec70'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'notional_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '483d96e24a444f96bd41f2b872dc5d29'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'golden_found'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '48e4e04df56942a2a47bc9ab4aab555b'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '492d0beae0834da5b3064292e40d4730'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '4a2b9354b00e45ea86176c0ab10b3237'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'agreed_fields'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '4abc3bf2084e4b0c95759da2d509884b'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.split'
                            position: '4'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '4ad40db0a3974e23a193d71cc4c04d99'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'reviewed_by'
                            position: '2'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4afcf4b88ce543c8ba6b1e5de1959f9c'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'base_currency'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: '4b690f9ff4384e0fb7649f184ba94deb'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'skip_reason'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '4bfe130ecff74408875feb79cd6ad2f2'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'buy_sell'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4c448436eb6248d6b6eb6883b3d35295'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'quote_currency'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '4c68b09124784fd0bebf06ce2e5fbfd5'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                            value: 'skipped'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '4d748a0d90114fe39aebdf6fed57cbde'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                            value: 'reset'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4d7813908e5d4b0fb75e379f7d9f25e3'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4dcca95331be47e9a9101085ee191bf6'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4de246845e1c44378c227fb3a4d2cc54'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'correlation_id'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4e5e1f1808a5486cbf66c08425d808e6'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '4f5a67a43ab64a3997f41517e3cc4aa4'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'pattern'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '4fc241544d6544b99321a03b34a3435f'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'agreed_fields'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '503609de106248cd988016d2384462e9'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '50eeee4ee78143048f51c2193878f352'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                            value: 'IRRELEVANT'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '510a4736dded429ea6d885c99e38402d'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'reviewed_at'
                            position: '3'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5116a77f18724d7cb85e941c55914311'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'trade_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '5192ed47efe1424dbddb5e1f8a3b4ce9'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '5230f1fa79d94c668b8edd2e5c55dfaa'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                            value: 'asset'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5236e2d7a8d4457d8e92cfbc99cd081f'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5240034345bf4024bf7a046bbcda1014'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'message_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_section'
                        id: '52a9c02c5f124ad5949a4dac006ed9f5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            caption: 'Email'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '5411b14b65cd4c04be9d8d7c674ed651'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '5655ff59cf224c51abfc745ba2bd66c4'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'case'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '566c7a7db63d45d395760e40ca6b5dcd'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '574ca52f317b44169fc8c1546214de45'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'notional_amount'
                            language: 'en'
                        }
                    },
                    {
                        table: 'm2m_sp_ng_pro_sp_widget'
                        id: '57afaca100e341f29775c0a08879e54a'
                        key: {
                            sp_widget: 'b11059715c754b7fbf66b702942333b2'
                            sp_angular_provider: '8e311a8a25134b97b29b566a66158858'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '57c886b725ec47929df3b1f1a93f5aea'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'implied_vol'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '57c99094c2c64a96831ed905662c3237'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5841099088764aeea3ec34a97dbb2bad'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trader'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '596c2e602b6c46e3bc14e63b3d74bb68'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'agree'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: '59d4124035914557ad120e2b12233fc7'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '5a9706333d624b3e81dec88206a1bbe2'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'state'
                            position: '7'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '5ace8903a9cf48de8f3dd16b1196a210'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '5ae5ac1fad6e477abbbd21a95f02309a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'skip_reason'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5ba9fb75b0a34bd3afa4c14b4fab55c0'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '5beb4918531644aab8b4daea227f25f4'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'status'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5d2328df1e854b4baf371b3c21c22d90'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'details'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '5ddaa1787551431ab5f9feb572a6507e'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            value: 'MATCHED'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '5f47c1a8eda3477eab9cf370d887cfed'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'actor'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '5fd927bf0cee48fbbc73c574d329d1f0'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '6114dc6c84f14c1899afffbd3d874a1d'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source'
                            value: 'Body'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '618b419ad6504def8b1a46307898b632'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'agree'
                        }
                    },
                    {
                        table: 'sp_page'
                        id: '62522d3ac2294031a8a93dca77fb2a16'
                        key: {
                            id: 'fxcm-console'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '6316859b5b83495f9f9d0b5764dd8536'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'NULL'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: '6335e1e6e35b4e09a0e9676f4df796f7'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '63972caa97cf44508085caa6524e2e59'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'trade_id'
                            position: '4'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '64fb825a52dc4cd8bc78ce2d553ccd30'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'attachment_count'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '6779e0672e3848018e67c56167409364'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '686bedb2fe684715b79560df1dc8b290'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                            value: 'negative'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '6cbe45b6cb7d46eb97ffdf0ad5604fbd'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'matched_subject'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '6d7086a1c572440aa6dbed1715d57335'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'actor'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '6dc36dd3e6e4460a987beee834068fbd'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_amount'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '6eb2d88c07b041f5be4c9ec629671f5a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'received_at'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '6ed904b270fb48cca81a49e9fed134bd'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'attachment_count'
                            position: '7'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '6ef5c16df5374f92902b28f9edb9322d'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'filled_fields'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '7013b0e047274d4ebf3a7dedb7c087be'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'portfolio'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '70cfa184a2e049118c2fa3bfc4bd4acd'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'default_asset_class'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '70de7d28a91b409db82381367f22a872'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'compared_fields'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '71054643d29d4d64b0ed5382cb8dde61'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '7107bc6640994e8f859969492341a82c'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'resource'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '74b2b17c7bc945138f08439de445fc1f'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'classification_label'
                            position: '2'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '75d36fc6666647e0bef61bb84eba9cfe'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'uti'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '7644d050c64742ecbb58977dd1f28609'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'book'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '776904f3c7fe4aad96892296f1f90d70'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'settlement_status'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '778d92e8fab14678a7e57a8b67371646'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'counterparty'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: '77f48ffe8e8b4ccbafe12a4fa72308ac'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '785f19a8130a4f6d86cf7a23ec6cacc5'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'strike_rate'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '79b00f5f4deb46e39d2ab205bad9e102'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'notional_currency'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '7a6ec77619504f5c9a26b41f74a079e8'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                            value: 'AMBIGUOUS'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '7c7b0ad18d6741b4a3dfc087d1ac4de9'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'confidence'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '7cad3879b48f4cd5b58ddaebd6419bce'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '7e22a8f704ae4350a20d0c23250d7969'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_numeric_tolerance'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '7e5dfa24f1734663bbbfbb0f38d007a5'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.split'
                            position: '6'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '7ec1fc27463d4beab558ddfeb1331e14'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'review_decision'
                            position: '1'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: '7ef941bc508f4c94b6287027c6eeb48f'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '7f4d357432cc44b7afe2de583fa9ff07'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'counterparty_code'
                        }
                    },
                    {
                        table: 'sys_ui_list'
                        id: '7f92f5780c2d4aadaa4ce78478361eeb'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                            element: 'NULL'
                            relationship: 'NULL'
                            parent: 'NULL'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '800d201367524af0bc6840b953721327'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '80d8929e7a3944769841ccf1c8912a9a'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'buy_sell'
                            value: 'Sell'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '80eccad5034143148809461f57086c1c'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'portfolio'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '82138b95a10b4ce0a9f1611247db2b41'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'event_time'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '822d768778184fbbbd9b1bb4cc015a05'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'sender'
                            position: '2'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '82891bfb18364e8985e6eb9a9ce3044c'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '83a01a624eac42f7a1e634cc2872f249'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'message_id'
                            position: '5'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '85c9674fb50044c09bb36854dd299b8f'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'sync_frequency_hours'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '868e8dae3cdc468fbef142069a01277c'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'field'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '879a12b989e84c0595e336fc6ba2bf94'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                            value: 'RELEVANT'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '87b357685d984f50bfc51da413781051'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                            value: 'RELEVANT'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '87e9f765d4eb487ca270d42608445c0d'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'book'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '8acfe3cfcb7548b1be0ec4d8ea41ec7b'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'settlement_date'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '8b232269f1f04f7fb3288091aa52518f'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_enrich_enabled'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '8bdc88f7fc0a4cf0b3d8a7dc99a42dd5'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'settlement_status'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '8d2d4d4846644d6b8d4ba4249ded397a'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'filled_count'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '8d4a3725a19a45e48cd61c62b13e1247'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'golden_found'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '8d775b54c3b545b693259ad21a6480f0'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'match_result'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '8e187007ce3c4124a8611165bf98b98d'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'notional_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '8eb2e3f456ec4651b00d1c60b4389f33'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'classified'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '8ebaf2fa7cf34d96b14115200fee037c'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source_file'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '8f7ee5152cb44edd90c353cb62bcaa06'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'exercise_style'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '8fff0e082e9e414c821794307298e357'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'relevant_threshold'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '90071f76cce448ada9b0120970b392ad'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'subject'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9112687bdf404965be84f230fb523a6f'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'sender'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '91429948855744238833373cbf6bae5b'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'relevant_threshold'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '9211c687be2b4ce6a021fe64bde26441'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'source'
                            value: 'graph'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9242cc21a7a84ed29fa7a48931f074cf'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'ambiguous_threshold'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '924a81446c0d4fa285f93e594232fca4'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'compared_fields'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '92d6cb747037408380f94f77ad0f74ec'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trader'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9335aa0bcfad46349609b6856dd4c11d'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '934ef651eb7342d78d23ee14de72c933'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'classification_confidence'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '938150480f2840f3968c540b65118926'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'source'
                            value: 'local'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '93937c17907848739514d26f436e9d19'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'settlement_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '93a5d62606974ebb81cd553e24d71c51'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'sender'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '94268ea20b8244f4aa6d22ab7cbf03c6'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'matched_asset'
                            position: '8'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: '94975cf78d7842d5ae35d414504d9144'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                            value: 'approve'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '94ccf5fd896a415d8c688848f74c5770'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '94eb6083d531461584fd12dfee7e9b22'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'skip_reason'
                            position: '6'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '95533985024d407380caefe760bf7e9b'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'settlement_status'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9630e4bbcbb24b768f74b8a552a2ce81'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: '968358404f2044ed973e2162dcd99e94'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.end_split'
                            position: '8'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '969acebcf87a4b259af3000f59e4eaa1'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'book'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '96ba42f023ef41a4a0887e1ff1056e06'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '97a3c5ca3c0c4a73a50abceba5c2f3b7'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'buy_sell'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '990f3a5137134c07ad84f9e7fa3f4940'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'exercise_style'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '9b63be8e4bc842faaec09481db3cac13'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'quote_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9b6f41527c484bebbbaa5555b692232d'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trader'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '9b733cde51b14c0c939c292c5fcabb94'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'counterparty'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '9d73df6b5e5f4de692780efdfda29e79'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9d7ae46c8f59469b80fc6d2fbf7ad971'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'extracted_value'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: '9e208ca85d594e49b5e9056a77ad5c2a'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'quote_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: '9e209fbc3f98493b9bb25667dfe01687'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'max_body_scan_chars'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '9e3ce278b87c4a95bb29e70f27db113c'
                        key: {
                            list_id: {
                                id: '7f92f5780c2d4aadaa4ce78478361eeb'
                                key: {
                                    name: 'x_2112826_fxcm_match_result'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'golden_found'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: '9fa6624171ec48fbb51ab9f8adaf7cba'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'strike_rate'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'a0036a88359a4c8cbf493760047334b8'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'strike_rate'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'a11127ec3cdf4255a03d036a74885b36'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'strike_rate'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list'
                        id: 'a11dd4505a20423d848310c840999425'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                            element: 'NULL'
                            relationship: 'NULL'
                            parent: 'NULL'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'a2bc11e9b574415f9dbb53dd30d8abb1'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'attachment_count'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'a34997dfa8c04095a21be0a38db8d2fd'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'field'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'a3f77bac999142b2a98a84e64e771db6'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trade_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'a4763005ef3b405f8990c560ed391eff'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'message_id'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'a482483225de4f73b079468def9fe806'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.split'
                            position: '4'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'a55f7bd94fd24c53b5ab0d3b862bc07d'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'uti'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: 'a5b8ede758c74f7498362a490343d447'
                        key: {
                            name: 'x_2112826_fxcm_case'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'a6f81e0ec13d47e28a43c649ecbcc028'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'a7ca3f592faf4501a085b61214dedc00'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'notional_currency'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'abb1bfd46fd84d878d9fdd5571f10c0e'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'expiry_date'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'acce9597120544a3abd3a9aed2866c06'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'adbc9c07fddf494c9291c063bbcfc185'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'adcbfc30716e4a02a5d176599a9ffe64'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'received_at'
                            position: '6'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'adf5a5d1497d452eacd4449636e8ce1b'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'resource'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ae0f25cd5e8d44659b4ef52f6711158a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'correlation_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_form_section'
                        id: 'ae1bb20656824a478ae7a1cc2acd185f'
                        key: {
                            sys_ui_form: {
                                id: '33f9a2a77f8e48b79fad883a1397d9a4'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ae582767d90a40a683c60407652d2109'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'correlation_id'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'aea05f11663f4c9295dfffc897ad80a4'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'implied_vol'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'af9baea9d5e84a3d87766f90d34e98fe'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_fields'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: 'b00663f94fed4b8f92d637573127a61b'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'b14b866b48db421595d93dc9b01e1563'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'base_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'b1a2bfac50184e779f7845587109bf17'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_currency'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'b25530b873fa4601b5e9fa9a187d7678'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'order'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'b391e42adf554cedadfaed1aa16dd0eb'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'uti'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'b422c7d709804c0a8fa73b6025bb6a2f'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'buy_sell'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'b439828811d143908598ad694298efe0'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'b69eed60d1934d84bfee728773c078c5'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.end_split'
                            position: '10'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'b7406f4404544e549359303d694b99db'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'trader'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'b7a9e66b030247da825f030188489abe'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'received_at'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sp_page'
                        id: 'b8c044d32241460d8192d9e7ec6ff815'
                        key: {
                            id: 'fxcm-login'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'ba14ea37f76e45c69e6735735e8c82ce'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'matched_subject'
                            position: '9'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: 'bbc1e990795b41a5b57a5255c5caab5c'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'bc9cbb36912345df868d4eaa17a34922'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'counterparty'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'bcd4dc8677f346dba1d13c749ebd0221'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'NULL'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'bdece81f64a342d7998aa636c5ea04bd'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'body'
                            position: '9'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'bf2f09d6a1d7462b903797ee8cd0feaa'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'action'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'bf3139845bea46cd800729e06d08eb26'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'currency_pair'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'bf55b1508ea947359b7f48104f67d985'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'bfd02f698ad4469284cc06dd2b0974a5'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'expiry_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c029f18f9d094b8daf2106803b75b9c6'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'subject_weight'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c05357f37b0445f0b7496d3f33cc7c11'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'quote_currency'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'c0a57c63f42341bdaf8371a16ad3e88b'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c233304eb11d42daa8b7ad0a59f2efe5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'reviewed_at'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'c256df9e0fb04edfb6b3b73c4a4a2582'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                            value: 'subject'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'c2736bfe2fd242a494c8a2e7d4510a38'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.end_split'
                            position: '8'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c380cb0885c3439dacfb7b67bb6ffa3a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_label'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c3822eeb1b1e40dcb273bf7da0a146ca'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'confidence'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c3af01e8f5c245bfb4965780375018ea'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'default_asset_class'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c40739d93a0b49baa1b7a0636f44b08c'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'max_body_scan_chars'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'c420b047c8634c91be6603db2c1724b8'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'in_review'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c43d7c445ebd410f8d51acdb5e72c4c0'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'trade_id_weight'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c463586cb4bb44a0b7a4c3dee50d6828'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'currency_pair'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c5383189043c4193b49320b74663237b'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'option_type'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c5ebf9d9ecbe452f89acaeb68b1d693f'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'trade'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c637adc8205041bfb7e7a5c524749868'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'reviewed_by'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'c698cfd6742b42ac8b9a001a8bf5fa06'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'base_currency'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'c6baaafe511d49d4b44429abef6099b2'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'portfolio'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'c7911af099f4420a8ce7a7582e84cec9'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'notional_amount'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'cb8edc3daa6e4d93a1cb242455df7e73'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'outcome'
                            value: 'failure'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'cbb25e6dfe85467a9ece23cc98403908'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_break_threshold'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'cbe537787b2d4b2f84bf1899a07f3b2a'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'case'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'cbff5bace44d47c780a52ea100188633'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'buy_sell'
                            value: 'Buy'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ccf5064668ef4d2782eb832ec139b138'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'correlation_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'cd8618eb9a0048aa81eca5c6dfc7d323'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'state'
                        }
                    },
                    {
                        table: 'sys_rest_message_fn'
                        id: 'cee060998c0544e38603325e636c395d'
                        deleted: true
                        key: {
                            rest_message: 'fx-graph-rest-msg'
                            function_name: 'GET'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'cee33b24df534a208e929034411faaa4'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'closed'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'cfc6c227231e446ab1047648ecbc2795'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'match_fields'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'd205cf32a598451b80e640bd9558e5cd'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'classification_label'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: 'd34eee5464bc41058de7aac451ba79c7'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'd3fbb2c2986940f2b1aa2b83d7638d49'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'strike_rate'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'd3ff3acd91b04d249deed08df95aa592'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'body'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'd5293d533f9348b08bd264f2ea1ce07f'
                        key: {
                            name: 'x_2112826_fxcm_trade_id_pattern'
                            element: 'pattern'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'd617056ed4d64fbe8647f4104f79b4e9'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'state'
                            value: 'extracted'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'd86e8c3c68ed466ea64c6b46d6bdca5f'
                        key: {
                            sys_ui_section: {
                                id: '06ff7c91391d4a1fa25c509809363800'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Classification (set automatically on save)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'classification_reason'
                            position: '11'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'd8b015dfbb0d4b398ea727416c481055'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'settlement_date'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'd8d80e39202a4240b2dccc0292ae0e75'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'premium_currency'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'da5190c61b9d446a88577f42b6712019'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'value'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: 'daefe735129344c99b233b2c95f9cef1'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: 'db8fe43831a8459a8b8525a3fc447259'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'dc6ef1b306144fd9a13298177d19ee33'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'trade'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'dc8cfcc8e6634eed9e013e4fd3ff9318'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'message_id'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'dcd5036826e846e098e544b897b6b897'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'body'
                        }
                    },
                    {
                        table: 'sys_ui_form_section'
                        id: 'dd64efd732c74242972e622f63126968'
                        key: {
                            sys_ui_form: {
                                id: '33f9a2a77f8e48b79fad883a1397d9a4'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                        }
                    },
                    {
                        table: 'm2m_sp_ng_pro_sp_widget'
                        id: 'de04e30ed7694e8e89bf61655dc45b33'
                        key: {
                            sp_widget: 'b11059715c754b7fbf66b702942333b2'
                            sp_angular_provider: 'ee3307e865e04ce887b40b40c7044c4a'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'e0184ee9af284c5eb80b20086cbd609a'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'option_type'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e0e9957e3b044f4790b7b262c1b62c02'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'implied_vol'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e117f19b15584d82b1b6c4e691ca8cea'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'trade_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'e16f074362344ad098dff566d162c919'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'e222830653b842bc9bbc2bf4b69ac2b7'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e30e0044ef9343f5b82b4a98a5df5ebd'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'e3c6caf440fc43e18805e0367ab2ff74'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'source'
                            value: 'Attachment'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'e4874886fd4a45dfa6ffdfc1deffbb22'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            value: 'NEAR_MATCH'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'e500691afcb84a088fbf51f29e740953'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'buy_sell'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e5ec2d845c01417689d4a0825bd778d8'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_settle_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'e6501bdd568e44eab289251a1c924aa7'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'asset_class'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e7170d4919ec49c0a69e12c0a30a1ee8'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'buy_sell'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e98e799a14114842ab8a6e3be2fe7925'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'reviewed_at'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'e9a7d349b85b413b9cec3c85b3d69b8f'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'source'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'e9fd993cb8fc49679b1131f725d8eebf'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'filled_count'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_section'
                        id: 'ea1779caa25044eb82e7fd07211f907a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            caption: 'Review (Human-in-the-loop)'
                            view: {
                                id: 'Default view'
                                key: {
                                    name: 'NULL'
                                }
                            }
                            sys_domain: 'global'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'eaa9a2d3e3b04f8ba38b2925f1b2667b'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trade_date'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'ebfc4df43d774ecb97b40dff9668a6ba'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'buy_sell'
                            value: 'Buy'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ec463eb1228243d0b5f4b8c97eeeacb3'
                        key: {
                            name: 'x_2112826_fxcm_audit_event'
                            element: 'details'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ec6c7c1e11874acaa07a2a106eb1c704'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'delta'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ed6e47c4f0ec493eb905d33f08e7fa87'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'matched_asset'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ed745d08dec14c818c177846b1267374'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'delta'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ee2cdfdb5bd54ce5b998a0e81ca9f379'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'premium_amount'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ee5db163cb34487181abbf58faf14617'
                        key: {
                            name: 'x_2112826_fxcm_settings'
                            element: 'asset_weight'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ee80917092ba4b7cb9165071d85d7f5f'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'counterparty_code'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ee899ebc7d2349c398ba5af5ef9cef0f'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_confidence'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'eed937a6c7b34b55a84ba00d262cf7ad'
                        key: {
                            list_id: {
                                id: '305064260ac34539ab314a78e4732e0a'
                                key: {
                                    name: 'x_2112826_fxcm_trade'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'counterparty'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'ef795597c9f847e683e266320ae5f73f'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'base_currency'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'f1aebe6f424648bebba683db49c0e5f9'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trade_id'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f39fd8e60b65407f9e69ef3bccbeca36'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'notional_amount'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'f41b89fb2b274aae88d8b556ae059629'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'original_label'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'f4847c4fc345415dba1e4e0088e200bc'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'option_type'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_ui_list_element'
                        id: 'f4f9d7236d1c44668c52e54fd04f8113'
                        key: {
                            list_id: {
                                id: 'a11dd4505a20423d848310c840999425'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                    element: 'NULL'
                                    relationship: 'NULL'
                                    parent: 'NULL'
                                }
                            }
                            element: 'subject'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f54765eed8f8419eb6595d433b536d4e'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'notional_amount'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'f560a3d660e1495da12eddfcb586af37'
                        key: {
                            sys_ui_section: {
                                id: 'ea1779caa25044eb82e7fd07211f907a'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Review (Human-in-the-loop)'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.begin_split'
                            position: '0'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'f6172128fad84e7fad12d42464337d3c'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'review_decision'
                            value: 'decline'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f62f415c0f1848db908e949f26f09220'
                        key: {
                            name: 'x_2112826_fxcm_field_diff'
                            element: 'match_result'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f6650f60ba9c419ebed8bfb446215fe5'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'reviewed_by'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'f665abab317848ee9704477722f88074'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'counterparty_code'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'f733b99849cd46acbe55173a5ef99740'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'asset_class'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f84cca6ba8a64fc7bd38cd856091d2ab'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'portfolio'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'f8af479a91354bf3b5879eba42e5f58b'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'f927604c12b14702a8a35f5b13b5a514'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: '.begin_split'
                            position: '0'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'f9461752b505450ab7907261511559fa'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'case'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice_set'
                        id: 'f9ebc59cea6c4526ab6fdba5129dab73'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                            element: 'type'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'fa0bf042b35f47529c70b3b274bd0a3d'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'delta'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'fa6b4155c0f0459d98605d5cb72092e2'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trade_id'
                        }
                    },
                    {
                        table: 'sys_ui_element'
                        id: 'fae2d440003441948a01562444bd6d30'
                        key: {
                            sys_ui_section: {
                                id: '52a9c02c5f124ad5949a4dac006ed9f5'
                                key: {
                                    name: 'x_2112826_fxcm_case'
                                    caption: 'Email'
                                    view: {
                                        id: 'Default view'
                                        key: {
                                            name: 'NULL'
                                        }
                                    }
                                    sys_domain: 'global'
                                }
                            }
                            element: 'subject'
                            position: '1'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'fb449a1036ce48498cbd458300abf27a'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_reason'
                            language: 'en'
                        }
                    },
                    {
                        table: 'ua_table_licensing_config'
                        id: 'fb9111113de1497da4da79e156ae5320'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'fbd44aec6796480aac15c33fbbdd470d'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'fc69af03877d49f2acce29d6a40f3ff1'
                        key: {
                            name: 'x_2112826_fxcm_trade'
                            element: 'trade_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_choice'
                        id: 'fc8e66049acc4db09549f658f032dc91'
                        key: {
                            name: 'x_2112826_fxcm_match_result'
                            element: 'status'
                            value: 'BREAK'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'feb47f7cfd364593a2769edfe3ad40f6'
                        key: {
                            name: 'x_2112826_fxcm_golden_trade'
                            element: 'settlement_date'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_dictionary'
                        id: 'ff69119f0b314af3b032a3e46bdbebc1'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'classification_confidence'
                        }
                    },
                    {
                        table: 'sys_documentation'
                        id: 'fff424ebc2c244a0bfe95e92bd7ee858'
                        key: {
                            name: 'x_2112826_fxcm_case'
                            element: 'matched_asset'
                            language: 'en'
                        }
                    },
                    {
                        table: 'sys_db_object'
                        id: 'ffff8f2f8852404ca383105cc944edff'
                        key: {
                            name: 'x_2112826_fxcm_keyword'
                        }
                    },
                ]
            }
        }
    }
}

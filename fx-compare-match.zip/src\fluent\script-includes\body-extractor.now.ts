import { ScriptInclude } from '@servicenow/sdk/core'

/** BodyExtractor — parse single-trade fields from subject + body. */
ScriptInclude({
    $id: Now.ID['si-body-extractor'],
    name: 'BodyExtractor',
    active: true,
    apiName: 'x_2112826_fxcm.BodyExtractor',
    description: 'Parse a single-trade settlement email body into a canonical trade object (port of body_extractor.py).',
    script: Now.include('../../server/BodyExtractor.server.js'),
})

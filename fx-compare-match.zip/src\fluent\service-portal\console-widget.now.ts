import { SPWidget } from '@servicenow/sdk/core'
import { fileChangeDirective, fileDropDirective } from './sp-directives.now'

/**
 * FX Compare & Match Console — the single-page app widget that replicates the
 * agentic-workflows front-end (Sync → Classify → Extract → Recon) plus the
 * Configure Workflows and Settings views, in Nomura colours. Reads the pipeline
 * tables via its server script; all interaction is AngularJS in the client.
 */
export const consoleWidget = SPWidget({
    $id: Now.ID['fxcm_console_widget'],
    name: 'FX Compare & Match Console',
    id: 'fxcm-console',
    serverScript: Now.include('../../server/sp/console.server.js'),
    clientScript: Now.include('../../server/sp/console.client.js'),
    htmlTemplate: Now.include('../../server/sp/console.html'),
    customCss: Now.include('../../server/sp/console.css'),
    angularProviders: [fileChangeDirective, fileDropDirective],
    hasPreview: false,
})

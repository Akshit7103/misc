/**
 * BodyExtractor — parse the fields of a single-trade settlement email from its
 * subject + "Trade Details" body block. Direct port of body_extractor.py.
 * Output uses the canonical FX Trade / golden-source field names so a
 * body-parsed trade and a spreadsheet-parsed trade compare apples-to-apples.
 * Script Include class file — Glide APIs auto-available; do not import.
 */
var BodyExtractor = Class.create();
BodyExtractor.prototype = {
    initialize: function () {
        this.c = new x_2112826_fxcm.Coercers();
        this.SYMBOL_MAP = {
            'A$': 'AUD', 'C$': 'CAD', 'NZ$': 'NZD', 'HK$': 'HKD', 'S$': 'SGD',
            '$': 'USD', '£': 'GBP', '€': 'EUR', '¥': 'JPY', 'kr': 'SEK', 'CHF': 'CHF',
        };
    },

    // Grab a "Label: value" line value (same line only).
    _field: function (body, labelRe) {
        var re = new RegExp(labelRe + '\\s*:[^\\S\\n\\r]*([^\\n\\r*]+)', 'i');
        var m = re.exec(body || '');
        if (!m) return null;
        var val = m[1].replace(/\*/g, '').trim();
        return val || null;
    },

    parse: function (subject, body, tradeId) {
        subject = subject || '';
        body = body || '';
        var full = subject + ' ' + body;
        var out = {};
        if (tradeId) out.trade_id = tradeId;

        // Currency pair — subject (EUR/USD) first, then a body "Currency Pair:" line
        var pair = null;
        var m = subject.match(/\b([A-Z]{3})\/([A-Z]{3})\b/);
        if (m) pair = m[0];
        if (!pair) {
            var bp = body.match(/Currency\s*Pair\s*:[^\S\n\r]*([A-Z]{3}\/[A-Z]{3})/i);
            if (bp) pair = bp[1].toUpperCase();
        }
        if (pair) {
            out.currency_pair = pair;
            out.base_currency = pair.split('/')[0];
            out.quote_currency = pair.split('/')[1];
        }

        // UTI
        m = full.match(/\bUTI[A-Z0-9]{6,}\b/);
        if (m) out.uti = m[0];

        // Trade date from subject: dd_mm_yy | dd/mm/yy | dd/mm/yyyy | yyyy-mm-dd
        var td = null;
        m = subject.match(/\b(\d{2})_(\d{2})_(\d{2,4})\b/);
        if (m) { var yr = m[3].length === 2 ? '20' + m[3] : m[3]; td = m[1] + '/' + m[2] + '/' + yr; }
        if (!td) { m = subject.match(/\b(\d{2})\/(\d{2})\/(\d{4})\b/); if (m) td = m[1] + '/' + m[2] + '/' + m[3]; }
        if (!td) { m = subject.match(/\b(\d{2})\/(\d{2})\/(\d{2})\b/); if (m) td = m[1] + '/' + m[2] + '/20' + m[3]; }
        if (!td) { m = subject.match(/\b(\d{4}-\d{2}-\d{2})\b/); if (m) td = m[1]; }
        if (td) out.trade_date = this.c.coerceDate(td);

        // Body fields
        var bs = this._field(body, 'Buy\\s*/\\s*Sell');
        if (bs) out.buy_sell = bs;
        var cp = this._field(body, 'Counterparty');
        if (cp) out.counterparty = cp;
        var vd = this._field(body, 'Value\\s*Date');
        if (vd && vd.length > 2) out.settlement_date = this.c.coerceDate(vd);

        // Amount -> notional_amount (+ notional_currency from code or symbol)
        var amountRaw = this._field(body, 'Amount');
        if (amountRaw) {
            var ccy = null;
            var code = amountRaw.match(/^([A-Z]{3})\b/);
            if (code) {
                ccy = code[1];
            } else {
                var sym = amountRaw.match(/^(NZ\$|HK\$|A\$|C\$|S\$|\$|£|€|¥|kr|CHF)/);
                if (sym) ccy = this.SYMBOL_MAP[sym[1]];
            }
            var num = amountRaw
                .replace(/^[A-Z]{3}\s*/, '')
                .replace(/^(NZ\$|HK\$|A\$|C\$|S\$|\$|£|€|¥|kr|CHF)\s*/, '')
                .trim();
            out.notional_amount = this.c.coerceNumber(num);
            out.notional_currency = out.base_currency || ccy || '';
        }

        return out;
    },

    type: 'BodyExtractor',
};

import {
    Table,
    StringColumn,
    BooleanColumn,
    ReferenceColumn,
} from '@servicenow/sdk/core'

/**
 * Field Diff — per-field comparison of an extracted trade vs the golden record
 * (child of Match Result). Replaces the FieldDiff list.
 */
export const x_2112826_fxcm_field_diff = Table({
    name: 'x_2112826_fxcm_field_diff',
    label: 'Field Diff',
    display: 'field',
    schema: {
        match_result: ReferenceColumn({
            label: 'Match Result',
            referenceTable: 'x_2112826_fxcm_match_result',
            cascadeRule: 'cascade',
        }),
        field: StringColumn({ label: 'Field', maxLength: 60 }),
        extracted_value: StringColumn({ label: 'Extracted Value', maxLength: 255 }),
        golden_value: StringColumn({ label: 'Golden Value', maxLength: 255 }),
        agree: BooleanColumn({ label: 'Agree' }),
    },
})

import { Record } from '@servicenow/sdk/core'

/**
 * Field styles (sys_ui_style) — colour-code the classification, state and the
 * duplicate flag in lists and forms so triage reads at a glance (green =
 * relevant, amber = ambiguous, red = irrelevant / duplicate).
 */
const CASE = 'x_2112826_fxcm_case'

// Classification label
Record({ $id: Now.ID['fs-label-relevant'], table: 'sys_ui_style', data: { name: CASE, element: 'classification_label', value: 'RELEVANT', style: 'background-color:#c7ecd2;color:#0a6b2e;font-weight:600;' } })
Record({ $id: Now.ID['fs-label-ambiguous'], table: 'sys_ui_style', data: { name: CASE, element: 'classification_label', value: 'AMBIGUOUS', style: 'background-color:#fdebc8;color:#9a6700;font-weight:600;' } })
Record({ $id: Now.ID['fs-label-irrelevant'], table: 'sys_ui_style', data: { name: CASE, element: 'classification_label', value: 'IRRELEVANT', style: 'background-color:#f9d2d0;color:#b42318;font-weight:600;' } })

// State
Record({ $id: Now.ID['fs-state-classified'], table: 'sys_ui_style', data: { name: CASE, element: 'state', value: 'classified', style: 'background-color:#e0ebff;color:#1a47b8;' } })
Record({ $id: Now.ID['fs-state-closed'], table: 'sys_ui_style', data: { name: CASE, element: 'state', value: 'closed', style: 'background-color:#eceff3;color:#566173;' } })
Record({ $id: Now.ID['fs-state-matched'], table: 'sys_ui_style', data: { name: CASE, element: 'state', value: 'matched', style: 'background-color:#c7ecd2;color:#0a6b2e;' } })

// Skip reason (duplicate stands out)
Record({ $id: Now.ID['fs-skip-duplicate'], table: 'sys_ui_style', data: { name: CASE, element: 'skip_reason', value: 'duplicate', style: 'background-color:#f9d2d0;color:#b42318;font-weight:600;' } })

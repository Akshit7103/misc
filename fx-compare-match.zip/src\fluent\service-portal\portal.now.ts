import { ServicePortal } from '@servicenow/sdk/core'
import { nomuraTheme } from './theme.now'
import { appPage } from './app-page.now'
import { loginPage } from './login-page.now'

/**
 * FX Compare & Match portal — reachable at /fxcm. Console home page, branded
 * Nomura login page for unauthenticated users, Nomura theme, portal name hidden
 * (the widgets render their own brand).
 */
export const fxcmPortal = ServicePortal({
    $id: Now.ID['fxcm_portal'],
    title: 'FX Compare & Match',
    urlSuffix: 'fxcm',
    theme: nomuraTheme,
    homePage: appPage,
    loginPage: loginPage,
    hidePortalName: true,
})

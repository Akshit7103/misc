/**
 * Coercers — shared value normalization used by the body and attachment
 * extractors and by Compare & Match. Port of the _coerce_date / _coerce_number
 * helpers in attachment_extractor.py.
 *
 * coerceDate returns ISO 'yyyy-MM-dd' (so it stores cleanly into a glide date
 * field and compares apples-to-apples), or '' if it can't parse the input.
 * Script Include class file — Glide APIs are auto-available; do not import.
 */
var Coercers = Class.create();
Coercers.prototype = {
    initialize: function () {
        this.MONTHS = {
            jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
            jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
        };
    },

    coerceDate: function (v) {
        if (v === null || v === undefined) return '';
        var s = ('' + v).trim();
        if (!s) return '';
        var m;
        // DD-Mon-YYYY / DD-Mon-YY / "13 October 2026"
        m = s.match(/^(\d{1,2})[-\s]([A-Za-z]{3})[A-Za-z]*[-\s](\d{2,4})$/);
        if (m) return this._iso(m[3], this.MONTHS[m[2].toLowerCase()], m[1]);
        // YYYY-MM-DD
        m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (m) return this._iso(m[1], m[2], m[3]);
        // DD/MM/YYYY or DD/MM/YY  (day-first, matching the generator)
        m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
        if (m) return this._iso(m[3], m[2], m[1]);
        // DD-MM-YYYY or DD-MM-YY
        m = s.match(/^(\d{1,2})-(\d{1,2})-(\d{2,4})$/);
        if (m) return this._iso(m[3], m[2], m[1]);
        return ''; // unrecognised → leave the date empty rather than store junk
    },

    _iso: function (y, mo, d) {
        if (!mo) return '';
        y = '' + y;
        if (y.length === 2) y = '20' + y;
        mo = ('0' + mo).slice(-2);
        d = ('0' + d).slice(-2);
        return y + '-' + mo + '-' + d;
    },

    coerceNumber: function (v) {
        if (v === null || v === undefined) return '';
        if (typeof v === 'number') return v;
        var s = ('' + v).trim().replace(/,/g, '').replace(/\s/g, '');
        if (s === '') return '';
        var neg = s.charAt(0) === '(' && s.charAt(s.length - 1) === ')';
        if (neg) s = s.substring(1, s.length - 1);
        s = s.replace(/%$/, '');
        var f = parseFloat(s);
        if (isNaN(f)) return '';
        return neg ? -f : f;
    },

    type: 'Coercers',
};

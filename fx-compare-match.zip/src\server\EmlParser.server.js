/**
 * EmlParser — parses a raw .eml (RFC-822 / MIME) string into a uniform object:
 *   { subject, sender, date, body, attachments: [{filename, contentType, base64|text}] }
 * Handles multipart (mixed/alternative, nested), base64 + quoted-printable
 * transfer encodings, MIME encoded-word headers, and attachment extraction.
 * The agentic-workflows LocalEmailConnector equivalent, for browser-uploaded files.
 */
var EmlParser = Class.create();
EmlParser.prototype = {
    initialize: function () {},

    parse: function (raw) {
        raw = ('' + (raw || '')).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        var ent = this._parseEntity(raw);
        var result = { subject: '', sender: '', date: null, body: '', _html: '', attachments: [] };
        result.subject = this._decodeWord(ent.headers['subject'] || '');
        result.sender = this._extractFrom(this._decodeWord(ent.headers['from'] || ''));
        result.date = this._parseDate(ent.headers['date'] || '');
        this._collect(ent, result);
        if (!result.body && result._html) result.body = this._stripHtml(result._html);
        delete result._html;
        return result;
    },

    _parseEntity: function (raw) {
        var idx = raw.indexOf('\n\n');
        var headerText, body;
        if (idx === -1) { headerText = raw; body = ''; }
        else { headerText = raw.substring(0, idx); body = raw.substring(idx + 2); }
        var headers = this._parseHeaders(headerText);
        var ent = { headers: headers, body: body, parts: [], multipart: false };
        var ct = headers['content-type'] || 'text/plain';
        if (/multipart\//i.test(ct)) {
            var b = ct.match(/boundary="?([^";]+)"?/i);
            if (b) {
                ent.multipart = true;
                var segs = body.split('--' + b[1]);
                for (var i = 0; i < segs.length; i++) {
                    if (i === 0) continue;                  // preamble
                    var seg = segs[i];
                    if (seg.indexOf('--') === 0) continue;  // closing boundary
                    seg = seg.replace(/^\n/, '');
                    if (seg.replace(/\s/g, '') === '') continue;
                    ent.parts.push(this._parseEntity(seg));
                }
            }
        }
        return ent;
    },

    _collect: function (ent, result) {
        if (ent.multipart) {
            for (var i = 0; i < ent.parts.length; i++) this._collect(ent.parts[i], result);
            return;
        }
        var ct = (ent.headers['content-type'] || 'text/plain').toLowerCase();
        var disp = (ent.headers['content-disposition'] || '').toLowerCase();
        var enc = (ent.headers['content-transfer-encoding'] || '7bit').toLowerCase();
        var filename = this._filename(ent.headers);

        var isAttachment = disp.indexOf('attachment') !== -1 ||
            (filename && ct.indexOf('text/') !== 0) ||
            ct.indexOf('application/') === 0 || ct.indexOf('octet') !== -1;

        if (isAttachment && filename) {
            var contentType = (ent.headers['content-type'] || 'application/octet-stream').split(';')[0].trim();
            if (enc === 'base64') {
                result.attachments.push({ filename: filename, contentType: contentType, base64: ent.body.replace(/\s+/g, '') });
            } else {
                var txt = enc === 'quoted-printable' ? this._decodeQP(ent.body) : ent.body;
                result.attachments.push({ filename: filename, contentType: contentType, text: txt });
            }
            return;
        }

        var charset = (ct.match(/charset="?([^";]+)"?/i) || [])[1] || '';
        var isUtf8 = /utf-?8/i.test(charset) || !charset;
        var content = ent.body;
        if (enc === 'base64') { content = this._b64ToText(content); if (isUtf8) content = this._utf8(content); }
        else if (enc === 'quoted-printable') { content = this._decodeQP(content); if (isUtf8) content = this._utf8(content); }
        // 7bit / 8bit: already decoded as UTF-8 when the file was read — leave as-is

        if (ct.indexOf('text/html') === 0) result._html += content;
        else result.body += (result.body ? '\n' : '') + content;   // text/plain (or default)
    },

    _parseHeaders: function (text) {
        var lines = text.split('\n');
        var headers = {}, cur = null;
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            if (/^[ \t]/.test(line) && cur) { headers[cur] += ' ' + line.replace(/^[ \t]+/, ''); continue; }
            var m = line.match(/^([!-9;-~]+):[ \t]?(.*)$/);
            if (m) { cur = m[1].toLowerCase(); headers[cur] = m[2]; }
        }
        return headers;
    },

    _filename: function (headers) {
        var cd = headers['content-disposition'] || '';
        var m = cd.match(/filename\*?="?([^";]+)"?/i);
        if (m) return this._decodeWord(m[1]);
        var ct = headers['content-type'] || '';
        var n = ct.match(/name\*?="?([^";]+)"?/i);
        if (n) return this._decodeWord(n[1]);
        return '';
    },

    _extractFrom: function (from) {
        var m = from.match(/<([^>]+)>/);
        if (m) {
            var name = from.replace(/<[^>]+>/, '').replace(/"/g, '').trim();
            return name ? (name + ' <' + m[1] + '>') : m[1];
        }
        return from.trim();
    },

    _decodeWord: function (s) {
        if (!s) return '';
        var self = this;
        return s.replace(/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/g, function (whole, charset, enc, data) {
            try {
                var bytes;
                if (enc.toUpperCase() === 'B') {
                    bytes = self._b64ToText(data);
                } else {
                    bytes = data.replace(/_/g, ' ').replace(/=([0-9A-Fa-f]{2})/g, function (m2, h) {
                        return String.fromCharCode(parseInt(h, 16));
                    });
                }
                return /utf-?8/i.test(charset) ? self._utf8(bytes) : bytes;
            } catch (e) { return data; }
        });
    },

    /* Reassemble a byte-string (each char 0-255) decoded as UTF-8 into Unicode. */
    _utf8: function (s) {
        var out = '', i = 0, n = s.length, c1, c2, c3, c4, cp;
        while (i < n) {
            c1 = s.charCodeAt(i++);
            if (c1 < 0x80) { out += String.fromCharCode(c1); }
            else if (c1 >= 0xC0 && c1 < 0xE0) { c2 = s.charCodeAt(i++) || 0; out += String.fromCharCode(((c1 & 0x1F) << 6) | (c2 & 0x3F)); }
            else if (c1 >= 0xE0 && c1 < 0xF0) { c2 = s.charCodeAt(i++) || 0; c3 = s.charCodeAt(i++) || 0; out += String.fromCharCode(((c1 & 0x0F) << 12) | ((c2 & 0x3F) << 6) | (c3 & 0x3F)); }
            else if (c1 >= 0xF0) {
                c2 = s.charCodeAt(i++) || 0; c3 = s.charCodeAt(i++) || 0; c4 = s.charCodeAt(i++) || 0;
                cp = (((c1 & 0x07) << 18) | ((c2 & 0x3F) << 12) | ((c3 & 0x3F) << 6) | (c4 & 0x3F)) - 0x10000;
                out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
            } else { out += String.fromCharCode(c1); }
        }
        return out;
    },

    _decodeQP: function (s) {
        return ('' + s).replace(/=\n/g, '').replace(/=([0-9A-Fa-f]{2})/g, function (m, h) {
            return String.fromCharCode(parseInt(h, 16));
        });
    },

    _b64ToText: function (b64) {
        b64 = ('' + (b64 || '')).replace(/\s+/g, '');
        if (!b64) return '';
        try { return GlideStringUtil.base64Decode(b64); } catch (e) { return ''; }
    },

    _stripHtml: function (h) {
        return ('' + h)
            .replace(/<style[\s\S]*?<\/style>/gi, '')
            .replace(/<script[\s\S]*?<\/script>/gi, '')
            .replace(/<\/(p|div|tr|br|li|h[1-6])>/gi, '\n')
            .replace(/<[^>]+>/g, '')
            .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
            .replace(/\n{3,}/g, '\n\n').trim();
    },

    _parseDate: function (d) {
        if (!d) return null;
        var months = { jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06', jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12' };
        var m = d.match(/(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?/);
        if (!m) return null;
        var mon = months[m[2].toLowerCase()];
        if (!mon) return null;
        var day = ('0' + m[1]).slice(-2);
        return m[3] + '-' + mon + '-' + day + ' ' + m[4] + ':' + m[5] + ':' + (m[6] || '00');
    },

    type: 'EmlParser'
};

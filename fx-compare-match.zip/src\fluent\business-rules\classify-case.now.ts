import { BusinessRule } from '@servicenow/sdk/core'

/**
 * Classify Case — before-insert business rule that scores every new FX Case
 * with the RuleClassifier and stamps the label/confidence/reason/trade id.
 */
BusinessRule({
    $id: Now.ID['br-classify-case'],
    name: 'Classify & Deduplicate Case',
    table: 'x_2112826_fxcm_case',
    when: 'before',
    action: ['insert'],
    order: 100,
    active: true,
    script: Now.include('../../server/classify-case.js'),
})

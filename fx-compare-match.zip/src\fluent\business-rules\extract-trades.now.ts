import { BusinessRule } from '@servicenow/sdk/core'

/**
 * Extract Trades — after-insert rule that turns a RELEVANT, non-duplicate case
 * into FX Trade rows via the TradeExtractor.
 */
BusinessRule({
    $id: Now.ID['br-extract-trades'],
    name: 'Extract Trades',
    table: 'x_2112826_fxcm_case',
    when: 'after',
    action: ['insert'],
    order: 200,
    active: true,
    script: Now.include('../../server/extract-trades.js'),
})

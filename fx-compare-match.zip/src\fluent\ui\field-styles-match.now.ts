import { Record } from '@servicenow/sdk/core'

/**
 * Field styles for Match Result status — green Matched, blue Enriched,
 * amber Near-match, red Break, grey Unmatched. Reads at a glance in lists.
 */
const MR = 'x_2112826_fxcm_match_result'
Record({ $id: Now.ID['fsm-matched'], table: 'sys_ui_style', data: { name: MR, element: 'status', value: 'MATCHED', style: 'background-color:#c7ecd2;color:#0a6b2e;font-weight:600;' } })
Record({ $id: Now.ID['fsm-enriched'], table: 'sys_ui_style', data: { name: MR, element: 'status', value: 'ENRICHED', style: 'background-color:#e0ebff;color:#1a47b8;font-weight:600;' } })
Record({ $id: Now.ID['fsm-near'], table: 'sys_ui_style', data: { name: MR, element: 'status', value: 'NEAR_MATCH', style: 'background-color:#fdebc8;color:#9a6700;font-weight:600;' } })
Record({ $id: Now.ID['fsm-break'], table: 'sys_ui_style', data: { name: MR, element: 'status', value: 'BREAK', style: 'background-color:#f9d2d0;color:#b42318;font-weight:600;' } })
Record({ $id: Now.ID['fsm-unmatched'], table: 'sys_ui_style', data: { name: MR, element: 'status', value: 'UNMATCHED', style: 'background-color:#eceff3;color:#566173;' } })

import { ScriptInclude } from '@servicenow/sdk/core'

/** AttachmentExtractor — parse .csv/.xlsx blotters into trade rows. */
ScriptInclude({
    $id: Now.ID['si-attachment-extractor'],
    name: 'AttachmentExtractor',
    active: true,
    apiName: 'x_2112826_fxcm.AttachmentExtractor',
    description: 'Parse xlsx/csv blotter attachments into normalized trade rows (port of attachment_extractor.py).',
    script: Now.include('../../server/AttachmentExtractor.server.js'),
})

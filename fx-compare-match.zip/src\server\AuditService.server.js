/**
 * AuditService — append-only compliance logging. One row per business action in
 * x_2112826_fxcm_audit_event (the ServiceNow port of utils/audit.py). Every
 * pipeline step calls log(); never throws (audit must not break the pipeline).
 */
var AuditService = Class.create();
AuditService.prototype = {
    initialize: function () {},

    /**
     * @param {string} action  e.g. 'email.classified', 'trade.matched'
     * @param {object} opts     { outcome, actor, resource, correlation_id, details }
     */
    log: function (action, opts) {
        opts = opts || {};
        try {
            var ae = new GlideRecord('x_2112826_fxcm_audit_event');
            ae.initialize();
            ae.setValue('action', action);
            ae.setValue('outcome', opts.outcome || 'success');
            ae.setValue('actor', opts.actor || gs.getUserDisplayName() || gs.getUserName() || 'system');
            ae.setValue('resource', opts.resource ? ('' + opts.resource).substring(0, 100) : '');
            ae.setValue('correlation_id', opts.correlation_id || '');
            ae.setValue('details', opts.details ? ('' + opts.details).substring(0, 4000) : '');
            ae.setValue('event_time', new GlideDateTime());
            ae.insert();
        } catch (e) {
            gs.warn('AuditService.log failed (' + action + '): ' + e);
        }
    },

    type: 'AuditService'
};

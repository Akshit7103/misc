import {
    Table,
    StringColumn,
    ChoiceColumn,
    DecimalColumn,
    IntegerColumn,
    DateTimeColumn,
    ReferenceColumn,
    MultiLineTextColumn,
} from '@servicenow/sdk/core'

/**
 * FX Case — one record per relevant settlement email.
 * Replaces the SQLite `email_cases` table + manifest.json + on-disk case folder
 * from the agentic-workflows app. Attachments live natively in sys_attachment.
 */
export const x_2112826_fxcm_case = Table({
    name: 'x_2112826_fxcm_case',
    label: 'FX Case',
    display: 'subject',
    audit: true,
    allowWebServiceAccess: true,
    schema: {
        message_id: StringColumn({ label: 'Message ID', maxLength: 255 }),
        trade_id: StringColumn({ label: 'Trade ID', maxLength: 40 }),
        asset_class: StringColumn({ label: 'Asset Class', maxLength: 60, default: 'FX Settlement' }),
        subject: StringColumn({ label: 'Subject', maxLength: 255 }),
        body: MultiLineTextColumn({ label: 'Body' }),
        sender: StringColumn({ label: 'Sender', maxLength: 255 }),
        received_at: DateTimeColumn({ label: 'Received At' }),
        source: ChoiceColumn({
            label: 'Source',
            choices: { local: 'Local (.eml)', graph: 'Graph API' },
            default: 'local',
        }),
        classification_label: ChoiceColumn({
            label: 'Classification',
            choices: { RELEVANT: 'Relevant', AMBIGUOUS: 'Ambiguous', IRRELEVANT: 'Irrelevant' },
        }),
        classification_confidence: DecimalColumn({ label: 'Confidence' }),
        classification_reason: StringColumn({ label: 'Reason', maxLength: 1000 }),
        matched_asset: StringColumn({ label: 'Matched Asset Keywords', maxLength: 1000 }),
        matched_subject: StringColumn({ label: 'Matched Subject Keywords', maxLength: 1000 }),
        attachment_count: IntegerColumn({ label: 'Attachment Count' }),
        state: ChoiceColumn({
            label: 'State',
            choices: {
                new: 'New',
                classified: 'Classified',
                extracted: 'Extracted',
                matched: 'Matched',
                in_review: 'In Review',
                closed: 'Closed',
            },
            default: 'new',
        }),
        skip_reason: ChoiceColumn({
            label: 'Skip Reason',
            choices: { duplicate: 'Duplicate', already_processed: 'Already Processed' },
        }),
        review_decision: ChoiceColumn({
            label: 'Review Decision',
            choices: { approve: 'Approve', decline: 'Decline', reset: 'Reset' },
        }),
        reviewed_by: ReferenceColumn({ label: 'Reviewed By', referenceTable: 'sys_user' }),
        reviewed_at: DateTimeColumn({ label: 'Reviewed At' }),
        original_label: ChoiceColumn({
            label: 'Original Label',
            choices: { RELEVANT: 'Relevant', AMBIGUOUS: 'Ambiguous', IRRELEVANT: 'Irrelevant' },
        }),
        correlation_id: StringColumn({ label: 'Correlation ID', maxLength: 40 }),
    },
})

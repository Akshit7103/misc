import { ScriptInclude } from '@servicenow/sdk/core'

/** AuditService — append-only compliance logging for every pipeline action. */
ScriptInclude({
    $id: Now.ID['si-audit-service'],
    name: 'AuditService',
    active: true,
    apiName: 'x_2112826_fxcm.AuditService',
    description: 'Append-only audit logging into x_2112826_fxcm_audit_event.',
    script: Now.include('../../server/AuditService.server.js'),
})

import { ScriptInclude } from '@servicenow/sdk/core'

/** TradeExtractor — orchestrates extraction of FX Trade rows for a case. */
ScriptInclude({
    $id: Now.ID['si-trade-extractor'],
    name: 'TradeExtractor',
    active: true,
    apiName: 'x_2112826_fxcm.TradeExtractor',
    description: 'Create FX Trade rows for a relevant case (body now; xlsx/csv attachments in part 2).',
    script: Now.include('../../server/TradeExtractor.server.js'),
})

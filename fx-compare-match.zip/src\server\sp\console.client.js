api.controller = function ($timeout, $window) {
    var c = this;

    /* ---- shell state ---- */
    c.view = 'pipeline';        // pipeline | schedules | settings
    c.step = 1;                 // 1..4
    c.source = 'local';         // local | graph

    /* ---- per-step "done" gates — initialised from existing data ---- */
    var d0 = c.data || {};
    c.synced = !!(d0.emails && d0.emails.length);
    c.classified = c.synced;
    c.extracted = !!(d0.trades && d0.trades.length);
    c.reconciled = !!(d0.matches && d0.matches.length);

    /* ---- .eml upload state ---- */
    c.uploading = false;
    c.finalizing = false;
    c.upTotal = 0;
    c.upDone = 0;
    c.upLog = [];
    c.upError = '';

    /* ---- transient run flags + progress ---- */
    c.syncing = false;
    c.classifying = false;
    c.extracting = false;
    c.reconciling = false;
    c.progress = [];

    c.stName = function (s) {
        var m = { MATCHED: 'Matched', ENRICHED: 'Enriched', NEAR_MATCH: 'Near-match', BREAK: 'Break', UNMATCHED: 'Unmatched' };
        return m[s] || s;
    };

    /* ---- filters / search ---- */
    c.cTab = 'all';
    c.eTab = 'all';
    c.rTab = 'all';
    c.q = { emails: '', classify: '', extract: '', recon: '', audit: '' };

    /* ---- navigation ---- */
    c.go = function (v) {
        c.view = v;
        if (v === 'settings') c.cfg = angular.copy((c.data && c.data.config) || {});
        if (v === 'audit' && !c.uploading) c._refreshData();
    };
    c.setStep = function (s) { c.step = s; };
    c.setSource = function (s) { c.source = s; };

    /* ---- account menu / logout ---- */
    c.userMenu = false;
    c.toggleUserMenu = function () { c.userMenu = !c.userMenu; };
    c.logout = function () {
        $window.location.href = '/logout.do?sysparm_goto_url=' + encodeURIComponent('/fxcm?id=fxcm-console');
    };

    /* ---- editable settings ---- */
    c.cfg = angular.copy((c.data && c.data.config) || {});
    c.newKw = { asset: '', subject: '', negative: '' };
    c.savingSettings = false;
    c.settingsSaved = false;
    c.saveSettings = function () {
        c.savingSettings = true; c.settingsSaved = false;
        c.server.get({ action: 'save_settings', cfg: c.cfg }).then(function (r) {
            c.data = r.data;
            c.cfg = angular.copy(c.data.config || {});
            c.savingSettings = false; c.settingsSaved = true;
            $timeout(function () { c.settingsSaved = false; }, 2500);
        });
    };
    c.addKeyword = function (type) {
        var v = (c.newKw[type] || '').trim();
        if (!v) return;
        c.newKw[type] = '';
        c.server.get({ action: 'add_keyword', kw_type: type, kw_value: v }).then(function (r) { c.data = r.data; });
    };
    c.delKeyword = function (sysId) {
        c.server.get({ action: 'del_keyword', sys_id: sysId }).then(function (r) { c.data = r.data; });
    };

    c.crumb = function () {
        if (c.view === 'schedules') return 'Configure Workflows';
        if (c.view === 'settings') return 'Settings';
        if (c.view === 'audit') return 'Audit Trail';
        return 'FX Trade Settlement';
    };

    /* ---- staged progress animation helper ---- */
    function runStages(stages, flagSetter, done) {
        c.progress = stages.map(function (s) { return { label: s, state: 'wait' }; });
        flagSetter(true);
        var idx = 0;
        function tick() {
            if (idx > 0) c.progress[idx - 1].state = 'done';
            if (idx < c.progress.length) {
                c.progress[idx].state = 'active';
                idx++;
                $timeout(tick, 480);
            } else {
                flagSetter(false);
                if (done) done();
            }
        }
        $timeout(tick, 250);
    }

    /* ---- step actions ---- */
    c.sync = function () {
        runStages(
            ['Connecting to mailbox', 'Fetching messages', 'Decoding headers', 'Indexing inbox'],
            function (v) { c.syncing = v; },
            function () { c.synced = true; }
        );
    };

    c.classify = function () {
        runStages(
            ['Loading email corpus', 'Initialising rule classifier', 'Scoring asset & subject signals',
             'Evaluating trade ID patterns', 'Storing relevant cases', 'Building classification index'],
            function (v) { c.classifying = v; },
            function () { c.classified = true; }
        );
    };

    c.extract = function () {
        runStages(
            ['Loading case index', 'Reading manifest files', 'Parsing trade fields',
             'Resolving counterparties', 'Building trade register'],
            function (v) { c.extracting = v; },
            function () {
                c.extracting = true;   // attachment extraction is async — refetch the latest
                c.server.get({ action: 'refresh' }).then(function (r) {
                    c.data = r.data;
                    c.extracting = false;
                    c.extracted = true;
                });
            }
        );
    };

    c.recon = function () {
        runStages(
            ['Connecting golden source', 'Matching by trade ID', 'Enriching missing fields',
             'Comparing fields', 'Scoring confidence'],
            function (v) { c.reconciling = v; },
            function () {
                c.reconciling = true;   // keep the spinner while the server rebuilds
                c.server.get({ action: 'rematch' }).then(function (r) {
                    c.data = r.data;
                    c.reconciling = false;
                    c.reconciled = true;
                });
            }
        );
    };

    /* ---- on-demand Microsoft Graph mailbox sync (Configure Workflows → Run).
       The server only QUEUES a background event (outbound HTTP isn't allowed in
       the interactive widget); we then poll until the new cases land. ---- */
    c.mailboxSyncing = false;
    c.mailboxMsg = '';
    c.syncMailbox = function () {
        if (c.mailboxSyncing) return;
        c.mailboxSyncing = true;
        c.mailboxMsg = 'Queuing background sync…';
        c._baseEmails = (c.data && c.data.emails) ? c.data.emails.length : 0;
        c.server.get({ action: 'sync_mailbox' }).then(function (r) {
            c.data = r.data;
            if (r.data && r.data.sync_error) {
                c.mailboxSyncing = false;
                c.mailboxMsg = 'Could not queue sync: ' + r.data.sync_error;
                return;
            }
            c.mailboxMsg = 'Pulling from Microsoft Graph…';
            c._pollMailbox(0);
        }, function () {
            c.mailboxSyncing = false;
            c.mailboxMsg = 'Could not reach the server.';
        });
    };
    c._pollMailbox = function (tries) {
        var self = this;
        self.server.get({ action: 'refresh' }).then(function (r) {
            self.data = r.data;
            var n = (r.data.emails || []).length;
            self.synced = n > 0; self.classified = self.synced;
            self.extracted = (r.data.trades || []).length > 0;
            self.reconciled = (r.data.matches || []).length > 0;
            var added = n - (self._baseEmails || 0);
            if (added > 0 || tries >= 16) {
                self.mailboxSyncing = false;
                self.mailboxMsg = added > 0
                    ? ('✓ Pulled ' + added + ' new message(s) — running pipeline.')
                    : 'No new messages found in the mailbox.';
                $timeout(function () { self.mailboxMsg = ''; }, 7000);
            } else {
                $timeout(function () { self._pollMailbox(tries + 1); }, 1500);
            }
        }, function () { self.mailboxSyncing = false; self.mailboxMsg = ''; });
    };

    /* jump to a step — switching never re-runs, but silently pulls the latest
       data (safety net so Extract/Recon are never stale after an upload) */
    c.openStep = function (s) {
        c.step = s;
        if (!c.uploading) c._refreshData();
    };

    c._refreshData = function () {
        var self = this;
        self.server.get({ action: 'refresh' }).then(function (r) {
            if (!r || !r.data) return;
            self.data = r.data;
            self.synced = (r.data.emails || []).length > 0;
            self.classified = self.synced;
            self.extracted = (r.data.trades || []).length > 0;
            self.reconciled = (r.data.matches || []).length > 0;
        });
    };

    /* ---- HITL review ---- */
    c.review = function (row, decision) {
        row.reviewed = decision;
        c.server.get({ action: 'review', sys_id: row.sys_id, decision: decision }).then(function (r) {
            c.data = r.data;
        });
    };

    /* ---- .eml upload (Option A): read each file → server parses → case → pipeline ---- */
    c.onFiles = function (files) {
        if (!files || !files.length) return;
        var list = [];
        for (var i = 0; i < files.length; i++) {
            if (/\.eml$/i.test(files[i].name)) list.push(files[i]);
        }
        if (!list.length) { c.upError = 'Please choose .eml files.'; return; }
        c.upError = '';
        c.uploading = true;
        c.upTotal = list.length;
        c.upDone = 0;
        c.upLog = [];
        // baseline counts so finalize waits for the NEW emails to be processed
        c._baseT = (c.data && c.data.trades) ? c.data.trades.length : 0;
        c._baseM = (c.data && c.data.matches) ? c.data.matches.length : 0;
        c._processNext(list, 0);
    };

    c._processNext = function (list, i) {
        var self = this;
        if (i >= list.length) {
            // All files uploaded. The pipeline (classify/extract/match) runs
            // server-side automatically; attachment extraction is async, so poll
            // until the trade/match counts settle, then reveal ALL tabs at once.
            self.finalizing = true;
            self._finalize(0, -1, -1);
            return;
        }
        var f = list[i];
        var reader = new $window.FileReader();
        reader.onload = function (ev) {
            self.server.get({ action: 'ingest_eml', filename: f.name, content: ev.target.result }).then(function (r) {
                self.upDone++;
                var ing = (r.data && r.data.ingest) || {};
                self.upLog.push({ name: f.name, ok: !!ing.ok, subject: ing.subject || '', att: ing.attachments || 0 });
                self.data = r.data;
                self._processNext(list, i + 1);
            }, function () {
                self.upDone++;
                self.upLog.push({ name: f.name, ok: false });
                self._processNext(list, i + 1);
            });
        };
        reader.onerror = function () {
            self.upDone++;
            self.upLog.push({ name: f.name, ok: false });
            self._processNext(list, i + 1);
        };
        reader.readAsText(f);
    };

    // Poll the server until the (async) pipeline settles, then show every tab.
    // "Settled" = counts have grown past the pre-upload baseline AND stopped
    // changing — so an incremental upload waits for the NEW email's trades/
    // matches, not just for the previous batch's (already-stable) counts.
    c._finalize = function (tries, prevT, prevM) {
        var self = this;
        self.server.get({ action: 'refresh' }).then(function (r) {
            self.data = r.data;
            var nt = (r.data.trades || []).length;
            var nm = (r.data.matches || []).length;
            self.synced = (r.data.emails || []).length > 0;
            self.classified = self.synced;
            self.extracted = nt > 0;
            self.reconciled = nm > 0;
            var grew = (nt > (self._baseT || 0)) || (nm > (self._baseM || 0));
            var stable = (nt === prevT && nm === prevM);
            if ((grew && stable && tries >= 1) || tries >= 12) {
                self.uploading = false;
                self.finalizing = false;
            } else {
                $timeout(function () { self._finalize(tries + 1, nt, nm); }, 1300);
            }
        }, function () { self.uploading = false; self.finalizing = false; });
    };

    /* ---- delete all emails (Settings → Danger Zone) ---- */
    c.deleting = false;
    c.deleteAll = function () {
        if (!$window.confirm('Delete ALL emails, extracted trades and reconciliations? This cannot be undone.')) return;
        c.deleting = true;
        c.server.get({ action: 'delete_all' }).then(function (r) {
            c.data = r.data;
            c.deleting = false;
            c.synced = false; c.classified = false; c.extracted = false; c.reconciled = false;
            c.upLog = [];
            c.view = 'pipeline';
            c.step = 1;
        });
    };

    /* ---- detail drawer (classify / extract / recon) ---- */
    c.drawer = null;
    c.drawerLoading = false;
    c.openDetail = function (kind, sysId) {
        c.drawer = { kind: kind };
        c.drawerLoading = true;
        c.server.get({ action: 'detail', kind: kind, sys_id: sysId }).then(function (r) {
            c.drawer = (r.data && r.data.detail) || null;
            c.drawerLoading = false;
        }, function () { c.drawer = null; c.drawerLoading = false; });
    };
    c.closeDrawer = function () { c.drawer = null; c.drawerLoading = false; };
    c.drawerReview = function (decision) {
        if (!c.drawer) return;
        c.drawer.reviewed = decision;
        if (decision === 'approve') c.drawer.label = 'RELEVANT';
        c.server.get({ action: 'review', sys_id: c.drawer.sys_id, decision: decision }).then(function (r) { c.data = r.data; });
    };

    /* ---- filter predicates ---- */
    c.cPred = function (row) { return c.cTab === 'all' || row.label === c.cTab; };
    c.ePred = function (row) { return c.eTab === 'all' || row.status === c.eTab; };
    c.rPred = function (row) { return c.rTab === 'all' || row.status === c.rTab; };
};

import { ScriptInclude } from '@servicenow/sdk/core'

/** Coercers — shared date/number normalization (port of the Python coercers). */
ScriptInclude({
    $id: Now.ID['si-coercers'],
    name: 'Coercers',
    active: true,
    apiName: 'x_2112826_fxcm.Coercers',
    description: 'Shared value normalization (coerceDate -> yyyy-MM-dd, coerceNumber).',
    script: Now.include('../../server/Coercers.server.js'),
})

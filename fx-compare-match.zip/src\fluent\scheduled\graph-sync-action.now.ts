import { Record, ScriptAction } from '@servicenow/sdk/core'

/**
 * On-demand Graph mailbox sync — event + script action.
 *
 * The console "Sync mailbox" button calls gs.eventQueue('x_2112826_fxcm.graph_sync')
 * (an interactive widget can't do outbound HTTP); the event is processed in the
 * background, where this Script Action runs the connector. The event is
 * registered below so gs.eventQueue accepts it.
 */
const EVENT_NAME = 'x_2112826_fxcm.graph_sync'

Record({
    $id: Now.ID['evt-graph-sync'],
    table: 'sysevent_register',
    data: {
        event_name: EVENT_NAME,
        table: 'x_2112826_fxcm_case',
        description: 'Fired by the console "Sync mailbox" button to run the Microsoft Graph inbox sync in the background.',
    },
})

ScriptAction({
    $id: Now.ID['sa-graph-sync'],
    name: 'FX Graph Mailbox Sync (on-demand)',
    active: true,
    eventName: EVENT_NAME,
    order: 100,
    description: 'Runs GraphConnector.syncInbox() in the background when the console requests an on-demand mailbox sync.',
    script: Now.include('../../server/graph-sync-action.js'),
})

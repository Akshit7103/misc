import { Record } from '@servicenow/sdk/core'

/** Pipeline reports — reconciliation outcomes + extraction sources. */
Record({
    $id: Now.ID['rpt-match-status'], table: 'sys_report',
    data: { title: 'Match Results by Status', table: 'x_2112826_fxcm_match_result', type: 'pie', field: 'status' },
})
Record({
    $id: Now.ID['rpt-trades-by-cpty'], table: 'sys_report',
    data: { title: 'Trades by Counterparty', table: 'x_2112826_fxcm_trade', type: 'bar', field: 'counterparty' },
})
Record({
    $id: Now.ID['rpt-trades-by-source'], table: 'sys_report',
    data: { title: 'Trades by Source', table: 'x_2112826_fxcm_trade', type: 'bar', field: 'source' },
})

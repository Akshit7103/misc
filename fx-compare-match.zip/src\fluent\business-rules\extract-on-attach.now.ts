import { BusinessRule } from '@servicenow/sdk/core'

/**
 * Extract Trades on Attach — re-runs extraction when a file is attached to an
 * FX Case, so blotters attached during/after case creation populate FX Trades.
 * ASYNC: xlsx parsing (sn_impex.GlideExcelParser) is classified as outbound HTTP
 * and is blocked in synchronous (before/after) business rules for scoped apps,
 * so this must run as an async rule (background job, outbound permitted).
 */
BusinessRule({
    $id: Now.ID['br-extract-on-attach'],
    name: 'Extract Trades on Attach',
    table: 'sys_attachment',
    when: 'async',
    action: ['insert'],
    order: 100,
    active: true,
    filterCondition: 'table_name=x_2112826_fxcm_case',
    script: Now.include('../../server/extract-on-attach.js'),
})

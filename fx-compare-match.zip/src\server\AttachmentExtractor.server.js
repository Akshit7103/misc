/**
 * AttachmentExtractor — parse trade rows out of a .csv / .xlsx blotter attached
 * to a case (one row per trade). Port of attachment_extractor.py: header
 * auto-detection (tolerates a banner row), column mapping, source-agnostic
 * normalization. Never throws — a bad file yields [].
 *
 * CSV  : read the attachment text (GlideSysAttachment + base64) and parse.
 * XLSX : ServiceNow's sn_impex.GlideExcelParser.
 * Script Include class file — Glide APIs auto-available; do not import.
 */
var AttachmentExtractor = Class.create();
AttachmentExtractor.prototype = {
    initialize: function () {
        this.c = new x_2112826_fxcm.Coercers();
        this.HEADER_SEARCH_DEPTH = 15;
        this.HEADER_MIN_HITS = 3;
        this.HEADER_MAP = {
            'trade id': 'trade_id', 'trade ref': 'trade_id', 'trade reference': 'trade_id', 'deal reference': 'trade_id',
            'uti': 'uti', 'trade date': 'trade_date',
            'counterparty code': 'counterparty_code', 'counterparty name': 'counterparty', 'counterparty': 'counterparty', 'cpty': 'counterparty',
            'currency pair': 'currency_pair', 'ccy pair': 'currency_pair', 'base currency': 'base_currency', 'quote currency': 'quote_currency',
            'option type': 'option_type', 'exercise style': 'exercise_style',
            'buy / sell': 'buy_sell', 'buy/sell': 'buy_sell', 'direction': 'buy_sell',
            'notional amount': 'notional_amount', 'notional': 'notional_amount', 'notional currency': 'notional_currency',
            'strike rate': 'strike_rate', 'strike': 'strike_rate',
            'expiry date': 'expiry_date', 'settlement date': 'settlement_date', 'value date': 'settlement_date',
            'premium amount': 'premium_amount', 'premium currency': 'premium_currency', 'premium settle date': 'premium_settle_date',
            'delta': 'delta', 'implied vol (%)': 'implied_vol', 'implied vol': 'implied_vol',
            'settlement status': 'settlement_status', 'status': 'settlement_status',
            'portfolio': 'portfolio', 'trader': 'trader', 'book': 'book',
        };
        this.DATE_FIELDS = { trade_date: 1, expiry_date: 1, settlement_date: 1, premium_settle_date: 1 };
        this.NUMERIC_FIELDS = { notional_amount: 1, premium_amount: 1, strike_rate: 1, delta: 1, implied_vol: 1 };
    },

    isSupported: function (fileName) {
        var n = ('' + (fileName || '')).toLowerCase();
        return n.slice(-4) === '.csv' || n.slice(-5) === '.xlsx' || n.slice(-5) === '.xlsm';
    },

    fileType: function (fileName) {
        var n = ('' + (fileName || '')).toLowerCase();
        if (n.slice(-4) === '.csv') return 'csv';
        if (n.slice(-5) === '.xlsx' || n.slice(-5) === '.xlsm') return 'xlsx';
        return 'unsupported';
    },

    // Parse one attachment -> array of normalized trade objects.
    extractRows: function (attSysId, fileName) {
        var ftype = this.fileType(fileName);
        var rows;
        try {
            if (ftype === 'csv') rows = this._readCsv(attSysId);
            else if (ftype === 'xlsx') rows = this._readXlsx(attSysId);
            else return [];
        } catch (e) {
            gs.warn('AttachmentExtractor failed on ' + fileName + ': ' + e);
            return [];
        }
        return this._rowsToTrades(rows || []);
    },

    _readCsv: function (attSysId) {
        // Read the raw bytes (base64) and decode UTF-8 with a Latin-1/cp1252
        // fallback, so accents survive whether Excel saved the CSV as UTF-8 or
        // ANSI (e.g. "Société Générale" — cp1252 'é' = 0xE9, invalid as UTF-8).
        try {
            var b64 = new GlideSysAttachment().getContentBase64(attSysId);
            if (b64) {
                var text = this._decodeBytes(this._b64bytes(b64));
                if (text) return this._parseCsv(text);
            }
        } catch (e) {
            gs.warn('AttachmentExtractor base64 CSV read failed, falling back: ' + e);
        }
        // Fallback: stream reader (fine for plain ASCII / UTF-8).
        var stream = new GlideSysAttachment().getContentStream(attSysId);
        var reader = new GlideTextReader(stream);
        var lines = [], line;
        while ((line = reader.readLine()) !== null) lines.push(line);
        return this._parseCsv(lines.join('\n'));
    },

    // base64 string -> raw byte-string (each char is one byte 0-255)
    _b64bytes: function (b64) {
        var T = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        b64 = ('' + (b64 || '')).replace(/[^A-Za-z0-9+/]/g, '');
        var out = '', i = 0, n = b64.length;
        while (i < n) {
            var e1 = T.indexOf(b64.charAt(i++));
            var e2 = i < n ? T.indexOf(b64.charAt(i++)) : -1;
            var e3 = i < n ? T.indexOf(b64.charAt(i++)) : -1;
            var e4 = i < n ? T.indexOf(b64.charAt(i++)) : -1;
            out += String.fromCharCode((e1 << 2) | (e2 >> 4));
            if (e3 !== -1) out += String.fromCharCode(((e2 & 15) << 4) | (e3 >> 2));
            if (e4 !== -1) out += String.fromCharCode(((e3 & 3) << 6) | e4);
        }
        return out;
    },

    // decode a byte-string: valid UTF-8 -> Unicode; otherwise treat as Latin-1/cp1252
    _decodeBytes: function (s) {
        var u = this._utf8(s);
        var out = (u.indexOf('�') === -1) ? u : s;
        if (out.charCodeAt(0) === 0xFEFF) out = out.slice(1); // strip BOM
        return out;
    },

    // strict UTF-8 decoder: emits U+FFFD on any invalid sequence (so _decodeBytes can detect)
    _utf8: function (s) {
        var out = '', i = 0, n = s.length;
        function cont(k) { return k < n && (s.charCodeAt(k) & 0xC0) === 0x80; }
        while (i < n) {
            var c1 = s.charCodeAt(i);
            if (c1 < 0x80) { out += String.fromCharCode(c1); i++; }
            else if (c1 >= 0xC2 && c1 <= 0xDF && cont(i + 1)) {
                out += String.fromCharCode(((c1 & 0x1F) << 6) | (s.charCodeAt(i + 1) & 0x3F)); i += 2;
            } else if (c1 >= 0xE0 && c1 <= 0xEF && cont(i + 1) && cont(i + 2)) {
                out += String.fromCharCode(((c1 & 0x0F) << 12) | ((s.charCodeAt(i + 1) & 0x3F) << 6) | (s.charCodeAt(i + 2) & 0x3F)); i += 3;
            } else if (c1 >= 0xF0 && c1 <= 0xF4 && cont(i + 1) && cont(i + 2) && cont(i + 3)) {
                var cp = (((c1 & 0x07) << 18) | ((s.charCodeAt(i + 1) & 0x3F) << 12) | ((s.charCodeAt(i + 2) & 0x3F) << 6) | (s.charCodeAt(i + 3) & 0x3F)) - 0x10000;
                out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)); i += 4;
            } else { out += '�'; i++; }
        }
        return out;
    },

    _parseCsv: function (text) {
        var rows = [], row = [], field = '', inq = false, i = 0;
        text = ('' + text).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        while (i < text.length) {
            var ch = text.charAt(i);
            if (inq) {
                if (ch === '"') {
                    if (text.charAt(i + 1) === '"') { field += '"'; i += 2; continue; }
                    inq = false; i++; continue;
                }
                field += ch; i++; continue;
            }
            if (ch === '"') { inq = true; i++; continue; }
            if (ch === ',') { row.push(field); field = ''; i++; continue; }
            if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }
            field += ch; i++;
        }
        if (field !== '' || row.length) { row.push(field); rows.push(row); }
        return rows;
    },

    _readXlsx: function (attSysId) {
        var parser = new sn_impex.GlideExcelParser();
        var stream = new GlideSysAttachment().getContentStream(attSysId);
        parser.parse(stream);
        var headers = parser.getColumnHeaders() || [];
        var rows = [headers];
        while (parser.next()) {
            var obj = parser.getRow();
            var arr = [];
            for (var h = 0; h < headers.length; h++) arr.push(obj[headers[h]]);
            rows.push(arr);
        }
        return rows;
    },

    _norm: function (h) {
        return ('' + (h === null || h === undefined ? '' : h)).trim().toLowerCase().replace(/\s+/g, ' ');
    },

    _headerHits: function (cells) {
        var n = 0;
        for (var i = 0; i < cells.length; i++) if (this.HEADER_MAP[this._norm(cells[i])]) n++;
        return n;
    },

    _locateHeader: function (rows) {
        var bestIdx = -1, best = 0;
        var depth = Math.min(this.HEADER_SEARCH_DEPTH, rows.length);
        for (var i = 0; i < depth; i++) {
            var hits = this._headerHits(rows[i]);
            if (hits > best) { best = hits; bestIdx = i; }
        }
        return best >= this.HEADER_MIN_HITS ? bestIdx : -1;
    },

    _rowsToTrades: function (rows) {
        var hidx = this._locateHeader(rows);
        if (hidx < 0) return [];
        var headers = rows[hidx];
        var out = [];
        for (var r = hidx + 1; r < rows.length; r++) {
            var cells = rows[r];
            var blank = true;
            for (var k = 0; k < cells.length; k++) {
                if (cells[k] !== null && cells[k] !== undefined && ('' + cells[k]).trim() !== '') { blank = false; break; }
            }
            if (blank) continue;

            var t = {};
            for (var col = 0; col < headers.length; col++) {
                var key = this.HEADER_MAP[this._norm(headers[col])];
                if (!key) continue;
                var val = col < cells.length ? cells[col] : '';
                if (this.DATE_FIELDS[key]) t[key] = this.c.coerceDate(val);
                else if (this.NUMERIC_FIELDS[key]) t[key] = this.c.coerceNumber(val);
                else t[key] = (val === null || val === undefined) ? '' : ('' + val).trim();
            }
            if (t.currency_pair && t.currency_pair.indexOf('/') > -1) {
                var p = t.currency_pair.split('/');
                if (!t.base_currency) t.base_currency = p[0];
                if (!t.quote_currency) t.quote_currency = p[1];
            }
            if (String(t.trade_id || '').trim()) out.push(t);
        }
        return out;
    },

    type: 'AttachmentExtractor',
};

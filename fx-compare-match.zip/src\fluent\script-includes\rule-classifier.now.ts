import { ScriptInclude } from '@servicenow/sdk/core'

/**
 * RuleClassifier Script Include — the deterministic scoring engine.
 * Source lives in src/server/RuleClassifier.server.js (Class.create pattern).
 */
ScriptInclude({
    $id: Now.ID['si-rule-classifier'],
    name: 'RuleClassifier',
    active: true,
    apiName: 'x_2112826_fxcm.RuleClassifier',
    description: 'Deterministic keyword/regex classifier for FX settlement emails (port of rule_classifier.py).',
    script: Now.include('../../server/RuleClassifier.server.js'),
})

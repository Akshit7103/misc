import { Record } from '@servicenow/sdk/core'

/**
 * Reports — live charts of the triage output (count of cases grouped by a
 * field). These render as real pie/bar charts and can be dropped onto a
 * dashboard/homepage. The ServiceNow equivalent of the old app's stat cards.
 */
const CASE = 'x_2112826_fxcm_case'

export const reportByClassification = Record({
    $id: Now.ID['rpt-by-classification'],
    table: 'sys_report',
    data: { title: 'FX Cases by Classification', table: CASE, type: 'pie', field: 'classification_label' },
})

export const reportByState = Record({
    $id: Now.ID['rpt-by-state'],
    table: 'sys_report',
    data: { title: 'FX Cases by State', table: CASE, type: 'bar', field: 'state' },
})

export const reportBySource = Record({
    $id: Now.ID['rpt-by-source'],
    table: 'sys_report',
    data: { title: 'FX Cases by Source', table: CASE, type: 'bar', field: 'source' },
})

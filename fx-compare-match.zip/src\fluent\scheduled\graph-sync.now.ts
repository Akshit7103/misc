import { ScheduledScript } from '@servicenow/sdk/core'

/**
 * FX Graph Mailbox Sync — pulls new inbox mail from Microsoft Graph daily.
 * Runs in the background (outbound HTTP allowed). Use "Execute Now" to test
 * on-demand once the OAuth provider is configured + consented.
 *
 * runAs MUST be the user that consented to the OAuth token — the delegated token
 * is keyed to that user together with the "FX Graph Mailbox" REST Message
 * requestor. Here that's admin (sys_id below). On another instance, set this to
 * that instance's consenting user. Kept in source so it survives
 * `now-sdk install` (a Table-API value gets wiped on every reinstall).
 */
export const graphSyncJob = ScheduledScript({
    $id: Now.ID['sched-graph-sync'],
    name: 'FX Graph Mailbox Sync',
    active: true,
    frequency: 'daily',
    executionTime: { hours: 6, minutes: 0, seconds: 0 },
    runAs: '6816f79cc0a8016401c5a33be04be441', // admin
    script: Now.include('../../server/graph-sync.job.js'),
})

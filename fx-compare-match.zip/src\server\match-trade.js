/**
 * Business Rule (after insert) on x_2112826_fxcm_trade.
 * Reconciles each newly extracted trade against the golden source — the
 * ServiceNow equivalent of the /match step. Classic server script.
 */
(function executeRule(current, previous /*null when async*/) {
    var tradeSysId = current.getUniqueValue();
    new x_2112826_fxcm.CompareMatcher().matchByTradeSysId(tradeSysId);
    var mr = new GlideRecord('x_2112826_fxcm_match_result');
    mr.addQuery('trade', tradeSysId);
    mr.orderByDesc('sys_created_on');
    mr.setLimit(1);
    mr.query();
    if (mr.next()) {
        var st = mr.getValue('status');
        new x_2112826_fxcm.AuditService().log('trade.matched', {
            outcome: (st === 'BREAK' || st === 'UNMATCHED') ? 'failure' : 'success',
            resource: current.getValue('trade_id'),
            correlation_id: current.getValue('case'),
            details: st + ' · confidence ' + Math.round(parseFloat(mr.getValue('confidence') || '0') * 100) + '% · ' +
                mr.getValue('agreed_fields') + '/' + mr.getValue('compared_fields') + ' fields agree · ' +
                mr.getValue('filled_count') + ' filled from golden'
        });
    }
})(current, previous);

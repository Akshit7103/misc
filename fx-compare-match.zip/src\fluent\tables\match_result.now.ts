import {
    Table,
    StringColumn,
    ChoiceColumn,
    FloatColumn,
    IntegerColumn,
    BooleanColumn,
    ReferenceColumn,
} from '@servicenow/sdk/core'

/**
 * Match Result — outcome of reconciling one extracted trade against the
 * golden source. Replaces the CompareMatcher result object.
 */
export const x_2112826_fxcm_match_result = Table({
    name: 'x_2112826_fxcm_match_result',
    label: 'Match Result',
    display: 'trade_id',
    schema: {
        trade: ReferenceColumn({
            label: 'Trade',
            referenceTable: 'x_2112826_fxcm_trade',
            cascadeRule: 'cascade',
        }),
        trade_id: StringColumn({ label: 'Trade ID', maxLength: 40 }),
        status: ChoiceColumn({
            label: 'Status',
            choices: {
                MATCHED: 'Matched',
                ENRICHED: 'Enriched',
                NEAR_MATCH: 'Near-match',
                BREAK: 'Break',
                UNMATCHED: 'Unmatched',
            },
        }),
        confidence: FloatColumn({ label: 'Confidence' }),
        golden_found: BooleanColumn({ label: 'Golden Found' }),
        filled_fields: StringColumn({ label: 'Filled Fields', maxLength: 1000 }),
        filled_count: IntegerColumn({ label: 'Filled Count' }),
        compared_fields: IntegerColumn({ label: 'Compared Fields' }),
        agreed_fields: IntegerColumn({ label: 'Agreed Fields' }),
    },
})

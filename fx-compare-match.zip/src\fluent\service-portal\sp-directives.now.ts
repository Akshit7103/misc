import { SPAngularProvider } from '@servicenow/sdk/core'

/**
 * AngularJS directives for the console widget's .eml upload. Stored as inline
 * factory functions (the format the platform expects for sp_angular_provider).
 */
export const fileChangeDirective = SPAngularProvider({
    $id: Now.ID['fxcm_dir_filechange'],
    name: 'fileChange',
    type: 'directive',
    script: `function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.on('change', function (event) {
                var files = event.target.files;
                scope.$apply(function () { scope.$eval(attrs.fileChange, { $files: files }); });
                event.target.value = '';
            });
        }
    };
}`,
})

export const fileDropDirective = SPAngularProvider({
    $id: Now.ID['fxcm_dir_filedrop'],
    name: 'fileDrop',
    type: 'directive',
    script: `function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            function stop(e) { e.preventDefault(); e.stopPropagation(); }
            element.on('dragover dragenter', function (e) { stop(e); element.addClass('dragging'); });
            element.on('dragleave dragend', function (e) { stop(e); element.removeClass('dragging'); });
            element.on('drop', function (e) {
                stop(e);
                element.removeClass('dragging');
                var dt = (e.originalEvent || e).dataTransfer;
                var files = dt ? dt.files : null;
                scope.$apply(function () { scope.$eval(attrs.fileDrop, { $files: files }); });
            });
        }
    };
}`,
})

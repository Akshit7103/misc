# PRD — FX Compare & Match (ServiceNow native rebuild)

> Product Requirements Document for rebuilding the `agentic-workflows` app **natively in ServiceNow** as a production-grade **scoped application**, authored as code with the ServiceNow SDK (Fluent) + Claude Code.
> Source app this replaces: `../agentic-workflows` (FastAPI backend + Next.js frontend). This PRD is the single source of truth the SDK build is generated from.

---

## 1. Purpose

A Middle/Back-Office settlement team shares one mailbox. Real FX/OTC trade-settlement emails arrive mixed with office noise. This app automates the first mile: **ingest → classify → deduplicate → extract trades → reconcile against a golden source → route breaks to a human → audit everything** — all on the ServiceNow platform, explainable and tunable by operations.

Rule-based core (no LLM required), mirroring the current app. PDF/OCR and LLM classification are explicitly deferred (Phase 2 enhancements).

## 2. Users & roles (RBAC)

| Role (scoped) | Who | Can |
|---|---|---|
| `x_<scope>.admin` | Platform/app admin | Configure keywords/weights/thresholds, manage golden source, all analyst rights |
| `x_<scope>.analyst` | SSG operations | Run/trigger pipeline, review ambiguous cases (approve/decline/override), view all cases/trades/matches |
| `x_<scope>.viewer` | Read-only stakeholder | View cases, trades, match results, dashboards |

Authentication is the platform's (SSO/AD in prod) — **no custom login**. Access enforced via ACLs (Section 7), not app code.

## 3. Data model (tables)

All tables are scoped (`x_<scope>_*`). Field types use ServiceNow dictionary types. "Ref →" = reference field.

### 3.1 `case` — one per relevant email (replaces SQLite `email_cases` + manifest + case folder)
| Field | Type | Notes |
|---|---|---|
| number | Auto-number | `FXC0001001` |
| message_id | String (255), **unique index** | dedup guard #1 (replaces `message_id_exists`) |
| trade_id | String (40) | extracted; dedup guard #2 for non-UNKNOWN ids |
| asset_class | String (60) | default "FX Settlement" |
| subject | String (255) | |
| sender | String (255) | |
| received_at | Date/Time | from email header |
| source | Choice | `local`, `graph` |
| classification_label | Choice | `RELEVANT`, `AMBIGUOUS`, `IRRELEVANT` |
| classification_confidence | Decimal | 0–1 |
| classification_reason | String (1000) | explainability text |
| matched_asset | String (1000) | matched asset keywords |
| matched_subject | String (1000) | matched subject keywords |
| attachment_count | Integer | |
| state | Choice | `new` → `classified` → `extracted` → `matched` → `in_review` → `closed` |
| skip_reason | Choice (nullable) | `duplicate`, `already_processed` |
| review_decision | Choice (nullable) | `approve`, `decline`, `reset` |
| reviewed_by | Ref → sys_user | HITL audit |
| reviewed_at | Date/Time | |
| original_label | Choice | label before human override |
| correlation_id | String (40) | threads logs/audit |

Native attachments (`sys_attachment`) replace the on-disk `attachments/` folder. The Case record **is** the manifest.

### 3.2 `trade` — extracted trade rows (replaces `extracted_trades.json` + body parse)
Ref → `case`. Canonical fields (same names as the extractor/golden source so they compare apples-to-apples):
`trade_id`, `uti`, `trade_date` (Date), `counterparty`, `counterparty_code`, `currency_pair`, `base_currency`, `quote_currency`, `option_type`, `exercise_style`, `buy_sell` (choice Buy/Sell), `notional_amount` (Decimal), `notional_currency`, `strike_rate` (Decimal), `expiry_date` (Date), `settlement_date` (Date), `premium_amount` (Decimal), `premium_currency`, `premium_settle_date` (Date), `delta` (Decimal), `implied_vol` (Decimal), `settlement_status`, `portfolio`, `trader`, `book`, `source` (choice `Body` / `Attachment`), `source_file` (String).

### 3.3 `golden_trade` — trusted master blotter (replaces `FX_Options_Trade_masterDataset.xlsx`)
Same field set as `trade` (the economic + reference fields), keyed on `trade_id` (unique). Populated by Import Set (Section 6). Stands in for GLOSS/OBI/FO; in prod swap the loader for an Integration Hub spoke.

### 3.4 `match_result` — one per reconciled trade (replaces `CompareMatcher` output)
Ref → `trade`. Fields: `trade_id`, `status` (Choice `MATCHED`/`ENRICHED`/`NEAR_MATCH`/`BREAK`/`UNMATCHED`), `confidence` (Decimal), `golden_found` (Boolean), `filled_fields` (String), `filled_count` (Integer), `compared_fields` (Integer), `agreed_fields` (Integer).

### 3.5 `field_diff` — child of `match_result` (the per-field comparison)
Ref → `match_result`. Fields: `field` (String), `extracted_value` (String), `golden_value` (String), `agree` (Boolean).

### 3.6 Configuration tables (replaces `EmailAgentConfig` + `/config`)
- `keyword` — `value` (String), `type` (Choice `asset`/`subject`/`negative`). One row per keyword; runtime-editable.
- `trade_id_pattern` — `pattern` (String regex), `order` (Integer).
- `settings` — single config record: `asset_weight` (0.5), `subject_weight` (0.3), `trade_id_weight` (0.2), `relevant_threshold` (0.7), `ambiguous_threshold` (0.3), `default_asset_class`, `match_numeric_tolerance` (0.01), `match_break_threshold` (0.6), `match_enrich_enabled` (Boolean), `max_body_scan_chars` (2000), `sync_frequency_hours` (24). `match_fields` modeled as a small `match_field` table or a comma-list on settings.

### 3.7 `audit_event` — compliance log (replaces `utils/audit.py`)
Fields: `action` (String, e.g. `email.classified`, `case.stored`, `trades.matched`, `config.updated`), `outcome` (Choice success/failure/skipped), `actor` (Ref → sys_user / system), `resource` (String — trade id / case number), `correlation_id` (String), `details` (String/JSON), `timestamp` (Date/Time). Append-only (ACL: create+read, no write/delete). Native field auditing also enabled on `case`, `trade`, `settings`.

## 4. Server logic (Script Includes — replaces the Python services)

| Script Include | Replaces | Responsibility |
|---|---|---|
| `ConfigService` | `agent_config.py` / `config_store.py` | Read keywords/weights/thresholds from config tables (cached per transaction) |
| `RuleClassifier` | `rule_classifier.py` | `classify(subject, body)` → {label, confidence, reason, matched_asset, matched_subject, trade_id}. Hard-negative early exit; additive scoring; threshold routing. `extractTradeId()` tries patterns in order. |
| `BodyExtractor` | `body_extractor.py` | Parse single-trade fields from subject + "Trade Details" body block; same canonical fields + coercers |
| `AttachmentExtractor` | `attachment_extractor.py` | Read xlsx/csv attachments → normalized trade rows (see Section 6 for parsing strategy) |
| `CompareMatcher` | `compare_match.py` | match → enrich → compare each trade vs `golden_trade`; produce `match_result` + `field_diff`; status + confidence; numeric tolerance, date canonicalization, string fold |
| `AuditService` | `audit.py` | `record(action, outcome, resource, details, correlationId)` → insert `audit_event` |
| `Coercers` | `_coerce_date`/`_coerce_number` | shared value normalization used by all of the above |

All Script Includes are **server-side, deterministic, never throw to the caller** (mirror the Python "never raises" contract).

## 5. Orchestration (Flow Designer — replaces `EmailAgentRunner` SPAR loop)

**Trigger A — Inbound email** (`x_<scope>` inbound email action) and **Trigger B — scheduled/on-demand "Run"**:
1. **Sense** — for each new email: create/locate `case`; if `message_id` exists → skip (dedup guard #1).
2. **Plan/Act** — call `RuleClassifier`. Set label/confidence/reason on `case`.
   - `IRRELEVANT` → state `closed`, audit, stop.
   - `AMBIGUOUS` → state `in_review`, assign to analyst group, audit, stop (HITL).
   - `RELEVANT` → if `trade_id` already captured (dedup guard #2) → `skip_reason=duplicate`; else extract (`AttachmentExtractor` for blotters, else `BodyExtractor`) → create `trade` rows → run `CompareMatcher` → create `match_result`/`field_diff` → state `matched`.
3. **Reflect** — write run summary + `agent.run.complete` audit event.

Idempotent re-runs (unique `message_id`/`trade_id`), self-heal not needed (DB is the store).

## 6. Ingestion & extraction strategy (the native-gap area)

- **Email + attachments:** native **Inbound Email Actions** (dev) → **Microsoft Graph spoke** via Integration Hub (prod). Attachments land in `sys_attachment` automatically.
- **Excel/CSV blotters:** ServiceNow **Data Source + Import Set + Transform Map** parses spreadsheet attachments natively into a staging table, mapped onto `trade`. (This is ServiceNow's native spreadsheet path — no openpyxl needed.) `AttachmentExtractor` reads the attachment, hands rows to the transform.
- **Single-trade body:** `BodyExtractor` regex (pure server JS).
- **PDF/OCR:** **deferred (Phase 2)** → ServiceNow Document Intelligence (licensed). Same as the source app, where OCR was optional.

## 7. Security (ACLs)

- `case`/`trade`/`match_result`/`field_diff`: read = viewer+; write = analyst+; delete = admin.
- `keyword`/`trade_id_pattern`/`settings`: read = analyst+; write = admin.
- `audit_event`: create = system; read = analyst+; **no update/delete for anyone** (WORM-style).
- Field-level ACL on `classification_*` (read-only to analysts; system-written).

## 8. UI (replaces the Next.js app)

- **Configurable Workspace** (UI Builder): Case list (filter by label/state), Case form with related Trades + Match Results + attachments; Ambiguous-review queue with **approve/decline/override UI Actions** (replaces `DecisionDrawer`).
- **Config screen:** forms/list on `keyword`, `settings` (replaces Configure Workflows). Editing keywords changes the next run's classification — live, no deploy.
- **Dashboards/Reports:** counts by label (14/3/10/2-style), match status breakdown, fields-filled, breaks needing attention (replaces stat cards + pipeline summary).
- **"Run" action:** a UI Action / scheduled job that triggers Flow B (replaces the Run console).

## 9. Observability & audit
Native field auditing + `audit_event` table + transaction logs. `correlation_id` threads a run across records and audit events (replaces the API correlation-id middleware).

## 10. Out of scope (Phase 2+)
PDF/OCR (Document Intelligence), LLM/Now Assist classification for the ambiguous band, live Microsoft Graph connection (procurement), the visual "marketplace/workflow builder" showcase (Flow Designer is the real one), multi-source agentic Compare & Match.

## 11. Mapping summary (source app → ServiceNow)

| agentic-workflows | ServiceNow |
|---|---|
| SQLite `email_cases` | `case` table |
| `extracted_trades.json` | `trade` table |
| golden xlsx | `golden_trade` table (Import Set) |
| `RuleClassifier`/`CompareMatcher`/`body_extractor` | Script Includes |
| `EmailAgentRunner` SPAR loop | Flow Designer flow |
| connectors (local/graph) | Inbound Email Action / Graph spoke |
| openpyxl parsing | Data Source + Import Set + Transform Map |
| `FileStore` + manifest.json | `case` record + `sys_attachment` |
| JWT auth + RBAC | platform auth + Roles + ACLs |
| `utils/audit.py` | `audit_event` + native field auditing |
| `EmailAgentConfig` + `/config` | `keyword`/`settings` tables + forms |
| Next.js pages / Run console / DecisionDrawer | Configurable Workspace + UI Actions + Dashboards |

## 12. Acceptance (mirrors the source app's tests/ suite)
- Deterministic classification split holds on the synthetic dataset.
- Idempotent re-run: no duplicates created.
- Compare & Match: MATCHED/ENRICHED/NEAR_MATCH/BREAK/UNMATCHED computed correctly; missing fields enriched; numeric within tolerance agrees.
- HITL: ambiguous approve → flows into extraction; decline → closed; both audited.
- ACLs: viewer cannot write; audit_event cannot be edited.
- All packaged as a scoped app, ATF tests green, deployable dev→test→prod.

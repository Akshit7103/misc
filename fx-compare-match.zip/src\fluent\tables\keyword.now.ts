import { Table, StringColumn, ChoiceColumn } from '@servicenow/sdk/core'

/**
 * Classifier Keyword — runtime-editable keyword that drives the rule
 * classifier. Replaces the asset/subject/negative keyword lists in
 * EmailAgentConfig. One row per keyword; editing changes the next run.
 */
export const x_2112826_fxcm_keyword = Table({
    name: 'x_2112826_fxcm_keyword',
    label: 'Classifier Keyword',
    display: 'value',
    schema: {
        value: StringColumn({ label: 'Keyword', maxLength: 120, mandatory: true }),
        type: ChoiceColumn({
            label: 'Type',
            choices: { asset: 'Asset', subject: 'Subject', negative: 'Negative' },
            mandatory: true,
        }),
    },
})

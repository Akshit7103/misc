/**
 * CompareMatcher — reconcile an extracted FX Trade against the golden source.
 * Port of compare_match.py: match by trade_id -> enrich missing fields from
 * golden -> compare the configured match_fields (numeric tolerance / date
 * canonicalization / string fold) -> classify MATCHED / ENRICHED / NEAR_MATCH /
 * BREAK / UNMATCHED with a confidence, writing a Match Result (+ Field Diffs).
 * Never throws. Script Include class file — Glide APIs auto-available.
 */
var CompareMatcher = Class.create();
CompareMatcher.prototype = {
    initialize: function () {
        this.c = new x_2112826_fxcm.Coercers();
        this.GOLDEN_FIELDS = [
            'uti', 'trade_date', 'counterparty', 'counterparty_code', 'currency_pair',
            'base_currency', 'quote_currency', 'option_type', 'exercise_style', 'buy_sell',
            'notional_amount', 'notional_currency', 'strike_rate', 'expiry_date',
            'settlement_date', 'premium_amount', 'premium_currency', 'premium_settle_date',
            'delta', 'implied_vol', 'settlement_status', 'portfolio', 'trader', 'book',
        ];
        this.NUMERIC = { notional_amount: 1, premium_amount: 1, strike_rate: 1, delta: 1, implied_vol: 1 };
        this.DATE = { trade_date: 1, expiry_date: 1, settlement_date: 1, premium_settle_date: 1 };
        this._loadSettings();
    },

    _loadSettings: function () {
        this.tolerance = 0.01;
        this.breakThreshold = 0.6;
        this.enrich = true;
        this.matchFields = ['currency_pair', 'buy_sell', 'notional_amount', 'counterparty', 'settlement_date', 'strike_rate'];
        var st = new GlideRecord('x_2112826_fxcm_settings');
        st.orderByDesc('sys_created_on');
        st.setLimit(1);
        st.query();
        if (st.next()) {
            var t = parseFloat(st.getValue('match_numeric_tolerance')); if (!isNaN(t)) this.tolerance = t;
            var b = parseFloat(st.getValue('match_break_threshold')); if (!isNaN(b)) this.breakThreshold = b;
            var e = st.getValue('match_enrich_enabled');
            this.enrich = (e === '1' || e === 'true');
            var mf = st.getValue('match_fields');
            if (mf) {
                this.matchFields = mf.split(',').map(function (s) { return s.trim(); }).filter(function (s) { return s; });
            }
        }
    },

    _blank: function (v) { return v === null || v === undefined || ('' + v).trim() === ''; },
    _normStr: function (v) { return ('' + v).trim().toLowerCase().replace(/\s+/g, ' '); },

    _agree: function (field, ev, gv) {
        if (this.NUMERIC[field]) {
            var a = parseFloat(('' + ev).replace(/,/g, ''));
            var b = parseFloat(('' + gv).replace(/,/g, ''));
            if (isNaN(a) || isNaN(b)) return this._normStr(ev) === this._normStr(gv);
            if (b === 0) return Math.abs(a - b) <= this.tolerance;
            return Math.abs(a - b) / Math.abs(b) <= this.tolerance;
        }
        if (this.DATE[field]) return this.c.coerceDate(ev) === this.c.coerceDate(gv);
        return this._normStr(ev) === this._normStr(gv);
    },

    _lookupGolden: function (tid) {
        if (!tid) return null;
        var g = new GlideRecord('x_2112826_fxcm_golden_trade');
        g.addQuery('trade_id', tid);
        g.setLimit(1);
        g.query();
        if (!g.next()) return null;
        var o = {};
        for (var i = 0; i < this.GOLDEN_FIELDS.length; i++) o[this.GOLDEN_FIELDS[i]] = g.getValue(this.GOLDEN_FIELDS[i]);
        return o;
    },

    // Reconcile one trade (by sys_id). Writes a Match Result + Field Diffs.
    matchByTradeSysId: function (tradeSysId) {
        var tr = new GlideRecord('x_2112826_fxcm_trade');
        if (!tr.get(tradeSysId)) return;
        var tid = tr.getValue('trade_id');

        // Idempotent: clear any prior match result for this trade (cascades diffs).
        var old = new GlideRecord('x_2112826_fxcm_match_result');
        old.addQuery('trade', tradeSysId);
        old.deleteMultiple();

        var golden = this._lookupGolden(tid);
        if (!golden) {
            this._writeResult(tradeSysId, tid, 'UNMATCHED', 0, false, [], [], 0, 0);
            return;
        }

        var filled = [];
        var diffs = [];
        var enrichUpdates = {};

        for (var i = 0; i < this.GOLDEN_FIELDS.length; i++) {
            var f = this.GOLDEN_FIELDS[i];
            var gv = golden[f];
            var ev = tr.getValue(f);
            if (this._blank(ev)) {
                if (this.enrich && !this._blank(gv)) { enrichUpdates[f] = gv; filled.push(f); }
            } else if (this.matchFields.indexOf(f) > -1 && !this._blank(gv)) {
                diffs.push({ field: f, extracted: ev, golden: gv, agree: this._agree(f, ev, gv) });
            }
        }

        var compared = diffs.length;
        var agreed = 0;
        for (var d = 0; d < diffs.length; d++) if (diffs[d].agree) agreed++;
        var confidence = compared ? (agreed / compared) : 1.0;

        var status;
        if (compared && agreed < compared) status = confidence < this.breakThreshold ? 'BREAK' : 'NEAR_MATCH';
        else if (filled.length) status = 'ENRICHED';
        else status = 'MATCHED';

        // Enrich the trade record itself from golden (the "completed" record).
        var keys = Object.keys(enrichUpdates);
        if (keys.length) {
            for (var k = 0; k < keys.length; k++) tr.setValue(keys[k], enrichUpdates[keys[k]]);
            tr.update();
        }

        this._writeResult(tradeSysId, tid, status, Math.round(confidence * 1000) / 1000, true, filled, diffs, compared, agreed);
    },

    _writeResult: function (tradeSysId, tid, status, confidence, goldenFound, filled, diffs, compared, agreed) {
        var mr = new GlideRecord('x_2112826_fxcm_match_result');
        mr.initialize();
        mr.setValue('trade', tradeSysId);
        mr.setValue('trade_id', tid);
        mr.setValue('status', status);
        mr.setValue('confidence', confidence);
        mr.setValue('golden_found', goldenFound ? true : false);
        mr.setValue('filled_fields', filled.join(', '));
        mr.setValue('filled_count', filled.length);
        mr.setValue('compared_fields', compared);
        mr.setValue('agreed_fields', agreed);
        var mrId = mr.insert();
        for (var i = 0; i < diffs.length; i++) {
            var fd = new GlideRecord('x_2112826_fxcm_field_diff');
            fd.initialize();
            fd.setValue('match_result', mrId);
            fd.setValue('field', diffs[i].field);
            fd.setValue('extracted_value', String(diffs[i].extracted));
            fd.setValue('golden_value', String(diffs[i].golden));
            fd.setValue('agree', diffs[i].agree ? true : false);
            fd.insert();
        }
    },

    type: 'CompareMatcher',
};

# Requirements — servicenow-fx-compare-match

The application itself runs **inside a ServiceNow instance**. Locally you only need a
**build + deploy toolchain** (Node.js + the ServiceNow SDK). Python is optional and is
used by a single dev helper script.

---

## 1. Required — to build & deploy the app

| Tool | Version used | Why |
|------|--------------|-----|
| **Node.js** (LTS) | v22.x (built on 22.18) | Runs the ServiceNow SDK / `now-sdk` CLI |
| **npm** | bundled with Node | Installs the project + SDK packages |
| **@servicenow/sdk** | 4.8.1 | The `now-sdk` CLI (build/install/transform) — global + devDependency |
| **@servicenow/glide** | 27.0.5 | Type support for server modules — devDependency |
| **A ServiceNow instance** | Zurich or later (a free PDI works) | Where the app is installed; admin login required |

Install:

```powershell
# 1) Node.js 22 LTS  -> https://nodejs.org  (or: winget install OpenJS.NodeJS.LTS)
node -v      # expect v22.x
npm -v

# 2) ServiceNow SDK CLI (global) — provides `now-sdk`
npm install -g @servicenow/sdk
now-sdk version

# 3) Project dependencies (run inside servicenow-fx-compare-match/)
cd servicenow-fx-compare-match
npm install          # installs @servicenow/sdk + @servicenow/glide from package.json

# 4) Authenticate to the instance (one-time; caches the "dev" auth alias)
now-sdk auth --add https://<your-instance>.service-now.com

# 5) Build & install the app
now-sdk build
now-sdk install --auth dev
```

---

## 2. Optional — Python (only to regenerate the golden-source seed)

`gen_golden.py` (workspace root) regenerates `src/fluent/data/golden-seed.now.ts`
from `FX_Options_Trade_masterDataset.xlsx`. **Not needed to build or run the app** —
the generated seed is already committed. Only run it if the master dataset changes.

| Tool | Version | Why |
|------|---------|-----|
| **Python** | 3.11+ (built on 3.13) | Runs `gen_golden.py` |
| **openpyxl** | >= 3.1 | Reads the master `.xlsx` (only third-party dep; `datetime`/`re` are stdlib) |

Install & run:

```powershell
pip install -r requirements.txt      # just openpyxl
python gen_golden.py                 # regenerates golden-seed.now.ts
```

---

## 3. Optional — developer tooling (recommended, not required)

| Tool | Version used | Why |
|------|--------------|-----|
| **Git** | 2.50 | Version control (repo not yet initialised) |
| **GitHub CLI (`gh`)** | 2.89 | GitHub auth / PRs |
| **VS Code** | latest | Editor |
| **ServiceNow SDK / Fluent VS Code extension** | latest | Syntax highlighting + Fluent validation |
| **Claude Code** | latest | AI-assisted authoring of the Fluent/JS source |

---

## 4. ServiceNow instance notes

- Release **Zurich or later** (the SDK/Fluent toolchain requires it).
- A **Personal Developer Instance (PDI)** is sufficient — no paid add-ons needed.
- Scope: `x_2112826_fxcm`. Admin login required for install.
- **No licensed components are used**: no Now Assist, no Document Intelligence,
  no IntegrationHub spokes, no Flow Designer. Pure core/rule-based platform.
- The Microsoft Graph mailbox sync uses a native **OAuth provider** (delegated,
  authorization-code) — configured in the instance UI, not a local dependency.

---

## TL;DR

- **Must install:** Node.js 22 + npm, then `npm install -g @servicenow/sdk`, then `npm install` in this folder. Plus a ServiceNow (Zurich+) instance.
- **Optional:** Python 3.11+ + `openpyxl` (only to regenerate the golden seed); Git/gh/VS Code for dev.

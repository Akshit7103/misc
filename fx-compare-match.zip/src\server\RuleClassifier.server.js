/**
 * RuleClassifier — deterministic keyword/regex classifier for FX settlement
 * emails. Direct port of classifier/rule_classifier.py from the
 * agentic-workflows app. Reads its keyword lists, weights, thresholds and
 * trade-id patterns from the x_2112826_fxcm_keyword / _settings /
 * _trade_id_pattern tables, so operations can tune it at runtime.
 *
 * Script Include class file: Glide APIs (GlideRecord, gs) are auto-available;
 * do NOT import them here.
 */
var RuleClassifier = Class.create();
RuleClassifier.prototype = {
    initialize: function () {
        this.cfg = this._loadConfig();
    },

    _loadConfig: function () {
        var cfg = {
            asset: [],
            subject: [],
            negative: [],
            patterns: [],
            asset_weight: 0.5,
            subject_weight: 0.3,
            trade_id_weight: 0.2,
            relevant_threshold: 0.7,
            ambiguous_threshold: 0.3,
            default_asset_class: 'FX Settlement',
            max_body_scan_chars: 2000,
        };

        var kw = new GlideRecord('x_2112826_fxcm_keyword');
        kw.query();
        while (kw.next()) {
            var type = kw.getValue('type');
            var value = (kw.getValue('value') || '').toLowerCase();
            if (!value) continue;
            if (type === 'asset') cfg.asset.push(value);
            else if (type === 'subject') cfg.subject.push(value);
            else if (type === 'negative') cfg.negative.push(value);
        }

        var pat = new GlideRecord('x_2112826_fxcm_trade_id_pattern');
        pat.orderBy('order');
        pat.query();
        while (pat.next()) {
            var p = pat.getValue('pattern');
            if (p) cfg.patterns.push(p);
        }

        var st = new GlideRecord('x_2112826_fxcm_settings');
        st.orderByDesc('sys_created_on');
        st.setLimit(1);
        st.query();
        if (st.next()) {
            cfg.asset_weight = this._num(st.getValue('asset_weight'), cfg.asset_weight);
            cfg.subject_weight = this._num(st.getValue('subject_weight'), cfg.subject_weight);
            cfg.trade_id_weight = this._num(st.getValue('trade_id_weight'), cfg.trade_id_weight);
            cfg.relevant_threshold = this._num(st.getValue('relevant_threshold'), cfg.relevant_threshold);
            cfg.ambiguous_threshold = this._num(st.getValue('ambiguous_threshold'), cfg.ambiguous_threshold);
            cfg.default_asset_class = st.getValue('default_asset_class') || cfg.default_asset_class;
            var mb = parseInt(st.getValue('max_body_scan_chars'), 10);
            if (!isNaN(mb)) cfg.max_body_scan_chars = mb;
        }
        return cfg;
    },

    _num: function (raw, fallback) {
        var f = parseFloat(raw);
        return isNaN(f) ? fallback : f;
    },

    _round2: function (n) {
        return Math.round(n * 100) / 100;
    },

    _hits: function (list, haystack) {
        var out = [];
        for (var i = 0; i < list.length; i++) {
            if (haystack.indexOf(list[i]) !== -1) out.push(list[i]);
        }
        return out;
    },

    extractTradeId: function (subject, body) {
        var text = (subject || '') + ' ' + (body || '').substring(0, this.cfg.max_body_scan_chars);
        for (var i = 0; i < this.cfg.patterns.length; i++) {
            try {
                var re = new RegExp(this.cfg.patterns[i], 'i');
                var m = re.exec(text);
                if (m) return m[0];
            } catch (e) {
                // skip an invalid pattern, mirroring the Python "never raise" contract
            }
        }
        return '';
    },

    /**
     * classify(subject, body) -> {
     *   label, confidence, reason, asset_class, matched_asset, matched_subject, trade_id
     * }
     */
    classify: function (subject, body) {
        var cfg = this.cfg;
        var subjectL = (subject || '').toLowerCase();
        var bodyL = (body || '').toLowerCase();
        var full = subjectL + ' ' + bodyL;

        var assetHits = this._hits(cfg.asset, full);
        var negHits = this._hits(cfg.negative, full);

        // Hard-negative early exit: a noise keyword and no FX-settlement signal.
        if (negHits.length > 0 && assetHits.length === 0) {
            return {
                label: 'IRRELEVANT',
                confidence: 0.9,
                reason: 'Negative keywords [' + negHits.join(', ') + '] and no asset signal',
                asset_class: 'Not Relevant',
                matched_asset: '',
                matched_subject: '',
                trade_id: '',
            };
        }

        var subjectHits = this._hits(cfg.subject, subjectL);
        var tradeId = this.extractTradeId(subject, body);

        var score = 0.0;
        var reasons = [];
        if (assetHits.length > 0) {
            score += cfg.asset_weight;
            reasons.push('asset[' + assetHits.join(', ') + ']');
        }
        if (subjectHits.length > 0) {
            score += cfg.subject_weight;
            reasons.push('subject[' + subjectHits.join(', ') + ']');
        }
        if (tradeId) {
            score += cfg.trade_id_weight;
            reasons.push('trade_id=' + tradeId);
        }

        var label, conf, assetClass;
        if (score >= cfg.relevant_threshold) {
            label = 'RELEVANT';
            conf = Math.min(score, 0.95);
            assetClass = cfg.default_asset_class;
        } else if (score >= cfg.ambiguous_threshold) {
            label = 'AMBIGUOUS';
            conf = this._round2(score);
            assetClass = 'Unknown';
        } else {
            label = 'IRRELEVANT';
            conf = this._round2(1 - score);
            assetClass = 'Not Relevant';
        }

        return {
            label: label,
            confidence: this._round2(conf),
            reason: reasons.length ? reasons.join('; ') : 'no signals matched',
            asset_class: assetClass,
            matched_asset: assetHits.join(', '),
            matched_subject: subjectHits.join(', '),
            trade_id: tradeId,
        };
    },

    type: 'RuleClassifier',
};

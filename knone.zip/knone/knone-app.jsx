
import { useState, useEffect, useCallback } from "react";

// ============================================================
// KNONE — Complete Platform Application
// Employer · Employee · Admin · Regulator portals
// All lifecycle stages, pages, and workflows
// ============================================================

const COLORS = {
  ink: "#0A0A0F",
  paper: "#F5F3EE",
  paperDark: "#ECEAE4",
  accent: "#C8431A",
  accentLight: "#F5E8E3",
  gold: "#B8941F",
  goldLight: "#F5EED8",
  teal: "#1A6B5C",
  tealLight: "#E1F0EB",
  slate: "#4A4A5A",
  muted: "#8A8A9A",
  border: "#D8D5CE",
  borderDark: "#B8B5AE",
  red: "#C8431A",
  amber: "#B8781A",
  green: "#1A6B5C",
  blue: "#1A4A8C",
  purple: "#5A3A8C",
  white: "#FFFFFF",
};

const RISK_COLORS = {
  critical: { bg: "#FCEBEB", text: "#A32D2D", border: "#E24B4A" },
  high: { bg: "#FAEEDA", text: "#854F0B", border: "#EF9F27" },
  moderate: { bg: "#E6F1FB", text: "#185FA5", border: "#378ADD" },
  low: { bg: "#E1F5EE", text: "#0F6E56", border: "#1D9E75" },
  clear: { bg: "#EAF3DE", text: "#3B6D11", border: "#6EA832" },
};

// ============================================================
// MOCK DATA
// ============================================================
const MOCK_CANDIDATES = [
  { pid: "7F3A·2B91", role: "VP Finance", score: 218, band: "critical", archetype: "The Fabricator", queried: "2h ago", signals: 6, employment: 3 },
  { pid: "A1C4·9D32", role: "Senior Analyst", score: 541, band: "moderate", archetype: "The Drifter", queried: "5h ago", signals: 2, employment: 4 },
  { pid: "B8F1·3E56", role: "Compliance Head", score: 847, band: "clear", archetype: "None", queried: "Yesterday", signals: 0, employment: 6 },
  { pid: "C3D9·7A11", role: "Relationship Mgr", score: 712, band: "low", archetype: "None", queried: "Yesterday", signals: 1, employment: 5 },
  { pid: "D4A2·6C78", role: "Operations Head", score: 901, band: "clear", archetype: "None", queried: "2 days ago", signals: 0, employment: 8 },
  { pid: "E9F3·1B44", role: "Treasury Analyst", score: 618, band: "moderate", archetype: "The Ghost", queried: "3 days ago", signals: 3, employment: 3 },
  { pid: "F2B7·4D19", role: "Credit Risk Mgr", score: 389, band: "high", archetype: "The Escalator", queried: "3 days ago", signals: 4, employment: 4 },
  { pid: "G1A3·5C22", role: "HR Business Partner", score: 778, band: "low", archetype: "None", queried: "1 week ago", signals: 1, employment: 7 },
];

const MOCK_SIGNALS = [
  { id: "S001", type: "CV misrepresentation — degree fabricated", category: "Integrity", severity: "critical", provenance: "Verified", date: "Jan 2022", weight: 1.0, desc: "Candidate claimed MBA from named institution. Direct verification found no record of attendance." },
  { id: "S002", type: "Data exfiltration on exit", category: "Conduct", severity: "critical", provenance: "Verified", date: "Mar 2021", weight: 1.0, desc: "Bulk download of client data in 72hr window before resignation. Confirmed by IT forensics." },
  { id: "S003", type: "IVA filed — individual voluntary arrangement", category: "Financial", severity: "high", provenance: "Verified · public record", date: "Mar 2023", weight: 0.82, desc: "IVA filed at NCLT Mumbai. Outstanding debt ₹18.4L. Settled Sep 2023.", rebuttal: "IVA settled in full as of September 2023. Certificate of completion available on request." },
  { id: "S004", type: "Ghost quit — disappeared without resignation", category: "Exit", severity: "high", provenance: "Verified", date: "Aug 2021", weight: 0.95, desc: "Stopped reporting, became uncontactable. No notice, no handover." },
  { id: "S005", type: "Repeated no-shows without notice", category: "Conduct", severity: "medium", provenance: "Asserted", date: "2022", weight: 0.45, desc: "7 unplanned absences over 4 months. No formal disciplinary outcome.", rebuttal: "Absences related to documented medical condition. All absences notified to line manager by phone." },
  { id: "S006", type: "Employer defamation on social media", category: "Digital", severity: "low", provenance: "Asserted", date: "Jan 2024", weight: 0.28, desc: "Public LinkedIn posts naming employer and making unverified allegations." },
];

const MOCK_EMPLOYEES = [
  { pid: "C3D9·7A11", role: "Relationship Manager", city: "Mumbai", score: 589, band: "moderate", trend: -123, alert: "urgent", lastSignal: "3 days ago" },
  { pid: "A1C4·9D32", role: "Senior Analyst", city: "Delhi", score: 541, band: "moderate", trend: -47, alert: "watch", lastSignal: "1 week ago" },
  { pid: "B8F1·3E56", role: "Compliance Head", city: "Bangalore", score: 847, band: "clear", trend: 0, alert: "none", lastSignal: "30 days ago" },
  { pid: "D4A2·6C78", role: "Operations Head", city: "Pune", score: 712, band: "low", trend: 0, alert: "none", lastSignal: "45 days ago" },
  { pid: "E9F3·1B44", role: "Treasury Head", city: "Mumbai", score: 901, band: "clear", trend: 12, alert: "none", lastSignal: "60 days ago" },
];

// ============================================================
// SHARED COMPONENTS
// ============================================================
const Badge = ({ children, variant = "gray", size = "sm" }) => {
  const variants = {
    red: { bg: "#FCEBEB", color: "#A32D2D" },
    amber: { bg: "#FAEEDA", color: "#854F0B" },
    blue: { bg: "#E6F1FB", color: "#185FA5" },
    teal: { bg: "#E1F5EE", color: "#0F6E56" },
    purple: { bg: "#EEEDFE", color: "#3C3489" },
    gray: { bg: "#F1EFE8", color: "#5F5E5A" },
    green: { bg: "#EAF3DE", color: "#3B6D11" },
    orange: { bg: "#FAECE7", color: "#712B13" },
  };
  const s = variants[variant] || variants.gray;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center",
      background: s.bg, color: s.color,
      padding: size === "sm" ? "2px 7px" : "4px 10px",
      borderRadius: 6, fontSize: size === "sm" ? 10 : 12,
      fontWeight: 500, whiteSpace: "nowrap",
    }}>{children}</span>
  );
};

const RiskBadge = ({ band }) => {
  const map = { critical: "red", high: "amber", moderate: "blue", low: "teal", clear: "green" };
  const labels = { critical: "Critical", high: "High", moderate: "Moderate", low: "Low risk", clear: "Clear" };
  return <Badge variant={map[band] || "gray"}>{labels[band] || band}</Badge>;
};

const ScoreRing = ({ score, band, size = 36 }) => {
  const colors = {
    critical: { border: "#E24B4A", color: "#A32D2D", bg: "#FCEBEB" },
    high: { border: "#EF9F27", color: "#854F0B", bg: "#FAEEDA" },
    moderate: { border: "#378ADD", color: "#185FA5", bg: "#E6F1FB" },
    low: { border: "#1D9E75", color: "#0F6E56", bg: "#E1F5EE" },
    clear: { border: "#6EA832", color: "#3B6D11", bg: "#EAF3DE" },
  };
  const c = colors[band] || colors.moderate;
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      border: `2px solid ${c.border}`, background: c.bg,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.28, fontWeight: 600, color: c.color, flexShrink: 0,
    }}>{score}</div>
  );
};

const Card = ({ children, style = {}, onClick }) => (
  <div onClick={onClick} style={{
    background: "#FFFFFF", border: `0.5px solid ${COLORS.border}`,
    borderRadius: 12, padding: "14px 16px",
    cursor: onClick ? "pointer" : "default",
    transition: onClick ? "border-color 0.15s, box-shadow 0.15s" : "none",
    ...style,
  }}
    onMouseEnter={e => { if (onClick) { e.currentTarget.style.borderColor = COLORS.borderDark; e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)"; } }}
    onMouseLeave={e => { if (onClick) { e.currentTarget.style.borderColor = COLORS.border; e.currentTarget.style.boxShadow = "none"; } }}
  >{children}</div>
);

const Btn = ({ children, onClick, variant = "primary", size = "md", style = {}, disabled = false }) => {
  const variants = {
    primary: { background: COLORS.ink, color: "#FFF", border: "none" },
    secondary: { background: "transparent", color: COLORS.slate, border: `0.5px solid ${COLORS.border}` },
    danger: { background: "#FCEBEB", color: "#A32D2D", border: "0.5px solid #F09595" },
    accent: { background: COLORS.accent, color: "#FFF", border: "none" },
    teal: { background: COLORS.teal, color: "#FFF", border: "none" },
  };
  const sizes = { sm: { padding: "4px 10px", fontSize: 11 }, md: { padding: "7px 16px", fontSize: 12 }, lg: { padding: "10px 22px", fontSize: 13 } };
  const v = variants[variant];
  const s = sizes[size];
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...v, ...s, borderRadius: 8, fontWeight: 500,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "inherit", transition: "opacity 0.15s, transform 0.1s",
      ...style,
    }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.opacity = "0.85"; }}
      onMouseLeave={e => { if (!disabled) e.currentTarget.style.opacity = "1"; }}
    >{children}</button>
  );
};

const Input = ({ label, placeholder, value, onChange, type = "text", style = {} }) => (
  <div style={{ marginBottom: 12 }}>
    {label && <label style={{ display: "block", fontSize: 11, fontWeight: 500, color: COLORS.slate, marginBottom: 5 }}>{label}</label>}
    <input
      type={type} placeholder={placeholder} value={value} onChange={onChange}
      style={{
        width: "100%", padding: "8px 11px",
        border: `0.5px solid ${COLORS.border}`, borderRadius: 8,
        fontSize: 12, fontFamily: "inherit", background: "#FFF",
        color: COLORS.ink, outline: "none", boxSizing: "border-box", ...style,
      }}
      onFocus={e => e.target.style.borderColor = COLORS.ink}
      onBlur={e => e.target.style.borderColor = COLORS.border}
    />
  </div>
);

const Select = ({ label, value, onChange, options }) => (
  <div style={{ marginBottom: 12 }}>
    {label && <label style={{ display: "block", fontSize: 11, fontWeight: 500, color: COLORS.slate, marginBottom: 5 }}>{label}</label>}
    <select value={value} onChange={onChange} style={{
      width: "100%", padding: "8px 11px",
      border: `0.5px solid ${COLORS.border}`, borderRadius: 8,
      fontSize: 12, fontFamily: "inherit", background: "#FFF",
      color: COLORS.ink, outline: "none",
    }}>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

const DomainBar = ({ label, score, maxScore = 100 }) => {
  const pct = (score / maxScore) * 100;
  const color = pct > 70 ? "#E24B4A" : pct > 50 ? "#EF9F27" : pct > 30 ? "#378ADD" : "#1D9E75";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}` }}>
      <span style={{ fontSize: 11, color: COLORS.muted, minWidth: 72 }}>{label}</span>
      <div style={{ flex: 1, height: 5, background: COLORS.paperDark, borderRadius: 3, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 3 }} />
      </div>
      <span style={{ fontSize: 11, fontWeight: 600, minWidth: 24, textAlign: "right", color }}>{score}</span>
    </div>
  );
};

const KpiCard = ({ label, value, delta, accentColor = COLORS.blue }) => (
  <div style={{
    background: COLORS.paper, borderRadius: 10, padding: "12px 14px",
    position: "relative", overflow: "hidden",
  }}>
    <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: accentColor, borderRadius: "3px 0 0 3px" }} />
    <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 3 }}>{label}</div>
    <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.ink, lineHeight: 1 }}>{value}</div>
    {delta && <div style={{ fontSize: 10, color: delta.startsWith("↑") ? COLORS.green : delta.startsWith("↓") ? COLORS.red : COLORS.muted, marginTop: 3 }}>{delta}</div>}
  </div>
);

const SectionLabel = ({ children }) => (
  <div style={{
    fontSize: 10, fontWeight: 600, color: COLORS.muted,
    letterSpacing: "0.08em", textTransform: "uppercase",
    marginBottom: 10, paddingBottom: 6,
    borderBottom: `0.5px solid ${COLORS.border}`,
  }}>{children}</div>
);

const Alert = ({ type = "info", title, body }) => {
  const types = {
    danger: { bg: "#FCEBEB", border: "#E24B4A", titleColor: "#A32D2D" },
    warning: { bg: "#FAEEDA", border: "#EF9F27", titleColor: "#854F0B" },
    info: { bg: "#E6F1FB", border: "#378ADD", titleColor: "#185FA5" },
    success: { bg: "#E1F5EE", border: "#1D9E75", titleColor: "#0F6E56" },
  };
  const s = types[type];
  return (
    <div style={{ background: s.bg, borderLeft: `3px solid ${s.border}`, borderRadius: 8, padding: "10px 13px", marginBottom: 8 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: s.titleColor, marginBottom: 3 }}>{title}</div>
      <div style={{ fontSize: 11, color: COLORS.slate, lineHeight: 1.5 }}>{body}</div>
    </div>
  );
};

const ProgressBar = ({ value, max = 100, color = COLORS.teal }) => (
  <div style={{ height: 5, background: COLORS.paperDark, borderRadius: 3, overflow: "hidden", flex: 1 }}>
    <div style={{ width: `${(value / max) * 100}%`, height: "100%", background: color, borderRadius: 3 }} />
  </div>
);

// ============================================================
// SIDEBAR
// ============================================================
const Sidebar = ({ userType, currentPage, setPage, collapsed }) => {
  const navItems = {
    employer: [
      { id: "home", icon: "⌂", label: "Dashboard" },
      { id: "query", icon: "⊕", label: "New Query" },
      { id: "reports", icon: "≡", label: "Reports" },
      { id: "monitoring", icon: "◎", label: "Monitoring" },
      { id: "submit-signal", icon: "↑", label: "Submit Signal" },
      { id: "analytics", icon: "↗", label: "Analytics" },
      { id: "team", icon: "◎", label: "Team Access" },
      { id: "billing", icon: "₹", label: "Billing" },
    ],
    employee: [
      { id: "my-record", icon: "◉", label: "My Record" },
      { id: "my-score", icon: "↗", label: "My Score" },
      { id: "signals", icon: "!", label: "Signals Filed" },
      { id: "rebuttals", icon: "↩", label: "Rebuttals" },
      { id: "consent", icon: "⚙", label: "Consent" },
      { id: "share", icon: "↗", label: "Share Record" },
      { id: "history", icon: "≡", label: "Query History" },
    ],
    admin: [
      { id: "admin-home", icon: "⌂", label: "Overview" },
      { id: "signal-queue", icon: "!", label: "Signal Queue" },
      { id: "disputes", icon: "⚖", label: "Disputes" },
      { id: "orgs", icon: "🏛", label: "Organisations" },
      { id: "scoring", icon: "⚡", label: "Scoring Engine" },
      { id: "security", icon: "⚔", label: "Security" },
      { id: "audit-log", icon: "≡", label: "Audit Log" },
    ],
    regulator: [
      { id: "reg-home", icon: "⌂", label: "Overview" },
      { id: "reg-reports", icon: "≡", label: "Reports" },
      { id: "sector-stats", icon: "↗", label: "Sector Stats" },
      { id: "compliance", icon: "⚖", label: "Compliance" },
      { id: "data-request", icon: "↓", label: "Data Request" },
    ],
  };

  const items = navItems[userType] || navItems.employer;

  return (
    <div style={{
      width: collapsed ? 52 : 200, flexShrink: 0,
      background: COLORS.ink, display: "flex", flexDirection: "column",
      alignItems: collapsed ? "center" : "flex-start",
      padding: "14px 0", gap: 2, transition: "width 0.2s",
      minHeight: "100vh",
    }}>
      <div style={{
        padding: collapsed ? "0 0 14px" : "0 16px 14px",
        borderBottom: `0.5px solid rgba(255,255,255,0.1)`,
        marginBottom: 8, width: "100%", textAlign: collapsed ? "center" : "left",
      }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#FFF", letterSpacing: "-0.01em" }}>
          <span style={{ color: "rgba(255,255,255,0.4)" }}>KN</span>ONE
        </div>
        {!collapsed && <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>
          {userType === "employer" ? "Employer Portal" : userType === "employee" ? "My Record" : userType === "admin" ? "Admin Console" : "Regulator Access"}
        </div>}
      </div>
      {items.map(item => (
        <button key={item.id} onClick={() => setPage(item.id)}
          style={{
            display: "flex", alignItems: "center", gap: collapsed ? 0 : 10,
            padding: collapsed ? "8px" : "8px 14px",
            width: collapsed ? "auto" : "calc(100% - 16px)", margin: "0 8px",
            borderRadius: 8, border: "none", cursor: "pointer", fontFamily: "inherit",
            background: currentPage === item.id ? "rgba(255,255,255,0.12)" : "transparent",
            color: currentPage === item.id ? "#FFF" : "rgba(255,255,255,0.5)",
            fontSize: 12, fontWeight: currentPage === item.id ? 600 : 400,
            transition: "all 0.15s", justifyContent: collapsed ? "center" : "flex-start",
          }}
          onMouseEnter={e => { if (currentPage !== item.id) e.currentTarget.style.background = "rgba(255,255,255,0.07)"; }}
          onMouseLeave={e => { if (currentPage !== item.id) e.currentTarget.style.background = "transparent"; }}
          title={collapsed ? item.label : ""}
        >
          <span style={{ fontSize: 15 }}>{item.icon}</span>
          {!collapsed && item.label}
        </button>
      ))}
    </div>
  );
};

// ============================================================
// TOPBAR
// ============================================================
const Topbar = ({ userType, orgName, userName, currentPage, pageLabels, onUserTypeChange, sidebarCollapsed, setSidebarCollapsed }) => {
  const [showMenu, setShowMenu] = useState(false);
  const userTypes = { employer: "Employer Portal", employee: "My Record", admin: "Admin Console", regulator: "Regulator Access" };

  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "10px 16px", background: "#FFF",
      borderBottom: `0.5px solid ${COLORS.border}`,
      position: "sticky", top: 0, zIndex: 100,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          style={{ border: "none", background: "transparent", cursor: "pointer", fontSize: 16, color: COLORS.muted, padding: 4 }}>
          ☰
        </button>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>{pageLabels[currentPage] || "Dashboard"}</div>
          <div style={{ fontSize: 10, color: COLORS.muted }}>{orgName} · {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "short", year: "numeric" })}</div>
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ position: "relative" }}>
          <select value={userType} onChange={e => onUserTypeChange(e.target.value)}
            style={{
              fontSize: 11, padding: "4px 10px", borderRadius: 20,
              border: `0.5px solid ${COLORS.border}`, background: COLORS.paper,
              color: COLORS.slate, cursor: "pointer", fontFamily: "inherit",
            }}>
            <option value="employer">Employer Portal</option>
            <option value="employee">Employee / Individual</option>
            <option value="admin">Admin Console</option>
            <option value="regulator">Regulator</option>
          </select>
        </div>
        <div style={{ fontSize: 10, padding: "3px 9px", borderRadius: 20, background: COLORS.goldLight, color: COLORS.gold, fontWeight: 500 }}>Premium</div>
        <div style={{ width: 30, height: 30, borderRadius: "50%", background: COLORS.ink, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#FFF", cursor: "pointer" }}>
          {userName.charAt(0)}
        </div>
      </div>
    </div>
  );
};

// ============================================================
// EMPLOYER PAGES
// ============================================================

// Home Dashboard
const EmployerHome = ({ setPage, setSelectedCandidate }) => {
  const stats = [
    { label: "Queries this month", value: "83", delta: "↑ 12 vs last month", color: COLORS.blue },
    { label: "Risk flags surfaced", value: "19", delta: "↓ 7 critical this month", color: COLORS.red },
    { label: "Clear candidates", value: "51", delta: "↑ 61% clear rate", color: COLORS.green },
    { label: "Signals contributed", value: "312", delta: "↑ 18 this month", color: COLORS.purple },
    { label: "Monitoring alerts", value: "3", delta: "↓ 2 require action", color: COLORS.amber },
  ];

  return (
    <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Search */}
      <div style={{ display: "flex", gap: 8 }}>
        <input placeholder="Quick KNONE check — enter PAN, Aadhaar, or passport number..."
          style={{ flex: 1, padding: "9px 13px", border: `0.5px solid ${COLORS.border}`, borderRadius: 9, fontSize: 12, fontFamily: "inherit", outline: "none" }}
          onFocus={e => e.target.style.borderColor = COLORS.ink}
          onBlur={e => e.target.style.borderColor = COLORS.border}
        />
        <Btn onClick={() => setPage("query")} variant="primary">Run KNONE check ↗</Btn>
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 8 }}>
        {stats.map(s => <KpiCard key={s.label} {...s} accentColor={s.color} />)}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 10 }}>
        {/* Recent queries */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>Recent queries</div>
            <button onClick={() => setPage("reports")} style={{ fontSize: 11, color: COLORS.blue, border: "none", background: "transparent", cursor: "pointer" }}>See all →</button>
          </div>
          {MOCK_CANDIDATES.slice(0, 6).map((c, i) => (
            <div key={c.pid} onClick={() => { setSelectedCandidate(c); setPage("candidate-report"); }}
              style={{ display: "grid", gridTemplateColumns: "24px 1fr 80px 44px 54px", gap: 8, alignItems: "center", padding: "7px 0", borderBottom: i < 5 ? `0.5px solid ${COLORS.border}` : "none", cursor: "pointer" }}
              onMouseEnter={e => e.currentTarget.style.background = COLORS.paper}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}
            >
              <div style={{ fontSize: 10, color: COLORS.muted, textAlign: "center" }}>{i + 1}</div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>PID · {c.pid}</div>
                <div style={{ fontSize: 10, color: COLORS.muted }}>{c.role} · {c.queried}</div>
              </div>
              <RiskBadge band={c.band} />
              <ScoreRing score={c.score} band={c.band} size={32} />
              <Btn size="sm" variant="secondary" onClick={e => { e.stopPropagation(); setSelectedCandidate(c); setPage("candidate-report"); }}>View</Btn>
            </div>
          ))}
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* Alerts */}
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>Active alerts</div>
              <button onClick={() => setPage("monitoring")} style={{ fontSize: 11, color: COLORS.blue, border: "none", background: "transparent", cursor: "pointer" }}>Monitoring →</button>
            </div>
            <Alert type="danger" title="Criminal record — new court filing" body="PID C3D9·7A11 · Relationship Manager · Filed 3 days post-hire" />
            <Alert type="warning" title="Financial stress escalation" body="PID A1C4·9D32 · Financial risk score 4→7 over 60 days" />
            <Alert type="info" title="Post-exit signal filed" body="PID F7B2·1C09 · Former employee · Under review" />
          </Card>

          {/* Risk distribution */}
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Risk bands — this month</div>
            {[
              { label: "Critical (0–300)", pct: 8, count: 7, color: "#E24B4A" },
              { label: "High (301–500)", pct: 14, count: 12, color: "#EF9F27" },
              { label: "Moderate (501–650)", pct: 26, count: 13, color: "#378ADD" },
              { label: "Low (651–800)", pct: 40, count: 36, color: "#1D9E75" },
              { label: "Clear (801–1000)", pct: 17, count: 15, color: "#9FE1CB" },
            ].map(r => (
              <div key={r.label} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ minWidth: 95, color: COLORS.muted }}>{r.label}</span>
                <ProgressBar value={r.pct} color={r.color} />
                <span style={{ fontWeight: 600, color: COLORS.ink, minWidth: 16 }}>{r.count}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>

      {/* Contribution status */}
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
          {[
            { label: "Signals contributed", value: "312", sub: "Target: 400/quarter" },
            { label: "Query credits used", value: "83/500", sub: "417 remaining this month" },
            { label: "Contribution rank", value: "Top 15%", sub: "vs BFSI peers" },
            { label: "Signal quality rating", value: "A−", sub: "71% verified signals" },
          ].map(s => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.ink, marginBottom: 2 }}>{s.value}</div>
              <div style={{ fontSize: 11, color: COLORS.slate, marginBottom: 2 }}>{s.label}</div>
              <div style={{ fontSize: 10, color: COLORS.muted }}>{s.sub}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

// Query Page
const QueryPage = ({ setPage, setSelectedCandidate }) => {
  const [step, setStep] = useState(1);
  const [docType, setDocType] = useState("aadhaar");
  const [docNum, setDocNum] = useState("");
  const [dob, setDob] = useState("");
  const [role, setRole] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const runQuery = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const candidate = MOCK_CANDIDATES[Math.floor(Math.random() * MOCK_CANDIDATES.length)];
      setResult(candidate);
      setStep(3);
    }, 1800);
  };

  if (step === 3 && result) {
    return (
      <div style={{ padding: 16, maxWidth: 700 }}>
        <SectionLabel>Query result</SectionLabel>
        <Card style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>KNONE check complete</div>
              <div style={{ fontSize: 11, color: COLORS.muted }}>Query ID: QRY-{Date.now().toString().slice(-8)}</div>
            </div>
            <RiskBadge band={result.band} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "16px 0", borderTop: `0.5px solid ${COLORS.border}`, borderBottom: `0.5px solid ${COLORS.border}`, marginBottom: 12 }}>
            <ScoreRing score={result.score} band={result.band} size={64} />
            <div>
              <div style={{ fontSize: 36, fontWeight: 700, color: result.band === "critical" ? COLORS.red : result.band === "high" ? COLORS.amber : result.band === "clear" ? COLORS.green : COLORS.blue }}>{result.score}</div>
              <div style={{ fontSize: 13, fontWeight: 500, color: COLORS.slate }}>KNONE Score · out of 1000</div>
              <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>Archetype: {result.archetype !== "None" ? <Badge variant="red">{result.archetype}</Badge> : <Badge variant="green">No archetype flagged</Badge>}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={() => { setSelectedCandidate(result); setPage("candidate-report"); }} variant="primary">View full report</Btn>
            <Btn onClick={() => { setStep(1); setResult(null); setDocNum(""); }} variant="secondary">Run another check</Btn>
            <Btn onClick={() => setPage("submit-signal")} variant="secondary">Submit signal</Btn>
          </div>
        </Card>
        {result.band === "critical" && (
          <Alert type="danger" title="Critical risk — immediate review required"
            body="This candidate has multiple verified adverse signals. Proceeding without a full compliance review carries significant legal and financial risk." />
        )}
      </div>
    );
  }

  return (
    <div style={{ padding: 16, maxWidth: 600 }}>
      <SectionLabel>Run a KNONE check</SectionLabel>
      <div style={{ display: "flex", gap: 0, marginBottom: 20, border: `0.5px solid ${COLORS.border}`, borderRadius: 10, overflow: "hidden" }}>
        {["Identify person", "Confirm query", "Result"].map((s, i) => (
          <div key={s} style={{
            flex: 1, padding: "10px", textAlign: "center", fontSize: 11,
            background: step === i + 1 ? COLORS.ink : step > i + 1 ? COLORS.paper : "#FFF",
            color: step === i + 1 ? "#FFF" : step > i + 1 ? COLORS.green : COLORS.muted,
            fontWeight: step === i + 1 ? 600 : 400,
            borderRight: i < 2 ? `0.5px solid ${COLORS.border}` : "none",
          }}>
            {step > i + 1 ? "✓ " : ""}{s}
          </div>
        ))}
      </div>

      {step === 1 && (
        <Card>
          <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink, marginBottom: 14 }}>Person identification</div>
          <Select label="Document type" value={docType} onChange={e => setDocType(e.target.value)}
            options={[{ value: "aadhaar", label: "Aadhaar number" }, { value: "pan", label: "PAN card" }, { value: "passport", label: "Passport number" }]} />
          <Input label="Document number" placeholder={docType === "aadhaar" ? "12-digit Aadhaar number" : docType === "pan" ? "10-character PAN" : "Passport number"} value={docNum} onChange={e => setDocNum(e.target.value)} />
          <Input label="Date of birth" type="date" value={dob} onChange={e => setDob(e.target.value)} />
          <Input label="Role being hired for (optional)" placeholder="e.g. VP Finance, Senior Analyst" value={role} onChange={e => setRole(e.target.value)} />
          <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 12, lineHeight: 1.5 }}>
            Document number and DOB are hashed using Argon2id before any query. Raw PII is never stored or transmitted.
          </div>
          <Btn onClick={() => setStep(2)} disabled={!docNum || !dob} variant="primary" style={{ width: "100%" }}>Identify and continue →</Btn>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink, marginBottom: 14 }}>Confirm query</div>
          <Alert type="info" title="Privacy-preserving query" body="Your query is being matched against pseudonymous PIDs only. No names or contact information are transmitted." />
          <div style={{ marginTop: 12, marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
              <span style={{ color: COLORS.muted }}>Document type</span>
              <span style={{ fontWeight: 500 }}>{docType.toUpperCase()}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
              <span style={{ color: COLORS.muted }}>Identity hash</span>
              <span style={{ fontFamily: "monospace", fontSize: 10, color: COLORS.muted }}>Argon2id · computing...</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
              <span style={{ color: COLORS.muted }}>Query cost</span>
              <span style={{ fontWeight: 500 }}>1 credit (482 remaining)</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: 11 }}>
              <span style={{ color: COLORS.muted }}>Data accessed</span>
              <span style={{ fontWeight: 500 }}>Standard — 7 domain scores + signals</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={() => setStep(1)} variant="secondary">← Back</Btn>
            <Btn onClick={runQuery} variant="primary" style={{ flex: 1 }} disabled={loading}>
              {loading ? "Running query..." : "Confirm and run KNONE check"}
            </Btn>
          </div>
          {loading && (
            <div style={{ marginTop: 12, textAlign: "center" }}>
              <div style={{ fontSize: 11, color: COLORS.muted }}>Matching identity hash · querying signal database · computing score...</div>
              <div style={{ height: 3, background: COLORS.paper, borderRadius: 2, marginTop: 8, overflow: "hidden" }}>
                <div style={{ height: "100%", background: COLORS.ink, borderRadius: 2, animation: "loading 1.5s ease-in-out infinite", width: "60%" }} />
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

// Candidate Report
const CandidateReport = ({ candidate, setPage }) => {
  const [activeTab, setActiveTab] = useState("signals");
  const c = candidate || MOCK_CANDIDATES[0];
  const tabs = ["signals", "history", "financial", "digital", "timeline"];
  const tabLabels = { signals: `Adverse signals (${MOCK_SIGNALS.length})`, history: "Employment history", financial: "Financial & lifestyle", digital: "Digital footprint", timeline: "Score timeline" };

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <Btn onClick={() => setPage("reports")} variant="secondary" size="sm">← Back</Btn>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>Candidate risk report — PID · {c.pid} · C04E</div>
          <div style={{ fontSize: 10, color: COLORS.muted }}>Queried today · {c.role} role · Query ID: QRY-20260505-0041</div>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <Btn size="sm" variant="secondary">Download PDF</Btn>
          <Btn size="sm" variant="secondary">Flag for review</Btn>
          <Btn size="sm" variant="primary">Add to monitoring</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 12, alignItems: "start" }}>
        {/* Left panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {c.band === "critical" && (
            <div style={{ background: "#FCEBEB", border: "0.5px solid #F09595", borderRadius: 10, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: "#A32D2D", marginBottom: 4 }}>⚠ Critical — do not proceed</div>
              <div style={{ fontSize: 11, color: "#791F1F", lineHeight: 1.5 }}>Multiple verified adverse signals across integrity and conduct categories.</div>
            </div>
          )}
          <Card>
            <div style={{ textAlign: "center", padding: "14px 0 10px" }}>
              <div style={{ fontSize: 52, fontWeight: 700, lineHeight: 1, color: c.band === "critical" ? "#A32D2D" : c.band === "high" ? "#854F0B" : c.band === "clear" ? "#0F6E56" : "#185FA5" }}>{c.score}</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.band === "critical" ? "#A32D2D" : COLORS.slate, marginTop: 3 }}>{c.band === "critical" ? "Critical risk band" : c.band === "clear" ? "Clear — low risk" : `${c.band.charAt(0).toUpperCase() + c.band.slice(1)} risk`}</div>
              <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 2 }}>KNONE score · out of 1000</div>
              <div style={{ height: 7, background: `linear-gradient(to right, #E24B4A, #EF9F27, #378ADD, #1D9E75)`, borderRadius: 4, margin: "10px 0 4px", position: "relative" }}>
                <div style={{ position: "absolute", top: -3, left: `${(c.score / 1000) * 100}%`, transform: "translateX(-50%)", width: 2, height: 13, background: COLORS.ink, borderRadius: 1 }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: COLORS.muted }}>
                <span>0</span><span>500</span><span>1000</span>
              </div>
            </div>
            {[
              ["Archetype", c.archetype !== "None" ? c.archetype : "—"],
              ["Score computed", "Today, 09:14"],
              ["Signal count", `${c.signals} total`],
              ["Time decay", "Applied"],
              ["Consent on file", "Not registered"],
            ].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ color: COLORS.muted }}>{k}</span>
                <span style={{ fontWeight: 500, color: COLORS.ink }}>{v}</span>
              </div>
            ))}
          </Card>
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Domain scores</div>
            <DomainBar label="Integrity" score={c.band === "critical" ? 89 : 12} />
            <DomainBar label="Conduct" score={c.band === "critical" ? 81 : 8} />
            <DomainBar label="Criminal" score={c.band === "critical" ? 72 : 5} />
            <DomainBar label="Financial" score={c.band === "critical" ? 58 : 18} />
            <DomainBar label="Lifestyle" score={c.band === "critical" ? 61 : 9} />
            <DomainBar label="Digital" score={c.band === "critical" ? 44 : 6} />
            <DomainBar label="Stability" score={c.band === "critical" ? 38 : 14} />
          </Card>
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Pattern flags</div>
            {[
              ["Job-hop velocity", c.band === "critical" ? <Badge variant="red">3 roles / 2 yrs</Badge> : <Badge variant="green">Stable</Badge>],
              ["Reference availability", c.band === "critical" ? <Badge variant="red">0 of 3</Badge> : <Badge variant="green">3 of 3</Badge>],
              ["Exit pattern", c.band === "critical" ? <Badge variant="red">2× ghost quit</Badge> : <Badge variant="green">Normal</Badge>],
              ["CV vs record gap", c.band === "critical" ? <Badge variant="red">14 months</Badge> : <Badge variant="green">Verified</Badge>],
              ["Signal provenance", c.band === "critical" ? <><Badge variant="red">4 verified</Badge> <Badge variant="amber">2 asserted</Badge></> : <Badge variant="green">Clean</Badge>],
            ].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ color: COLORS.muted }}>{k}</span>
                <span>{v}</span>
              </div>
            ))}
          </Card>
          <div style={{ fontSize: 10, color: COLORS.muted, lineHeight: 1.5, padding: "8px 10px", background: COLORS.paper, borderRadius: 8 }}>
            KNONE score is a risk indicator, not a veto. The hiring decision remains with the employer. The candidate has a right to view and contest this record.
          </div>
        </div>

        {/* Right panel */}
        <div>
          <div style={{ display: "flex", gap: 0, borderBottom: `0.5px solid ${COLORS.border}`, marginBottom: 14 }}>
            {tabs.map(t => (
              <button key={t} onClick={() => setActiveTab(t)}
                style={{
                  padding: "8px 12px", border: "none", background: "transparent", cursor: "pointer",
                  fontSize: 12, fontFamily: "inherit",
                  color: activeTab === t ? COLORS.blue : COLORS.muted,
                  fontWeight: activeTab === t ? 600 : 400,
                  borderBottom: activeTab === t ? `2px solid ${COLORS.blue}` : "2px solid transparent",
                  marginBottom: -1,
                }}
              >{tabLabels[t]}</button>
            ))}
          </div>

          {activeTab === "signals" && (
            <div>
              {(c.band === "critical" ? MOCK_SIGNALS : MOCK_SIGNALS.slice(4)).map(sig => (
                <div key={sig.id} style={{
                  border: `0.5px solid ${COLORS.border}`,
                  borderLeft: `3px solid ${sig.severity === "critical" ? "#E24B4A" : sig.severity === "high" ? "#EF9F27" : "#378ADD"}`,
                  borderRadius: 8, padding: "10px 13px", marginBottom: 8,
                }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8, marginBottom: 4 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>{sig.type}</div>
                    <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
                      <Badge variant={sig.provenance.includes("Verified") ? "red" : "amber"}>{sig.provenance.split("·")[0].trim()}</Badge>
                      <Badge variant={sig.severity === "critical" ? "red" : sig.severity === "high" ? "amber" : "blue"}>{sig.severity.charAt(0).toUpperCase() + sig.severity.slice(1)}</Badge>
                      <Badge variant="purple">{sig.category}</Badge>
                    </div>
                  </div>
                  <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 6 }}>
                    {sig.date} · Signal weight: {sig.weight} · {sig.provenance}
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.slate, lineHeight: 1.5, marginBottom: sig.rebuttal ? 8 : 0 }}>{sig.desc}</div>
                  {sig.rebuttal && (
                    <div style={{ background: COLORS.paper, borderRadius: 8, padding: "8px 10px", borderLeft: `2px solid ${COLORS.border}` }}>
                      <div style={{ fontSize: 9, fontWeight: 600, color: COLORS.blue, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 3 }}>Candidate rebuttal</div>
                      <div style={{ fontSize: 11, color: COLORS.slate, lineHeight: 1.4 }}>{sig.rebuttal}</div>
                    </div>
                  )}
                </div>
              ))}
              {c.band !== "critical" && (
                <Alert type="success" title="No significant adverse signals" body="This candidate has a clean employment record across all verified domains." />
              )}
            </div>
          )}

          {activeTab === "history" && (
            <div>
              <Card style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Employment timeline</div>
                {[
                  { period: "Jan 2023 – Dec 2023", role: "Regional Sales Director", tenure: "12 months", exitType: c.band === "critical" ? "Ghost quit" : "Resigned", rehire: c.band === "critical" ? "No" : "Yes" },
                  { period: "Mar 2021 – Aug 2021", role: "Senior Analyst", tenure: "5 months", exitType: c.band === "critical" ? "Ghost quit" : "Contract end", rehire: c.band === "critical" ? "No" : "Yes" },
                  { period: "Aug 2019 – Feb 2021", role: "Analyst", tenure: "18 months", exitType: "Resigned", rehire: "Conditional" },
                ].map((h, i) => (
                  <div key={i} style={{ display: "flex", gap: 12, paddingBottom: 12, position: "relative" }}>
                    <div style={{ width: 22, height: 22, borderRadius: "50%", background: h.exitType === "Ghost quit" ? "#FCEBEB" : COLORS.paper, border: `1px solid ${h.exitType === "Ghost quit" ? "#E24B4A" : COLORS.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, flexShrink: 0 }}>
                      {h.exitType === "Ghost quit" ? "✕" : "✓"}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>{h.role} — BFSI Co. (masked)</div>
                      <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 5 }}>{h.period} · {h.tenure}</div>
                      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                        <Badge variant={h.exitType === "Ghost quit" ? "red" : "teal"}>{h.exitType}</Badge>
                        <Badge variant={h.rehire === "No" ? "red" : h.rehire === "Conditional" ? "amber" : "teal"}>Rehire: {h.rehire}</Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </Card>
              <Card>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Employment summary</div>
                {[["Total verified employers", "3"], ["Average tenure", c.band === "critical" ? "11.7 months" : "26.4 months"], ["Rehire eligible", c.band === "critical" ? "No — 1 employer" : "Yes — all employers"], ["References available", c.band === "critical" ? "0 of 3" : "3 of 3"]].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                    <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
                  </div>
                ))}
              </Card>
            </div>
          )}

          {activeTab === "financial" && (
            <div>
              <Alert type="info" title="Premium data — Account Aggregator analysis" body="Financial scores derived from consented bank statement analysis via RBI Account Aggregator framework. Raw transactions never stored." />
              <Card style={{ marginTop: 10 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Bank statement analysis — 12 months</div>
                {[
                  { label: "Income stability", value: c.band === "critical" ? 3 : 8, max: 10 },
                  { label: "Debt service ratio", value: c.band === "critical" ? 74 : 28, max: 100, suffix: "%" },
                  { label: "Financial stress score", value: c.band === "critical" ? 8 : 2, max: 10 },
                  { label: "Savings rate", value: c.band === "critical" ? 8 : 42, max: 100, suffix: "%" },
                  { label: "Gambling spend", value: c.band === "critical" ? 7 : 1, max: 10 },
                  { label: "Alcohol spend", value: c.band === "critical" ? 4 : 1, max: 10 },
                ].map(m => (
                  <div key={m.label} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                    <span style={{ minWidth: 120, color: COLORS.muted }}>{m.label}</span>
                    <ProgressBar value={m.value} max={m.max || 10} color={m.value / (m.max || 10) > 0.6 ? "#E24B4A" : m.value / (m.max || 10) > 0.4 ? "#EF9F27" : "#1D9E75"} />
                    <span style={{ fontWeight: 600, minWidth: 30, textAlign: "right" }}>{m.value}{m.suffix || ""}</span>
                  </div>
                ))}
              </Card>
            </div>
          )}

          {activeTab === "digital" && (
            <div>
              <Card style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Social media and digital signals</div>
                <Alert type="warning" title="LinkedIn — employment discrepancy" body="Profile states 6 years experience. KNONE verified record shows 35 months across 3 employers. Discrepancy: 37 months." />
              </Card>
              <Card>
                <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Credential verification</div>
                {[
                  ["Degree claimed", "MBA Finance"],
                  ["Verification result", c.band === "critical" ? "Not verified — no record" : "Verified ✓"],
                  ["UGC database check", c.band === "critical" ? "Institution doesn't offer programme" : "Passed"],
                  ["Identity document", "Aadhaar — verified ✓"],
                  ["PAN verified", "Active — NSDL confirmed ✓"],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                    <span style={{ color: COLORS.muted }}>{k}</span>
                    <span style={{ fontWeight: 500, color: v.includes("Not verified") || v.includes("doesn't") ? "#A32D2D" : COLORS.ink }}>{v}</span>
                  </div>
                ))}
              </Card>
            </div>
          )}

          {activeTab === "timeline" && (
            <Card>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Score history — how this candidate's score has changed</div>
              <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 100, paddingTop: 8, marginBottom: 6 }}>
                {[612, 519, 481, 441, 398, 342, 281, c.score].map((s, i) => {
                  const h = (s / 1000) * 100;
                  const color = s > 700 ? "#1D9E75" : s > 500 ? "#378ADD" : s > 300 ? "#EF9F27" : "#E24B4A";
                  return (
                    <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
                      <div style={{ fontSize: 9, color, marginBottom: 3 }}>{s}</div>
                      <div style={{ width: "100%", height: `${h}%`, background: i === 7 ? color : `${color}80`, borderRadius: "2px 2px 0 0" }} />
                    </div>
                  );
                })}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: COLORS.muted, marginBottom: 12 }}>
                {["Oct 23", "Jan 24", "Apr 24", "Jul 24", "Oct 24", "Jan 25", "Apr 25", "Today"].map(d => <span key={d}>{d}</span>)}
              </div>
              {[
                ["Oct 2023", "Score initialised at 612 (Low)"],
                ["Jan 2024", "−93 pts — Data exfiltration signal"],
                ["Apr 2024", "−38 pts — Ghost quit signal added"],
                ["Aug 2024", "−43 pts — CV fabrication verified"],
                ["Nov 2024", "−56 pts — IVA public record ingested"],
                ["Feb 2025", "−61 pts — Second data exfiltration"],
                ["Today", `Current score: ${c.score}`],
              ].map(([d, e]) => (
                <div key={d} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                  <span style={{ color: COLORS.muted, minWidth: 80 }}>{d}</span>
                  <span style={{ color: COLORS.ink }}>{e}</span>
                </div>
              ))}
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

// Reports Page
const ReportsPage = ({ setPage, setSelectedCandidate }) => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filtered = MOCK_CANDIDATES.filter(c => {
    const matchSearch = c.pid.toLowerCase().includes(search.toLowerCase()) || c.role.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || c.band === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div style={{ padding: 16 }}>
      <SectionLabel>All KNONE reports</SectionLabel>
      <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
        <input placeholder="Search by PID or role..."
          value={search} onChange={e => setSearch(e.target.value)}
          style={{ flex: 1, minWidth: 200, padding: "7px 11px", border: `0.5px solid ${COLORS.border}`, borderRadius: 8, fontSize: 12, fontFamily: "inherit", outline: "none" }} />
        {["all", "critical", "high", "moderate", "low", "clear"].map(f => (
          <Btn key={f} onClick={() => setFilter(f)} variant={filter === f ? "primary" : "secondary"} size="sm">
            {f === "all" ? "All" : f.charAt(0).toUpperCase() + f.slice(1)}
          </Btn>
        ))}
        <Btn onClick={() => setPage("query")} variant="accent" size="sm">+ New query</Btn>
      </div>
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "28px 1fr 90px 50px 110px 70px 54px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
          <div>#</div><div>PID / Role</div><div>Risk band</div><div>Score</div><div>Signals</div><div>Queried</div><div></div>
        </div>
        {filtered.map((c, i) => (
          <div key={c.pid}
            style={{ display: "grid", gridTemplateColumns: "28px 1fr 90px 50px 110px 70px 54px", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: i < filtered.length - 1 ? `0.5px solid ${COLORS.border}` : "none", cursor: "pointer" }}
            onClick={() => { setSelectedCandidate(c); setPage("candidate-report"); }}
            onMouseEnter={e => e.currentTarget.style.background = COLORS.paper}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >
            <div style={{ fontSize: 10, color: COLORS.muted, textAlign: "center" }}>{i + 1}</div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>PID · {c.pid}</div>
              <div style={{ fontSize: 10, color: COLORS.muted }}>{c.role}</div>
            </div>
            <RiskBadge band={c.band} />
            <div style={{ fontSize: 12, fontWeight: 700, color: c.band === "critical" ? "#A32D2D" : c.band === "clear" ? "#0F6E56" : COLORS.ink }}>{c.score}</div>
            <div style={{ display: "flex", gap: 4 }}>
              <Badge variant={c.signals > 3 ? "red" : c.signals > 1 ? "amber" : "gray"}>{c.signals} signal{c.signals !== 1 ? "s" : ""}</Badge>
            </div>
            <div style={{ fontSize: 11, color: COLORS.muted }}>{c.queried}</div>
            <Btn size="sm" variant="secondary" onClick={e => { e.stopPropagation(); setSelectedCandidate(c); setPage("candidate-report"); }}>View</Btn>
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{ padding: "20px", textAlign: "center", color: COLORS.muted, fontSize: 12 }}>No results match your search or filter.</div>
        )}
      </Card>
    </div>
  );
};

// Signal Submission
const SubmitSignalPage = () => {
  const [step, setStep] = useState(2);
  const [category, setCategory] = useState("Conduct");
  const [severity, setSeverity] = useState("critical");
  const [provenance, setProvenance] = useState("verified-hr");
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div style={{ padding: 16, maxWidth: 600 }}>
        <div style={{ textAlign: "center", padding: "40px 20px" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✓</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: COLORS.ink, marginBottom: 8 }}>Signal submitted successfully</div>
          <div style={{ fontSize: 12, color: COLORS.muted, lineHeight: 1.6, marginBottom: 24 }}>Your signal has been submitted to KNONE's compliance review team. Verified signals are processed within 24 hours. The signal will impact the candidate's score once verified.</div>
          <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
            <Btn onClick={() => { setSubmitted(false); setStep(2); }} variant="primary">Submit another signal</Btn>
            <Btn onClick={() => setSubmitted(false)} variant="secondary">Return to home</Btn>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: 16, maxWidth: 820 }}>
      <SectionLabel>Submit adverse signal</SectionLabel>
      <div style={{ display: "flex", gap: 0, marginBottom: 20, background: COLORS.paper, borderRadius: 10, overflow: "hidden", border: `0.5px solid ${COLORS.border}` }}>
        {["Identify person", "Signal details", "Evidence", "Review & submit"].map((s, i) => (
          <div key={s} style={{
            flex: 1, padding: "10px", textAlign: "center", fontSize: 11,
            background: step === i + 1 ? COLORS.ink : step > i + 1 ? COLORS.tealLight : "transparent",
            color: step === i + 1 ? "#FFF" : step > i + 1 ? COLORS.teal : COLORS.muted,
            fontWeight: step === i + 1 ? 600 : 400,
            borderRight: i < 3 ? `0.5px solid ${COLORS.border}` : "none",
          }}>{step > i + 1 ? "✓ " : ""}{s}</div>
        ))}
      </div>

      {step === 2 && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, alignItems: "start" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Alert type="success" title="Person identified — step 1 complete"
              body="PID · A1C4 · 9D32 · E7F1 · Identity verified via Aadhaar eKYC · 2 existing signals · Current score: 541 (Elevated)" />
            <Card>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Signal category</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6 }}>
                {[{ icon: "⚠", label: "Conduct" }, { icon: "⚖", label: "Integrity" }, { icon: "⚡", label: "Criminal" }, { icon: "₹", label: "Financial" }, { icon: "↗", label: "Exit" }, { icon: "◎", label: "Digital" }].map(c => (
                  <div key={c.label} onClick={() => setCategory(c.label)}
                    style={{
                      border: `0.5px solid ${category === c.label ? COLORS.blue : COLORS.border}`,
                      background: category === c.label ? "#E6F1FB" : "#FFF",
                      borderRadius: 8, padding: "9px 8px", textAlign: "center",
                      cursor: "pointer", fontSize: 11,
                      color: category === c.label ? COLORS.blue : COLORS.slate, fontWeight: category === c.label ? 600 : 400,
                    }}>
                    <div style={{ fontSize: 18, marginBottom: 3 }}>{c.icon}</div>
                    {c.label}
                  </div>
                ))}
              </div>
            </Card>
            <Card>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Severity</div>
              {[
                { id: "critical", label: "Critical", desc: "Fraud, data theft, criminal conviction" },
                { id: "high", label: "High", desc: "Upheld complaints, serious misconduct" },
                { id: "medium", label: "Medium", desc: "Repeated behaviour, pattern to watch" },
                { id: "low", label: "Low", desc: "Soft signal, contextual, minor" },
              ].map(s => (
                <div key={s.id} onClick={() => setSeverity(s.id)}
                  style={{
                    border: `0.5px solid ${severity === s.id ? "#E24B4A" : COLORS.border}`,
                    background: severity === s.id ? "#FCEBEB" : "#FFF",
                    borderRadius: 8, padding: "8px 10px", marginBottom: 6, cursor: "pointer",
                  }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: severity === s.id ? "#A32D2D" : COLORS.ink }}>{s.label}</div>
                  <div style={{ fontSize: 10, color: COLORS.muted }}>{s.desc}</div>
                </div>
              ))}
            </Card>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Card>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Provenance</div>
              {[
                { id: "verified-hr", label: "Verified — HR record / documented outcome", desc: "Supported by formal HR file, disciplinary letter, IT forensics. Maximum signal weight." },
                { id: "verified-legal", label: "Verified — disciplinary or legal outcome", desc: "Court judgment, employment tribunal ruling, regulatory finding. Publicly verifiable." },
                { id: "asserted", label: "Asserted — employer-reported, not formally upheld", desc: "Observed internally but not subject to formal proceedings. Reduced weight (0.35–0.55)." },
              ].map(p => (
                <div key={p.id} onClick={() => setProvenance(p.id)}
                  style={{
                    border: `0.5px solid ${provenance === p.id ? COLORS.blue : COLORS.border}`,
                    background: provenance === p.id ? "#E6F1FB" : "#FFF",
                    borderRadius: 8, padding: "10px 12px", marginBottom: 8, cursor: "pointer",
                  }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: provenance === p.id ? COLORS.blue : COLORS.ink, marginBottom: 2 }}>{p.label}</div>
                  <div style={{ fontSize: 10, color: COLORS.muted, lineHeight: 1.4 }}>{p.desc}</div>
                </div>
              ))}
            </Card>
            <Card>
              <Select label="Signal type" value="data-exfil" onChange={() => { }}
                options={[{ value: "data-exfil", label: "Data exfiltration on exit" }, { value: "expense-fraud", label: "Expense fraud" }, { value: "harassment", label: "Harassment complaint upheld" }, { value: "cv-misrep", label: "CV misrepresentation" }, { value: "ghost-quit", label: "Ghost quit" }]} />
              <Input label="Event date" type="date" value="2024-09-15" onChange={() => { }} />
              <Select label="Outcome / consequence" value="dismissed" onChange={() => { }}
                options={[{ value: "dismissed", label: "Dismissed for cause" }, { value: "resigned", label: "Resigned before disciplinary conclusion" }, { value: "warning", label: "Formal warning issued" }, { value: "no-action", label: "No formal action — internal record only" }]} />
              <Select label="Rehire eligible?" value="no" onChange={() => { }}
                options={[{ value: "no", label: "No — would not rehire" }, { value: "conditional", label: "Yes — with written conditions" }, { value: "prefer-not", label: "Prefer not to say" }]} />
            </Card>
            <Alert type="warning" title="Your legal position"
              body="As the submitting organisation, you hold liability for asserted signals. All submissions are timestamped and immutable. False or malicious submissions may result in platform removal and legal referral." />
            <div style={{ display: "flex", gap: 8 }}>
              <Btn onClick={() => setStep(1)} variant="secondary">← Back</Btn>
              <Btn onClick={() => setStep(3)} variant="primary" style={{ flex: 1 }}>Continue to evidence →</Btn>
            </div>
          </div>
        </div>
      )}

      {(step === 3 || step === 4) && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Supporting evidence</div>
            <div style={{ border: `1px dashed ${COLORS.border}`, borderRadius: 8, padding: "28px", textAlign: "center", fontSize: 12, color: COLORS.muted, marginBottom: 10, cursor: "pointer" }}
              onMouseEnter={e => e.currentTarget.style.background = COLORS.paper}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
              Drop HR record, disciplinary letter, or court document here
              <div style={{ fontSize: 10, marginTop: 4 }}>PDF, JPG, PNG · max 10MB · AES-256 encrypted on upload</div>
            </div>
            <div style={{ background: COLORS.paper, borderRadius: 8, padding: "7px 10px", display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <div style={{ fontSize: 14 }}>📄</div>
              <div style={{ flex: 1, fontSize: 11 }}>dismissal_letter_sept2024.pdf</div>
              <div style={{ fontSize: 10, color: COLORS.muted }}>340KB</div>
              <div style={{ fontSize: 10, color: COLORS.green }}>✓ Encrypted</div>
            </div>
            <div style={{ fontSize: 10, color: COLORS.muted, lineHeight: 1.5 }}>Verified evidence elevates signal provenance and increases weight. Raw document is encrypted at rest and visible only to KNONE's compliance team.</div>
          </Card>
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Review and submit</div>
            {[["PID", "A1C4 · 9D32 · E7F1"], ["Category", category], ["Signal type", "Data exfiltration on exit"], ["Severity", severity.charAt(0).toUpperCase() + severity.slice(1)], ["Provenance", "Verified — HR record"], ["Evidence", "1 document attached"], ["Rehire eligible", "No"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
              </div>
            ))}
            <div style={{ marginTop: 12 }}>
              {["I confirm this signal is accurate and filed in good faith", "I understand I hold liability for asserted signals", "I have obtained necessary authorisation to file this signal"].map(c => (
                <div key={c} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "5px 0", fontSize: 11 }}>
                  <div style={{ width: 16, height: 16, borderRadius: 3, background: COLORS.tealLight, border: `1.5px solid ${COLORS.teal}`, display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.teal, fontSize: 10, flexShrink: 0 }}>✓</div>
                  <span style={{ color: COLORS.slate, lineHeight: 1.4 }}>{c}</span>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
              <Btn onClick={() => setStep(2)} variant="secondary">← Back</Btn>
              <Btn onClick={() => setSubmitted(true)} variant="teal" style={{ flex: 1 }}>Submit signal to KNONE ↑</Btn>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

// Monitoring Page
const MonitoringPage = ({ setPage, setSelectedCandidate }) => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Post-hire monitoring</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="Employees monitored" value="68" delta="↑ 5 added this month" accentColor={COLORS.purple} />
      <KpiCard label="Active alerts" value="3" delta="↓ 2 require action now" accentColor={COLORS.red} />
      <KpiCard label="Score movements" value="11" delta="↓ 8 worsened this month" accentColor={COLORS.amber} />
      <KpiCard label="Est. risk avoided" value="₹42L" delta="↑ since programme start" accentColor={COLORS.green} />
    </div>

    <Card style={{ marginBottom: 12 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>Active alerts — requires your attention</div>
      <Alert type="danger" title="Criminal record — new court filing detected"
        body="PID C3D9·7A11 · Relationship Manager · Mumbai · Cheque dishonour case filed at Andheri Court 3 days after joining. Score dropped 712→589. Probation confirmation pending." />
      <Alert type="warning" title="Financial stress escalation"
        body="PID A1C4·9D32 · Senior Analyst · Delhi · Financial risk score moved 4→7 over 60 days. Debt service ratio exceeding 72%. Employee holds access to client financial data." />
      <Alert type="info" title="Post-exit signal filed by new employer"
        body="PID F7B2·1C09 · Former employee · Conduct signal filed by subsequent employer. Under KNONE verification review. No score impact until verified." />
    </Card>

    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12, alignItems: "center" }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>All monitored employees</div>
        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="Search by PID or department..." style={{ padding: "5px 10px", border: `0.5px solid ${COLORS.border}`, borderRadius: 8, fontSize: 11, fontFamily: "inherit", outline: "none", width: 180 }} />
          <Btn size="sm" variant="primary">+ Add employee</Btn>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "36px 1fr 100px 100px 70px 60px 50px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
        <div></div><div>Employee / role</div><div>KNONE score</div><div>30-day trend</div><div>Last signal</div><div>Alert</div><div></div>
      </div>
      {MOCK_EMPLOYEES.map(e => (
        <div key={e.pid}
          style={{ display: "grid", gridTemplateColumns: "36px 1fr 100px 100px 70px 60px 50px", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, cursor: "pointer" }}
          onMouseEnter={ev => ev.currentTarget.style.background = COLORS.paper}
          onMouseLeave={ev => ev.currentTarget.style.background = "transparent"}
          onClick={() => { setSelectedCandidate(MOCK_CANDIDATES.find(c => c.pid === e.pid) || MOCK_CANDIDATES[1]); setPage("candidate-report"); }}
        >
          <ScoreRing score={e.score} band={e.band} size={28} />
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>PID {e.pid}</div>
            <div style={{ fontSize: 10, color: COLORS.muted }}>{e.role} · {e.city}</div>
          </div>
          <RiskBadge band={e.band} />
          <div style={{ fontSize: 11, fontWeight: 500, color: e.trend < 0 ? "#A32D2D" : e.trend > 0 ? COLORS.green : COLORS.muted }}>
            {e.trend < 0 ? `↑ ${Math.abs(e.trend)} pts worse` : e.trend > 0 ? `↓ +${e.trend} pts better` : "— no change"}
          </div>
          <div style={{ fontSize: 11, color: COLORS.muted }}>{e.lastSignal}</div>
          <Badge variant={e.alert === "urgent" ? "red" : e.alert === "watch" ? "amber" : "gray"}>
            {e.alert === "urgent" ? "Urgent" : e.alert === "watch" ? "Watch" : "None"}
          </Badge>
          <Btn size="sm" variant="secondary">View</Btn>
        </div>
      ))}
    </Card>
  </div>
);

// Analytics Page
const AnalyticsPage = () => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Analytics — 12 months</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="Total queries — 12m" value="1,247" delta="↑ 34% vs prior year" accentColor={COLORS.blue} />
      <KpiCard label="Risk flags surfaced" value="94" delta="7.5% flag rate" accentColor={COLORS.red} />
      <KpiCard label="Signals contributed" value="312" delta="Contribution ratio: 0.25" accentColor={COLORS.teal} />
      <KpiCard label="Est. bad hires avoided" value="11" delta="≈ ₹2.3Cr saved" accentColor={COLORS.purple} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Monthly query volume — 12 months</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 80, paddingTop: 8 }}>
          {[62, 71, 58, 84, 79, 95, 68, 102, 91, 110, 97, 83].map((v, i) => (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
              <div style={{ fontSize: 8, color: COLORS.muted }}>{v}</div>
              <div style={{ width: "100%", height: `${(v / 110) * 100}%`, background: i === 9 || i === 11 ? COLORS.blue : `${COLORS.blue}50`, borderRadius: "2px 2px 0 0" }} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, fontSize: 9, color: COLORS.muted }}>
          {["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"].map(m => <span key={m}>{m}</span>)}
        </div>
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Sector benchmark — BFSI</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 60px 60px 60px", gap: 8, padding: "4px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
          <div>Metric</div><div style={{ textAlign: "right" }}>You</div><div style={{ textAlign: "right" }}>Sector</div><div style={{ textAlign: "right" }}>Top 10%</div>
        </div>
        {[["Flag rate", "7.5%", "8.2%", "5.1%"], ["Clear rate", "67%", "65%", "74%"], ["Avg query/hire", "1.2", "1.8", "1.0"], ["Contribution ratio", "0.25", "0.18", "0.42"], ["Signal quality", "A−", "B+", "A+"]].map(([k, y, s, t]) => (
          <div key={k} style={{ display: "grid", gridTemplateColumns: "1fr 60px 60px 60px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ color: COLORS.muted }}>{k}</span>
            <span style={{ fontWeight: 600, textAlign: "right", color: COLORS.ink }}>{y}</span>
            <span style={{ textAlign: "right", color: COLORS.muted }}>{s}</span>
            <span style={{ textAlign: "right", color: COLORS.green }}>{t}</span>
          </div>
        ))}
      </Card>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Top signal types surfaced</div>
        {[["CV fabrication", 31, "#E24B4A"], ["Ghost quit", 26, "#EF9F27"], ["Data exfiltration", 21, "#E24B4A"], ["Financial flags", 18, "#EF9F27"], ["Conduct complaints", 14, "#378ADD"]].map(([l, v, c]) => (
          <div key={l} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ flex: 1, color: COLORS.muted }}>{l}</span>
            <ProgressBar value={v} max={35} color={c} />
            <span style={{ fontWeight: 600, minWidth: 20, textAlign: "right" }}>{v}</span>
          </div>
        ))}
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Risk by role level</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 80 }}>
          {[{ l: "Exec", v: 18, c: "#E24B4A" }, { l: "Senior", v: 12, c: "#EF9F27" }, { l: "Mid", v: 9, c: "#EF9F27" }, { l: "Junior", v: 5, c: "#378ADD" }, { l: "Intern", v: 3, c: "#1D9E75" }].map(r => (
            <div key={r.l} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
              <div style={{ fontSize: 9, color: r.c, fontWeight: 600 }}>{r.v}%</div>
              <div style={{ width: "100%", height: `${(r.v / 20) * 100}%`, background: r.c, borderRadius: "2px 2px 0 0" }} />
              <div style={{ fontSize: 9, color: COLORS.muted }}>{r.l}</div>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 8 }}>Flag rate highest at executive level — 18% of C-suite queries return elevated or higher</div>
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>KNONE insights</div>
        {[
          { title: "CV fabrication rate 2.5× national average", body: "31 of 94 flagged candidates had degree fabrication. Consider pre-screening at application stage." },
          { title: "Financial stress correlates with data exfiltration", body: "Candidates with financial risk >6 are 3.1× more likely to have a data exfiltration signal." },
          { title: "Signal quality improved 18% this quarter", body: "Signals with evidence docs accepted at 96% vs 78% without. Training programme effective." },
        ].map(i => (
          <div key={i.title} style={{ background: COLORS.paper, borderRadius: 8, padding: "8px 10px", marginBottom: 6 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink, marginBottom: 2 }}>{i.title}</div>
            <div style={{ fontSize: 11, color: COLORS.muted, lineHeight: 1.4 }}>{i.body}</div>
          </div>
        ))}
      </Card>
    </div>
  </div>
);

// Team Access Page
const TeamPage = () => {
  const [showInvite, setShowInvite] = useState(false);
  const members = [
    { name: "Rahul Kumar", email: "rahul.kumar@apex.com", role: "Admin", access: "Full access", lastLogin: "2h ago" },
    { name: "Priya Sharma", email: "priya.sharma@apex.com", role: "CHRO", access: "Full access", lastLogin: "1 day ago" },
    { name: "Ankit Verma", email: "ankit.verma@apex.com", role: "HR Ops", access: "Query + Submit", lastLogin: "30 min ago" },
    { name: "Rohan Malhotra", email: "rohan.m@apex.com", role: "TA Lead", access: "Query only", lastLogin: "3h ago" },
    { name: "Deepa K", email: "deepa.k@apex.com", role: "Compliance", access: "Full + Audit", lastLogin: "Yesterday" },
  ];
  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
        <SectionLabel>Team access</SectionLabel>
        <Btn onClick={() => setShowInvite(!showInvite)} variant="primary" size="sm">+ Invite team member</Btn>
      </div>
      {showInvite && (
        <Card style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Invite new team member</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <Input label="Full name" placeholder="e.g. Siddharth Joshi" value="" onChange={() => { }} />
            <Input label="Work email" placeholder="siddharth@apex.com" type="email" value="" onChange={() => { }} />
            <Select label="Role / permission level" value="hr-ops" onChange={() => { }}
              options={[{ value: "admin", label: "Admin — full access" }, { value: "hr-ops", label: "HR Ops — query + submit signals" }, { value: "ta", label: "TA — query only" }, { value: "compliance", label: "Compliance — full + audit export" }]} />
            <Select label="Department" value="hr" onChange={() => { }}
              options={[{ value: "hr", label: "HR / People" }, { value: "compliance", label: "Compliance / Legal" }, { value: "ta", label: "Talent Acquisition" }, { value: "mgmt", label: "Management" }]} />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn onClick={() => setShowInvite(false)} variant="secondary">Cancel</Btn>
            <Btn variant="primary">Send invite</Btn>
          </div>
        </Card>
      )}
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 80px 120px 80px 60px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
          <div>Name</div><div>Email</div><div>Role</div><div>Access level</div><div>Last login</div><div></div>
        </div>
        {members.map(m => (
          <div key={m.email} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 80px 120px 80px 60px", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <div style={{ fontWeight: 600, color: COLORS.ink }}>{m.name}</div>
            <div style={{ color: COLORS.muted }}>{m.email}</div>
            <Badge variant="gray">{m.role}</Badge>
            <Badge variant={m.access.includes("Full") ? "teal" : "blue"}>{m.access}</Badge>
            <div style={{ color: COLORS.muted }}>{m.lastLogin}</div>
            <Btn size="sm" variant="secondary">Edit</Btn>
          </div>
        ))}
      </Card>
    </div>
  );
};

// Billing Page
const BillingPage = () => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Billing and subscription</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Current plan</div>
        <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.gold, marginBottom: 4 }}>Premium</div>
        <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 12 }}>₹14,999/month · billed monthly · next billing: 1 Jun 2026</div>
        {[["Query credits", "500 / month (482 remaining)"], ["Monitoring", "Up to 100 employees"], ["Domain scores", "All 7 domains"], ["Bank analysis", "Included (consent required)"], ["API access", "Included"], ["Support", "Priority support + CSM"]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
          </div>
        ))}
        <Btn variant="secondary" style={{ marginTop: 12, width: "100%" }}>Upgrade to Enterprise</Btn>
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Usage this month</div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, marginBottom: 4 }}>
          <span style={{ fontSize: 11, color: COLORS.muted, flex: 1 }}>Queries used</span>
          <ProgressBar value={83} max={500} color={COLORS.blue} />
          <span style={{ fontSize: 11, fontWeight: 600 }}>83/500</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, marginBottom: 4 }}>
          <span style={{ fontSize: 11, color: COLORS.muted, flex: 1 }}>Employees monitored</span>
          <ProgressBar value={68} max={100} color={COLORS.teal} />
          <span style={{ fontSize: 11, fontWeight: 600 }}>68/100</span>
        </div>
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink, marginBottom: 6 }}>Recent invoices</div>
          {[["May 2026", "₹14,999", "Paid"], ["Apr 2026", "₹14,999", "Paid"], ["Mar 2026", "₹16,892", "Paid (with overage)"]].map(([m, a, s]) => (
            <div key={m} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
              <span style={{ color: COLORS.muted }}>{m}</span>
              <span style={{ fontWeight: 500 }}>{a}</span>
              <Badge variant={s === "Paid" ? "teal" : "amber"}>{s}</Badge>
              <button style={{ fontSize: 10, color: COLORS.blue, border: "none", background: "transparent", cursor: "pointer" }}>Download</button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  </div>
);

// ============================================================
// EMPLOYEE / INDIVIDUAL PAGES
// ============================================================

const MyRecordPage = ({ setPage: _ }) => {
  const [toggles, setToggles] = useState({ employment: true, financial: false, bank: false, lifestyle: false, criminal: false, conduct: false });
  const toggle = key => setToggles(p => ({ ...p, [key]: !p[key] }));

  return (
    <div style={{ padding: 16 }}>
      <div style={{ background: "#E6F1FB", border: `0.5px solid #B5D4F4`, borderRadius: 10, padding: "10px 14px", marginBottom: 12, fontSize: 11, color: "#0C447C", lineHeight: 1.6 }}>
        This is your KNONE record — the information employers see when they query your professional history. You have the right to view all signals, submit rebuttals, and control which data categories employers can access.
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
        <KpiCard label="Your KNONE score" value="847" delta="Clear band" accentColor={COLORS.green} />
        <KpiCard label="Signals on record" value="1" delta="1 asserted · 0 verified" accentColor={COLORS.amber} />
        <KpiCard label="Employers queried you" value="4" delta="last 12 months" accentColor={COLORS.blue} />
        <KpiCard label="Rebuttals submitted" value="1" delta="1 under review" accentColor={COLORS.purple} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 10, alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <Card>
            <div style={{ textAlign: "center", padding: "14px 0 10px" }}>
              <div style={{ fontSize: 44, fontWeight: 700, color: COLORS.green, lineHeight: 1 }}>847</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.green, marginTop: 2 }}>Clear — low risk</div>
              <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 2 }}>Your KNONE score · out of 1000</div>
              <div style={{ height: 7, background: `linear-gradient(to right, #E24B4A, #EF9F27, #378ADD, #1D9E75)`, borderRadius: 4, margin: "10px 0 4px", position: "relative" }}>
                <div style={{ position: "absolute", top: -3, left: "84.7%", transform: "translateX(-50%)", width: 2, height: 13, background: COLORS.ink, borderRadius: 1 }} />
              </div>
            </div>
            {[["Archetype", "None flagged"], ["Last updated", "Today, 06:00"], ["Identity", "Aadhaar eKYC ✓"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
              </div>
            ))}
          </Card>
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Consent controls</div>
            {[
              { key: "criminal", label: "Criminal & regulatory", sub: "Verified public records — cannot be turned off", locked: true },
              { key: "conduct", label: "Conduct & integrity", sub: "Verified signals cannot be turned off", locked: false },
              { key: "employment", label: "Employment history", sub: "Tenure, exit type, rehire eligibility", locked: false },
              { key: "financial", label: "Financial risk score", sub: "Derived from credit bureau data", locked: false },
              { key: "bank", label: "Bank statement analysis", sub: "Via Account Aggregator", locked: false },
              { key: "lifestyle", label: "Lifestyle signals", sub: "Gambling, alcohol risk scores", locked: false },
            ].map(c => (
              <div key={c.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "7px 0", borderBottom: `0.5px solid ${COLORS.border}` }}>
                <div style={{ flex: 1, marginRight: 10 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink }}>{c.label}</div>
                  <div style={{ fontSize: 10, color: COLORS.muted }}>{c.sub}</div>
                </div>
                <div onClick={() => !c.locked && toggle(c.key)}
                  style={{ width: 36, height: 20, borderRadius: 10, background: toggles[c.key] ? COLORS.teal : COLORS.paperDark, position: "relative", cursor: c.locked ? "not-allowed" : "pointer", flexShrink: 0, opacity: c.locked ? 0.5 : 1, transition: "background 0.2s" }}>
                  <div style={{ position: "absolute", width: 14, height: 14, borderRadius: "50%", background: "#FFF", top: 3, left: toggles[c.key] ? 19 : 3, transition: "left 0.2s" }} />
                </div>
              </div>
            ))}
          </Card>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* Signal */}
          <div style={{ background: "#FAEEDA", border: `0.5px solid #FAC775`, borderRadius: 10, padding: "10px 13px" }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#854F0B", marginBottom: 4 }}>1 signal on your record — rebuttal under review</div>
            <div style={{ fontSize: 11, color: "#633806", lineHeight: 1.5 }}>An employer has filed an asserted conduct signal. Your rebuttal is being reviewed within the 28-day resolution window.</div>
          </div>
          <div style={{
            border: `0.5px solid ${COLORS.border}`, borderLeft: `3px solid #EF9F27`,
            borderRadius: 8, padding: "10px 13px",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>Repeated no-shows — conduct signal</div>
              <div style={{ display: "flex", gap: 4 }}><Badge variant="amber">Asserted</Badge><Badge variant="blue">Medium</Badge></div>
            </div>
            <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 6 }}>Filed by: 1 employer (masked) · Q3 2022 · Signal weight: 0.35</div>
            <div style={{ fontSize: 11, color: COLORS.slate, marginBottom: 8 }}>Employer reported 7 unplanned absences. Asserted — not independently verified. Reduced weight in score.</div>
            <div style={{ background: COLORS.paper, borderRadius: 8, padding: "8px 10px", borderLeft: `2px solid ${COLORS.blue}` }}>
              <div style={{ fontSize: 9, fontWeight: 600, color: COLORS.blue, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 3 }}>Your rebuttal — under review</div>
              <div style={{ fontSize: 11, color: COLORS.slate }}>Absences related to documented medical condition. All absences notified to line manager by phone on each occasion. I dispute this characterisation.</div>
            </div>
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              <Btn size="sm" variant="secondary">Track status</Btn>
              <Btn size="sm" variant="secondary">Add document</Btn>
              <Btn size="sm" variant="danger">Escalate</Btn>
            </div>
          </div>
          {/* Query history */}
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Who queried your record</div>
            {[["BFSI employer", "Mumbai · NBFC sector", "2 days ago", "Clear"], ["Staffing agency", "Bangalore · IT staffing", "3 weeks ago", "Clear"], ["Insurance co.", "Mumbai · IRDAI regulated", "2 months ago", "Clear"], ["Private bank", "Delhi · BFSI", "4 months ago", "Clear"]].map(([org, city, when, result]) => (
              <div key={org + when} style={{ display: "grid", gridTemplateColumns: "1fr 80px 54px", gap: 8, alignItems: "center", padding: "6px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <div>
                  <div style={{ fontWeight: 600, color: COLORS.ink }}>{org} (masked)</div>
                  <div style={{ fontSize: 10, color: COLORS.muted }}>{city}</div>
                </div>
                <div style={{ color: COLORS.muted }}>{when}</div>
                <Badge variant="teal">{result}</Badge>
              </div>
            ))}
            <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 8 }}>Employer identities are masked. You can see sector, city, and result only.</div>
          </Card>
          {/* Share record */}
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 8 }}>Share your record proactively</div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 12, lineHeight: 1.5 }}>Generate a verified, time-limited share link to proactively send your KNONE report to a prospective employer. This signals transparency and can accelerate hiring. Link expires in 7 days.</div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="secondary" style={{ flex: 1 }}>Generate share link</Btn>
              <Btn variant="teal" style={{ flex: 1 }}>Download my report PDF</Btn>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// ADMIN PAGES
// ============================================================

const AdminHome = () => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Admin overview</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="Total PIDs in database" value="47,382" delta="↑ 1,247 this month" accentColor={COLORS.purple} />
      <KpiCard label="Active employers" value="284" delta="↑ 18 new this month" accentColor={COLORS.blue} />
      <KpiCard label="Signals pending review" value="23" delta="↓ 5 urgent" accentColor={COLORS.red} />
      <KpiCard label="Disputes open" value="7" delta="↓ 3 within SLA" accentColor={COLORS.amber} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Signal review queue</div>
        {["CV misrepresentation — BFSI employer · Urgent", "Harassment complaint — IT co. · Verified docs attached", "Financial fraud — asserted · Under investigation", "Ghost quit pattern — staffing agency submission · Routine"].map((s, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: i === 0 ? "#E24B4A" : i === 1 ? "#1D9E75" : i === 2 ? "#EF9F27" : COLORS.border, flexShrink: 0 }} />
            <span style={{ flex: 1, color: COLORS.ink }}>{s}</span>
            <Btn size="sm" variant="secondary">Review</Btn>
          </div>
        ))}
        <div style={{ marginTop: 10, display: "flex", justifyContent: "flex-end" }}>
          <Btn size="sm" variant="primary">Open signal queue →</Btn>
        </div>
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Platform health</div>
        {[["API uptime (30 days)", "99.97%", "green"], ["Avg query response time", "1.2 seconds", "green"], ["Vault DB status", "Air-gapped · Healthy", "green"], ["Signal DB replication lag", "< 100ms", "green"], ["HSM status", "Active · Key rotation in 12 days", "amber"], ["Last pen test", "Feb 2026 · No critical findings", "green"], ["ISO 27001 status", "Certified · Renewal: Dec 2026", "green"]].map(([k, v, c]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ color: COLORS.muted }}>{k}</span>
            <span style={{ fontWeight: 500, color: c === "green" ? COLORS.green : c === "amber" ? COLORS.amber : COLORS.red }}>{v}</span>
          </div>
        ))}
      </Card>
    </div>
  </div>
);

const SignalQueuePage = () => {
  const [selected, setSelected] = useState(null);
  const signals = [
    { id: "SQ-001", type: "CV misrepresentation", org: "Apex Financial", pid: "7F3A·2B91", severity: "critical", submitted: "2h ago", docs: true },
    { id: "SQ-002", type: "Harassment complaint upheld", org: "TechCorp India", pid: "A1C4·9D32", severity: "high", submitted: "5h ago", docs: true },
    { id: "SQ-003", type: "Data exfiltration on exit", org: "NBFCo", pid: "C3D9·7A11", severity: "critical", submitted: "Yesterday", docs: true },
    { id: "SQ-004", type: "Repeated no-shows", org: "RetailMax", pid: "D4A2·6C78", severity: "medium", submitted: "Yesterday", docs: false },
    { id: "SQ-005", type: "Ghost quit pattern", org: "Staffing Pro", pid: "E9F3·1B44", severity: "high", submitted: "2 days ago", docs: false },
  ];
  return (
    <div style={{ padding: 16 }}>
      <SectionLabel>Signal review queue — 23 pending</SectionLabel>
      <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 1fr" : "1fr", gap: 12 }}>
        <Card>
          <div style={{ display: "grid", gridTemplateColumns: "80px 1fr 90px 70px 80px 70px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
            <div>Signal ID</div><div>Type / Org</div><div>Severity</div><div>Docs</div><div>Submitted</div><div></div>
          </div>
          {signals.map(s => (
            <div key={s.id} onClick={() => setSelected(s)}
              style={{ display: "grid", gridTemplateColumns: "80px 1fr 90px 70px 80px 70px", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, cursor: "pointer", background: selected?.id === s.id ? COLORS.paper : "transparent" }}
              onMouseEnter={e => e.currentTarget.style.background = COLORS.paper}
              onMouseLeave={e => e.currentTarget.style.background = selected?.id === s.id ? COLORS.paper : "transparent"}
            >
              <div style={{ fontSize: 10, fontFamily: "monospace", color: COLORS.muted }}>{s.id}</div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink }}>{s.type}</div>
                <div style={{ fontSize: 10, color: COLORS.muted }}>{s.org}</div>
              </div>
              <Badge variant={s.severity === "critical" ? "red" : s.severity === "high" ? "amber" : "blue"}>{s.severity.charAt(0).toUpperCase() + s.severity.slice(1)}</Badge>
              <Badge variant={s.docs ? "teal" : "gray"}>{s.docs ? "Attached" : "None"}</Badge>
              <div style={{ fontSize: 10, color: COLORS.muted }}>{s.submitted}</div>
              <Btn size="sm" variant="secondary">Review</Btn>
            </div>
          ))}
        </Card>
        {selected && (
          <Card>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 12 }}>{selected.id} — Review panel</div>
            {[["PID", selected.pid], ["Signal type", selected.type], ["Submitting org", selected.org], ["Severity", selected.severity], ["Supporting docs", selected.docs ? "1 document" : "None attached"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
                <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
              </div>
            ))}
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink, marginBottom: 6 }}>Reviewer decision</div>
              <Select label="" value="verify" onChange={() => { }}
                options={[{ value: "verify", label: "Verify — apply full signal weight" }, { value: "downgrade", label: "Downgrade to asserted" }, { value: "reject", label: "Reject — insufficient evidence" }, { value: "escalate", label: "Escalate to legal team" }]} />
              <Input label="Review notes" placeholder="Document your reasoning..." value="" onChange={() => { }} />
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="teal" style={{ flex: 1 }}>Submit decision</Btn>
                <Btn variant="secondary" onClick={() => setSelected(null)}>Close</Btn>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

const DisputesPage = () => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Dispute resolution — 7 open disputes</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="Open disputes" value="7" delta="3 within 28-day SLA" accentColor={COLORS.amber} />
      <KpiCard label="Resolved (30 days)" value="12" delta="Avg resolution: 4.2 days" accentColor={COLORS.green} />
      <KpiCard label="Overdue (>28 days)" value="1" delta="↓ Urgent attention needed" accentColor={COLORS.red} />
    </div>
    <Card>
      <div style={{ display: "grid", gridTemplateColumns: "90px 1fr 1fr 80px 80px 70px 70px", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.borderDark}`, fontSize: 10, fontWeight: 600, color: COLORS.muted }}>
        <div>Dispute ID</div><div>Signal type</div><div>Individual reason</div><div>Days open</div><div>SLA status</div><div>Signal</div><div></div>
      </div>
      {[
        { id: "D-0041", signal: "Repeated no-shows", reason: "Medical condition documented", days: 13, sla: "on-track", provenance: "Asserted" },
        { id: "D-0038", signal: "CV misrepresentation", reason: "Degree obtained later — date error", days: 21, sla: "due-soon", provenance: "Asserted" },
        { id: "D-0035", signal: "Data exfiltration", reason: "Files were personal, not company data", days: 31, sla: "overdue", provenance: "Verified" },
        { id: "D-0029", signal: "Ghost quit", reason: "Medical emergency — hospitalised", days: 8, sla: "on-track", provenance: "Verified" },
        { id: "D-0027", signal: "Financial stress flag", reason: "IVA settled 18 months ago", days: 5, sla: "on-track", provenance: "Public record" },
      ].map(d => (
        <div key={d.id} style={{ display: "grid", gridTemplateColumns: "90px 1fr 1fr 80px 80px 70px 70px", gap: 8, alignItems: "center", padding: "8px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
          <div style={{ fontSize: 10, fontFamily: "monospace", color: COLORS.muted }}>{d.id}</div>
          <div style={{ fontWeight: 500, color: COLORS.ink }}>{d.signal}</div>
          <div style={{ color: COLORS.muted }}>{d.reason}</div>
          <div style={{ fontWeight: 600, color: d.days > 28 ? COLORS.red : d.days > 20 ? COLORS.amber : COLORS.ink }}>{d.days} days</div>
          <Badge variant={d.sla === "overdue" ? "red" : d.sla === "due-soon" ? "amber" : "teal"}>
            {d.sla === "overdue" ? "Overdue" : d.sla === "due-soon" ? "Due soon" : "On track"}
          </Badge>
          <Badge variant={d.provenance === "Verified" ? "red" : d.provenance === "Asserted" ? "amber" : "blue"}>{d.provenance}</Badge>
          <Btn size="sm" variant={d.sla === "overdue" ? "danger" : "secondary"}>Review</Btn>
        </div>
      ))}
    </Card>
  </div>
);

const ScoringPage = () => (
  <div style={{ padding: 16 }}>
    <SectionLabel>Scoring engine — model v2.4</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="Model version" value="v2.4" delta="Deployed Dec 2025" accentColor={COLORS.purple} />
      <KpiCard label="Score computations today" value="1,847" delta="Nightly batch + real-time" accentColor={COLORS.blue} />
      <KpiCard label="Model accuracy (backtest)" value="94.2%" delta="vs manual review decisions" accentColor={COLORS.green} />
      <KpiCard label="Next scheduled update" value="Jun 15" delta="v2.5 — archetype ML upgrade" accentColor={COLORS.amber} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Signal weights by category</div>
        {[["Criminal — verified", 1.0], ["Integrity — verified", 0.95], ["Data exfiltration — verified", 1.0], ["CV fabrication — verified", 0.98], ["Financial — public record", 0.85], ["Conduct — verified", 0.80], ["Exit — verified", 0.75], ["Conduct — asserted", 0.45], ["Digital — asserted", 0.28]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ flex: 1, color: COLORS.muted }}>{k}</span>
            <ProgressBar value={v * 100} color={v > 0.9 ? "#E24B4A" : v > 0.7 ? "#EF9F27" : "#378ADD"} />
            <span style={{ fontWeight: 600, minWidth: 32, textAlign: "right" }}>{v}</span>
          </div>
        ))}
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Time decay schedule</div>
        {[["Criminal — unspent", "Indefinite — no decay"], ["Criminal — spent", "Zero weight after 7 years"], ["Financial", "6-year decay (mirrors credit)"], ["Integrity / conduct", "3-year half-life"], ["Exit behaviour", "3-year half-life"], ["Lifestyle signals", "1-year — fast decay"], ["Digital / social", "2-year half-life"]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ color: COLORS.muted }}>{k}</span><span style={{ fontWeight: 500 }}>{v}</span>
          </div>
        ))}
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.ink, marginBottom: 6 }}>Archetype classifiers</div>
          {[["The Fabricator", "CV misrep + credential fraud pattern", "94% confidence"], ["The Ghost", "Ghost quit + disappearance pattern", "89% confidence"], ["The Escalator", "Escalating conduct + repeat offence", "87% confidence"], ["The Drifter", "High job-hop velocity + gap anomaly", "82% confidence"], ["The Liability", "Criminal + financial + conduct combo", "91% confidence"]].map(([n, d, c]) => (
            <div key={n} style={{ padding: "6px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontWeight: 600, color: COLORS.ink }}>{n}</span>
                <Badge variant="teal">{c}</Badge>
              </div>
              <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 1 }}>{d}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  </div>
);

// ============================================================
// REGULATOR PAGES
// ============================================================

const RegulatorHome = () => (
  <div style={{ padding: 16 }}>
    <div style={{ background: COLORS.paper, border: `0.5px solid ${COLORS.border}`, borderRadius: 10, padding: "12px 16px", marginBottom: 12 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.ink, marginBottom: 3 }}>SEBI / RBI Regulator Access — Read-only</div>
      <div style={{ fontSize: 11, color: COLORS.muted, lineHeight: 1.5 }}>You have regulator-grade access to aggregate statistics, sector compliance data, and the ability to submit formal data requests. Individual PID-level data requires a statutory data request with court order or equivalent legal instrument.</div>
    </div>
    <SectionLabel>National employment risk overview</SectionLabel>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 12 }}>
      <KpiCard label="PIDs in KNONE database" value="47,382" delta="National employment database" accentColor={COLORS.purple} />
      <KpiCard label="BFSI sector employers" value="284" delta="Using KNONE for fit-and-proper" accentColor={COLORS.blue} />
      <KpiCard label="CV fabrication rate — BFSI" value="2.9%" delta="vs 1.2% national average" accentColor={COLORS.red} />
      <KpiCard label="Criminal flags — financial sector" value="0.7%" delta="Of all BFSI queries this quarter" accentColor={COLORS.amber} />
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>BFSI sector risk distribution (Q1 2026)</div>
        {[["Critical risk (0–300)", "1.2%", "#E24B4A"], ["High risk (301–500)", "4.8%", "#EF9F27"], ["Moderate (501–650)", "12.3%", "#378ADD"], ["Low risk (651–800)", "38.7%", "#1D9E75"], ["Clear (801–1000)", "43.0%", "#9FE1CB"]].map(([k, v, c]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <div style={{ width: 10, height: 10, borderRadius: 2, background: c, flexShrink: 0 }} />
            <span style={{ flex: 1, color: COLORS.muted }}>{k}</span>
            <ProgressBar value={parseFloat(v)} max={50} color={c} />
            <span style={{ fontWeight: 600, minWidth: 36, textAlign: "right" }}>{v}</span>
          </div>
        ))}
      </Card>
      <Card>
        <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink, marginBottom: 10 }}>Fit-and-proper compliance — SEBI regulated entities</div>
        {[["Entities using KNONE for KMP checks", "284 / 412 (68.9%)"], ["Average queries per entity/month", "14.2"], ["Audit trail completeness", "99.3%"], ["Signal contribution rate", "0.22 avg"], ["Entities with 0 contributions", "23 (8.1%) — flagged"], ["Top signal type — BFSI", "CV fabrication (31% of all flags)"]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: `0.5px solid ${COLORS.border}`, fontSize: 11 }}>
            <span style={{ color: COLORS.muted, maxWidth: "60%" }}>{k}</span>
            <span style={{ fontWeight: 500, textAlign: "right" }}>{v}</span>
          </div>
        ))}
        <Btn variant="primary" style={{ marginTop: 12, width: "100%" }}>Download quarterly compliance report</Btn>
      </Card>
    </div>
  </div>
);

const DataRequestPage = () => {
  const [submitted, setSubmitted] = useState(false);
  return (
    <div style={{ padding: 16, maxWidth: 700 }}>
      <SectionLabel>Formal data request</SectionLabel>
      {submitted ? (
        <div style={{ textAlign: "center", padding: "40px 20px" }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>✓</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.ink, marginBottom: 8 }}>Request submitted — reference: RDR-2026-0047</div>
          <div style={{ fontSize: 12, color: COLORS.muted, lineHeight: 1.6 }}>KNONE's legal team will review your request within 5 business days. Individual PID data requires verification of the statutory instrument before disclosure. You will be notified by secure email.</div>
        </div>
      ) : (
        <div>
          <Alert type="info" title="Statutory data requests"
            body="Individual PID-level data can only be disclosed under a valid statutory instrument — court order, SEBI/RBI formal notice, or equivalent legal authority. Aggregate data is available via the sector statistics dashboard without a formal request." />
          <Card style={{ marginTop: 12 }}>
            <Select label="Request type" value="individual" onChange={() => { }}
              options={[{ value: "individual", label: "Individual PID data — requires statutory instrument" }, { value: "aggregate", label: "Aggregate sector data — no instrument required" }, { value: "employer-audit", label: "Employer audit trail — regulated entity inspection" }]} />
            <Input label="Statutory instrument reference" placeholder="e.g. SEBI/ENF/2026/01234 or court order number" value="" onChange={() => { }} />
            <Input label="Requesting officer name and designation" placeholder="e.g. Rajesh Kumar, Deputy General Manager — Enforcement" value="" onChange={() => { }} />
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: "block", fontSize: 11, fontWeight: 500, color: COLORS.slate, marginBottom: 5 }}>Justification for data request</label>
              <textarea placeholder="Describe the specific regulatory purpose and how the data will be used. This is recorded in KNONE's immutable audit log."
                style={{ width: "100%", padding: "8px 11px", border: `0.5px solid ${COLORS.border}`, borderRadius: 8, fontSize: 12, fontFamily: "inherit", resize: "vertical", minHeight: 80, outline: "none", boxSizing: "border-box" }} />
            </div>
            <Select label="Data retention for this request" value="7days" onChange={() => { }}
              options={[{ value: "7days", label: "7 days — delete after review" }, { value: "30days", label: "30 days — active investigation" }, { value: "permanent", label: "Permanent — court record" }]} />
            <Btn onClick={() => setSubmitted(true)} variant="primary" style={{ width: "100%" }}>Submit formal data request</Btn>
          </Card>
        </div>
      )}
    </div>
  );
};

// ============================================================
// LANDING / ROLE SELECTION
// ============================================================
const LandingPage = ({ onSelect }) => (
  <div style={{
    minHeight: "100vh", background: COLORS.ink,
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    padding: 24,
  }}>
    <div style={{ textAlign: "center", marginBottom: 48 }}>
      <div style={{ fontSize: 42, fontWeight: 800, color: "#FFF", letterSpacing: "-0.03em", marginBottom: 8 }}>
        <span style={{ color: "rgba(255,255,255,0.3)" }}>KN</span>ONE
      </div>
      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", letterSpacing: "0.12em", textTransform: "uppercase" }}>India's Employment Risk Bureau</div>
      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", marginTop: 8 }}>Known Network of National Employment · Est. 2026</div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 12, maxWidth: 600, width: "100%" }}>
      {[
        { type: "employer", icon: "🏛", title: "Employer portal", sub: "Run KNONE checks, submit signals, monitor your workforce", color: "#E6F1FB", textColor: COLORS.blue },
        { type: "employee", icon: "◉", title: "My record", sub: "View your KNONE persona, manage consent, submit rebuttals", color: "#E1F5EE", textColor: COLORS.teal },
        { type: "admin", icon: "⚡", title: "Admin console", sub: "Signal review queue, disputes, scoring engine, security", color: "#EEEDFE", textColor: COLORS.purple },
        { type: "regulator", icon: "⚖", title: "Regulator access", sub: "Sector statistics, compliance data, formal data requests", color: "#FAEEDA", textColor: COLORS.amber },
      ].map(r => (
        <div key={r.type} onClick={() => onSelect(r.type)}
          style={{
            background: "rgba(255,255,255,0.05)", border: "0.5px solid rgba(255,255,255,0.1)",
            borderRadius: 14, padding: "20px 22px", cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.1)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.transform = "none"; }}
        >
          <div style={{ fontSize: 28, marginBottom: 10 }}>{r.icon}</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#FFF", marginBottom: 5 }}>{r.title}</div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", lineHeight: 1.5 }}>{r.sub}</div>
        </div>
      ))}
    </div>
    <div style={{ marginTop: 40, fontSize: 10, color: "rgba(255,255,255,0.2)", textAlign: "center", lineHeight: 1.8 }}>
      All data is pseudonymised · Argon2id hashing · AES-256-GCM field encryption · Air-gapped Vault DB<br />
      DPDP Act 2023 compliant · ISO 27001 certified · AWS Mumbai (ap-south-1)
    </div>
  </div>
);

// ============================================================
// MAIN APP
// ============================================================
export default function KNONEApp() {
  const [showLanding, setShowLanding] = useState(true);
  const [userType, setUserType] = useState("employer");
  const [currentPage, setCurrentPage] = useState("home");
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const userMeta = {
    employer: { orgName: "Apex Financial Services Pvt Ltd", userName: "Rahul Kumar" },
    employee: { orgName: "My KNONE Record", userName: "Priya Kaur" },
    admin: { orgName: "KNONE Admin Console", userName: "Admin" },
    regulator: { orgName: "SEBI Enforcement", userName: "R. Kumar" },
  };

  const pageLabels = {
    home: "Dashboard", query: "New query", reports: "All reports", "candidate-report": "Candidate report",
    monitoring: "Post-hire monitoring", "submit-signal": "Submit signal", analytics: "Analytics",
    team: "Team access", billing: "Billing",
    "my-record": "My record", "my-score": "My score", signals: "Signals filed", rebuttals: "Rebuttals", consent: "Consent controls", share: "Share record", history: "Query history",
    "admin-home": "Admin overview", "signal-queue": "Signal queue", disputes: "Disputes", orgs: "Organisations", scoring: "Scoring engine", security: "Security", "audit-log": "Audit log",
    "reg-home": "Regulator overview", "reg-reports": "Reports", "sector-stats": "Sector statistics", compliance: "Compliance", "data-request": "Data request",
  };

  const handleUserTypeChange = (type) => {
    setUserType(type);
    const defaultPages = { employer: "home", employee: "my-record", admin: "admin-home", regulator: "reg-home" };
    setCurrentPage(defaultPages[type]);
  };

  const handleLandingSelect = (type) => {
    setUserType(type);
    const defaultPages = { employer: "home", employee: "my-record", admin: "admin-home", regulator: "reg-home" };
    setCurrentPage(defaultPages[type]);
    setShowLanding(false);
  };

  if (showLanding) {
    return <LandingPage onSelect={handleLandingSelect} />;
  }

  const renderPage = () => {
    const setPage = (page) => {
      setCurrentPage(page);
    };
    if (userType === "employer") {
      switch (currentPage) {
        case "home": return <EmployerHome setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
        case "query": return <QueryPage setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
        case "reports": return <ReportsPage setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
        case "candidate-report": return <CandidateReport candidate={selectedCandidate} setPage={setPage} />;
        case "monitoring": return <MonitoringPage setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
        case "submit-signal": return <SubmitSignalPage />;
        case "analytics": return <AnalyticsPage />;
        case "team": return <TeamPage />;
        case "billing": return <BillingPage />;
        default: return <EmployerHome setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
      }
    }
    if (userType === "employee") {
      switch (currentPage) {
        case "my-record": return <MyRecordPage setPage={setPage} />;
        case "my-score": return <MyRecordPage setPage={setPage} />;
        case "signals": return <MyRecordPage setPage={setPage} />;
        case "rebuttals": return <MyRecordPage setPage={setPage} />;
        case "consent": return <MyRecordPage setPage={setPage} />;
        default: return <MyRecordPage setPage={setPage} />;
      }
    }
    if (userType === "admin") {
      switch (currentPage) {
        case "admin-home": return <AdminHome />;
        case "signal-queue": return <SignalQueuePage />;
        case "disputes": return <DisputesPage />;
        case "scoring": return <ScoringPage />;
        default: return <AdminHome />;
      }
    }
    if (userType === "regulator") {
      switch (currentPage) {
        case "reg-home": return <RegulatorHome />;
        case "data-request": return <DataRequestPage />;
        default: return <RegulatorHome />;
      }
    }
    return <EmployerHome setPage={setPage} setSelectedCandidate={setSelectedCandidate} />;
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: COLORS.paper, fontFamily: "'Georgia', serif" }}>
      <style>{`
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; } 
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.15); border-radius: 2px; }
        input, select, textarea, button { font-family: 'Georgia', serif; }
      `}</style>
      <Sidebar userType={userType} currentPage={currentPage} setPage={setCurrentPage} collapsed={sidebarCollapsed} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "auto" }}>
        <Topbar
          userType={userType}
          orgName={userMeta[userType].orgName}
          userName={userMeta[userType].userName}
          currentPage={currentPage}
          pageLabels={pageLabels}
          onUserTypeChange={handleUserTypeChange}
          sidebarCollapsed={sidebarCollapsed}
          setSidebarCollapsed={setSidebarCollapsed}
        />
        <div style={{ flex: 1 }}>
          {renderPage()}
        </div>
      </div>
    </div>
  );
}

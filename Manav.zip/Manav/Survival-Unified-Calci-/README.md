# Survival Unified Calculator

A Flask-based web application that unifies Survival Calculator 1 and 2 for calculating survival benefits from insurance policy data. This tool automates complex insurance calculations previously performed manually in Excel.

## Features

- **Unified Logic**: Merged Calculator 1 (S1) and Calculator 2 (S2) into a single processing engine.
- **Automated Calculations**: Processes input Excel files (Columns A-AW) and generates survival benefit amounts.
- **Comprehensive Product Support**:
    - **S1 Products**: CPP, CHP.
    - **S2 Products**: IMP, MPI, CSR, MBG, MBN, MSB, SMB, RFI, WLI, MBP, SEP, RFP.
- **Calculator Indicator**: Automatically identifies and marks which calculator logic (S1 or S2) was applied for each row.
- **Loan Adjustment**: Automatically calculates accrued loan interest and adjusts final survival benefit amounts.
- **Formatted Output**: Generates a professionally formatted Excel file with consistent styling, borders, and color-coded headers matching corporate standards.
- **Robust Date Parsing**: Handles both standard datetime formats and numeric Excel serial dates (common in .xlsb files).

## Deployment on Render

This project is configured for deployment on [Render](https://render.com/).

### Steps to Deploy:

1. **Create a New Web Service**: Connect your GitHub/GitLab repository to Render.
2. **Environment**: Select `Python`.
3. **Build Command**: 
   ```bash
   pip install -r requirements.txt
   ```
4. **Start Command**: 
   ```bash
   gunicorn app:app
   ```

## Local Development

1. **Clone the repository**:
   ```bash
   git clone <your-repo-url>
   cd survival-2-calci
   ```

2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**:
   ```bash
   python app.py
   ```
   The app will be available at `http://127.0.0.1:5000`.

## Input File Format

The application expects an Excel file where:
- **Headers** are on Row 2.
- **Data** starts from Row 3.
- **Columns A to AW** contain the required policy and loan information.

## License

Internal Use Only.

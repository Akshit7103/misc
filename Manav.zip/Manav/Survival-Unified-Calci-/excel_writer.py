import pandas as pd
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows

# EXTRACTED STYLE DATA (From Row 2 of original)
# col_idx: (fill_hex, bold)
STYLE_MAP = {
    # Calculations based on result_df structure: 0-48 (A-AW), 49 (CJ), 50 (CK)
    49: ("FFA500", True), # SB Amount (CJ)
    50: ("FFA500", True)  # Final SB Amount (CK)
}

def write_formatted_excel(df, output_path):
    """
    Optimized Excel writer that only styles headers and output columns.
    Avoids cell-by-cell loops for data rows to prevent Render timeouts.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Calculated Output"
    
    # ROW 1: Empty
    ws.append([])
    
    # ROW 2: Headers
    headers = df.columns.tolist()
    ws.append(headers)
    
    # ROW 3+: Data
    # Fast write of data rows
    for r in dataframe_to_rows(df, index=False, header=False):
        ws.append(r)
        
    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    
    # Apply formatting and numeric styling
    for col_idx in range(1, len(headers) + 1):
        # Header formatting
        header_cell = ws.cell(row=2, column=col_idx)

        # Color code: 1-49 White (Normal), Last 2 Orange with Borders
        if col_idx <= 49:
            fill_hex = "FFFFFF"
            is_bold = False
            has_border = False
        else:
            fill_hex = "FFA500"
            is_bold = True
            has_border = True

        header_cell.fill = PatternFill(start_color=fill_hex, end_color=fill_hex, fill_type="solid")
        header_cell.font = Font(bold=is_bold)
        header_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        if has_border:
            header_cell.border = thin_border

        # Set consistent width
        ws.column_dimensions[header_cell.column_letter].width = 18

        # Data row formatting: Dates and Numbers
        for row_idx in range(3, ws.max_row + 1):
            cell = ws.cell(row=row_idx, column=col_idx)

            # Apply Borders ONLY to output columns
            if col_idx > 49:
                cell.border = thin_border

            # Apply Date Formatting (04-May-26 style)
            if isinstance(cell.value, (datetime, pd.Timestamp)):
                cell.number_format = 'DD-MMM-YY'

            # Apply Number Formatting for result columns (comma separated)
            if col_idx > 49: # SB Amount and Final SB Amount
                cell.number_format = '#,##0.00'


    
    wb.save(output_path)
    return output_path

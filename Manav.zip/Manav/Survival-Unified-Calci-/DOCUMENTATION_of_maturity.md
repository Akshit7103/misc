# Unified Insurance Calculator — Technical Documentation

This document explains how the unified maturity-benefit (MB) calculator was
built: how the three independent calculators were merged behind one input,
how the loan-interest cutoff date and rate were made configurable from the
UI, and how CSV input/output was added on top of the original Excel-only
pipeline. It also covers the validation strategy and the deployment layout
on Render.

---

## 1. Background — what existed before

There were three independent calculators, each shipped as its own Excel
reference workbook plus a Python port:

| Calculator | Reference workbook                | Products it covered                              |
| ---------- | --------------------------------- | ------------------------------------------------ |
| MB1        | `MB_Calc1_*.xlsx`                 | CPP, CHP, MBP, RFP, SMB, MSB, RMM, MMP           |
| MB2        | `MB_Calc2_*.xlsx`                 | CSR, SEP, CPF, CPH, DEP, END, RBC                |
| MB3        | `MB_Calc3_*.xlsx`                 | LPR, LBR, LBS, LCS                               |

All three calculators shared the **same 56 input columns** (`A:BD`) — the
columns came from a common policy-master extract — but each produced its
own variant of the 9 output columns (LN_LA Updated, GLA, GMA, Revisionary
Bonus, Special Bonus, Terminal Bonus, Maturity Benefit, Condition 100.1%,
Total Maturity Benefit) at different column letters in its own sheet.

That meant a user had to know in advance which calculator to run for
each row of their input, split the file by `CNTTYPE` (column Z), feed
each chunk to the right tool, and merge the results back together. The
goal of the unified tool was to make that decision automatically.

---

## 2. Merging the three calculators into one tool

### 2.1 The routing dispatcher

The whole merge is driven by a single dictionary in `unified.py`:

```python
CNTTYPE_TO_CALCULATOR: dict[str, str] = {
    "CPP": "MB1", "CHP": "MB1", "MBP": "MB1", "RFP": "MB1",
    "SMB": "MB1", "MSB": "MB1", "RMM": "MB1", "MMP": "MB1",
    "CSR": "MB2", "SEP": "MB2", "CPF": "MB2", "CPH": "MB2",
    "DEP": "MB2", "END": "MB2", "RBC": "MB2", "IMP": "MB2",
    "MBG": "MB2", "MBN": "MB2", "MPI": "MB2", "RFI": "MB2",
    "WLI": "MB2",
    "LPR": "MB3", "LBR": "MB3", "LBS": "MB3", "LCS": "MB3",
}
```

For each data row, `lookup_calculator(row["Z"])` returns `"MB1"`,
`"MB2"`, `"MB3"`, or `None`. `compute_outputs(row_dict, ...)` then
dispatches the row to the matching module and pulls the 9 user-facing
output values into a canonical order (`OUTPUT_KEY_ORDER`).

### 2.2 Calculators as a package

The three calculators were bundled into `calculators/` as a Python
package so the unified app is self-contained for Render deployment:

```
unified_deploy/
├── unified.py               # router + I/O
├── app.py                   # Flask wrapper
├── calculators/
│   ├── __init__.py
│   ├── mb1.py
│   ├── mb2.py
│   └── mb3.py
└── ...
```

Each calculator exposes a slightly different entry point — they were
ported at different times — but `unified.py` papers over that:

- `mb1.calculate_row(row_dict, cutoff_serial=..., rate=...)` returns a
  dict keyed by column letters; the unified router reads the 9 needed
  values from `MB1_OUTPUT_COLS = ["DG", ..., "DO"]`.
- `mb2.calculate_row(row_dict, config)` takes a `WorkbookConfig`
  dataclass; the router calls `mb2.default_config()`, overrides the
  cutoff and rate fields on it, and reads outputs from
  `MB2_OUTPUT_COLS = ["CO", ..., "CW"]`.
- `mb3.calculate_outputs(row_dict, cutoff_serial=..., rate=...)`
  already returns a dict keyed by the canonical names in
  `OUTPUT_KEY_ORDER`, so no remapping is needed.

### 2.3 Canonical I/O layout

Whatever calculator runs, the unified workbook always has the same
shape:

| Column range | Contents                                                       |
| ------------ | -------------------------------------------------------------- |
| `A:BD`       | 56 input columns, copied through unchanged from the input.     |
| `BE:BM`      | 9 user-facing output columns, in `OUTPUT_KEY_ORDER`.           |
| `BN`         | Diagnostic "Calculator Used" column: `MB1` / `MB2` / `MB3` / `UNROUTED`. |

The output sheet is always named `MAIN CALCULATOR`. The first row is a
section/label row, the second row is the header, and data starts at
row 3 — matching the layout the three reference workbooks use so users
can swap files in and out without learning a new convention.

### 2.4 Sheet auto-detection

Some reference workbooks (notably MB2) have a `Notes` sheet first.
`_find_input_sheet()` walks a small `CANDIDATE_SHEETS` preference list,
falls back to the first sheet whose row 2 matches `INPUT_HEADERS`, and
finally to the first sheet — so users don't have to rearrange the
input file.

---

## 3. Making the loan-interest cutoff date and rate configurable

### 3.1 Why the change was needed

All three calculators apply the same accrued-loan-interest formula:

```
IF AH ≤ cutoff_date THEN 0
ELSE (M + N) × ((1 + rate) ^ ((AH − cutoff_date) / 365) − 1)
```

Originally the cutoff (`2026-03-31`, Excel serial `46112`) and rate
(`0.0825` = 8.25%) were hardcoded inside each calculator. Business
users needed to be able to "what-if" both values without editing
source code, so both became request-scoped inputs.

### 3.2 Threading parameters through the call stack

The change is mechanical but disciplined — both parameters are passed
down by argument, never via module-level globals. That keeps the tool
safe under gunicorn's sync workers, where a global override from one
request could otherwise leak into another.

```
Flask form
  └─ app.upload_file()             # parses form
       └─ unified.process_workbook(..., cutoff_date, rate)
            └─ unified.compute_outputs(row, cutoff_date, rate)
                 ├─ mb1.calculate_row(row, cutoff_serial, rate)
                 ├─ mb2.calculate_row(row, config)              # config.accrued_interest_date_serial / .rate
                 └─ mb3.calculate_outputs(row, cutoff_serial, rate)
```

`unified.py` defines:

```python
DEFAULT_CUTOFF_DATE = date(2026, 3, 31)
DEFAULT_RATE = 0.0825

def _to_excel_serial(d: date | datetime) -> float:
    base = date(1899, 12, 30)
    if isinstance(d, datetime):
        d = d.date()
    return float((d - base).days)
```

The conversion to an Excel serial day count is important because the
calculator formulas were originally written in Excel: dates are
subtracted as integers. Re-using Excel's epoch (`1899-12-30` after the
1900 leap-year correction) means the Python implementation produces
bit-identical results to the reference workbooks.

### 3.3 UI surface

`templates/index.html` adds two fields in a single `.form-row`:

```html
<input type="date"   name="cutoff_date" value="{{ default_cutoff }}" required>
<input type="number" name="rate"        value="{{ default_rate }}"  step="0.0001"
       min="0" max="1" required>
```

`app.py` injects defaults from the unified module so the UI never
drifts from the code:

```python
return render_template(
    "index.html",
    default_cutoff=DEFAULT_CUTOFF_DATE.isoformat(),
    default_rate=DEFAULT_RATE,
)
```

On submit, `upload_file()` parses, validates, and passes the values:

```python
cutoff_date = datetime.strptime(cutoff_raw, "%Y-%m-%d").date()
rate = float(rate_raw)         # rejected unless 0 ≤ rate ≤ 1
...
process_workbook(input_path, output_path, cutoff_date=cutoff_date, rate=rate)
```

### 3.4 Backward-compatibility guarantee

The defaults (`2026-03-31`, `0.0825`) are exactly the values previously
hardcoded. The validation script
`_validate_configurable_cutoff.py` asserts that running the new
parameterised pipeline at the defaults reproduces the golden output
workbook cell-for-cell.

---

## 4. Adding CSV input and output

### 4.1 Goals

- Accept `.csv` uploads in addition to `.xlsx` / `.xls`.
- Let the user choose the output format (`.xlsx` or `.csv`) on the form.
- Produce CSV outputs that are *value-equivalent* to the xlsx outputs:
  the same routing decisions, the same numeric results to within
  floating-point tolerance, the same date strings.
- Zero change to routing, calculator logic, or default behaviour.

### 4.2 The shape problem

The CSV reader/writer had to plug into the same row pipeline as the
xlsx reader/writer. The xlsx reader returns *typed* cell values
(`int`, `float`, `datetime`, `str`, `None`) and the calculators
depend on those types — for example, an integer policy number is
treated differently from a string. CSV is plain text, so the bridge
between the two is the *coercion function*.

### 4.3 `_coerce_csv_cell` — CSV → Python

```python
_DATE_PATTERNS = ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y")
_DATETIME_PATTERNS = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M")
_V_LIKE_DATE = re.compile(r"^\d{2}[A-Z]{3}\d{4}:\d{2}:\d{2}:\d{2}$")

def _coerce_csv_cell(text: str) -> Any:
    s = (text or "").strip()
    if s == "":                              return None
    if _V_LIKE_DATE.match(s):                return s            # 01APR2010:00:00:00 → string
    if s.lstrip("-").isdigit():              return int(s)       # 12345
    try:    return float(s)                                       # 12345.67
    except ValueError: pass
    for fmt in _DATETIME_PATTERNS + _DATE_PATTERNS:               # 2024-09-30 etc.
        try:    return datetime.strptime(s, fmt)
        except ValueError: continue
    return s                                                      # otherwise a string
```

Three subtleties worth calling out:

1. **Empty string → `None`**, not `""`. This matches openpyxl, and
   `_is_blank()` checks elsewhere in the pipeline only know how to
   recognise `None` / `""` as blank.
2. **V-column timestamps (`01APR2010:00:00:00`)** are preserved as
   strings rather than parsed into a `datetime`. The reference
   workbooks store those values as text and the calculators treat them
   as opaque labels — parsing them would silently change types.
3. **Excel-style integer-as-float** (`123.0`) gets stored as `float`
   because that's how openpyxl loads `123` from a numeric cell. The
   coercion preserves the same downstream behaviour.

### 4.4 `_csv_cell` — Python → CSV

```python
def _csv_cell(value: Any) -> str:
    if value is None:                                          return ""
    if isinstance(value, datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return value.strftime("%Y-%m-%d")
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):                                return value.strftime("%Y-%m-%d")
    return str(value)
```

A midnight `datetime` is rendered as a pure date (`2024-09-30`),
non-midnight as `YYYY-MM-DD HH:MM:SS`. This is exactly the textual
form openpyxl produces when an xlsx cell is read and stringified, so
round-trip equality holds.

### 4.5 Reading and writing CSV files

```python
def find_data_rows_csv(input_path: Path) -> list[tuple[int, list[Any]]]:
    rows = []
    header_seen = False
    with open(input_path, "r", encoding="utf-8-sig", newline="") as f:
        for r_idx, raw in enumerate(csv.reader(f), start=1):
            padded = list(raw) + [""] * max(0, INPUT_LAST_COL - len(raw))
            normalized = [_clean(v) for v in padded[:INPUT_LAST_COL]]
            if normalized == INPUT_HEADERS:
                header_seen = True
                continue
            if not header_seen and r_idx == 1:
                continue                                  # leading label row
            if any(_clean(v) for v in padded[:INPUT_LAST_COL]):
                rows.append((r_idx, [_coerce_csv_cell(v) for v in padded[:INPUT_LAST_COL]]))
    return rows
```

- `encoding="utf-8-sig"` quietly eats a BOM if Excel wrote one.
- The reader pads or trims each row to exactly 56 columns so trailing
  blank cells don't break ragged-CSV inputs.
- Header detection is exact-match against `INPUT_HEADERS` (with
  newlines flattened) — the same logic the xlsx reader uses.

The writer is symmetrical: it flattens the multi-line `INPUT_HEADERS`
and `OUTPUT_HEADERS` (`"LN_LA\nUpdated"` → `"LN_LA Updated"`), writes
the header row, and then writes each processed row's 56 inputs + 9
outputs + the diagnostic column.

### 4.6 Dispatch by file extension

`process_workbook` decides what to do purely by suffix, with no flags:

```python
def _is_csv_path(p: Path) -> bool:
    return p.suffix.lower() == ".csv"

def process_workbook(input_path, output_path, cutoff_date=None, rate=None):
    if _is_csv_path(input_path):
        data_rows = find_data_rows_csv(input_path)
    else:
        in_wb = load_workbook(input_path, data_only=True, read_only=True)
        in_ws = _find_input_sheet(in_wb)
        data_rows = find_data_rows(in_ws)
    ...
    if _is_csv_path(output_path):
        write_csv(output_path, processed)
    else:
        write_workbook(output_path, processed)
```

That keeps the routing/dispatch code completely format-agnostic — any
of the four combinations (`xlsx→xlsx`, `xlsx→csv`, `csv→xlsx`,
`csv→csv`) goes through the same row pipeline.

### 4.7 UI surface

`templates/index.html` widens the file picker and adds a radio group:

```html
<input type="file" name="file" accept=".xlsx,.xls,.csv" required>
...
<input type="radio" name="output_format" value="xlsx" checked> Excel (.xlsx)
<input type="radio" name="output_format" value="csv">          CSV (.csv)
```

`app.py` parses the selection, builds the output path with the right
suffix, and lets `process_workbook` do the rest:

```python
output_format = (request.form.get("output_format") or "xlsx").strip().lower()
stem = Path(safe_name).stem
output_name = f"Unified_Output_{stem}.{output_format}"
```

---

## 5. Validation strategy

Each feature ships with a validation script kept at the repository
root (one level above `unified_deploy/`). The scripts are runnable
locally with `python <script>.py` and exit non-zero on failure.

### 5.1 `_validate_configurable_cutoff.py`

Three assertions:

1. Running `process_workbook` at the default cutoff
   (`date(2026, 3, 31)`) reproduces the golden v2 sample workbook
   cell-for-cell. **This guarantees zero behavioural change vs the
   pre-config version.**
2. Running with `cutoff_date=date(2030, 12, 31)` produces *different*
   outputs for at least one row (otherwise the cutoff isn't actually
   threaded through). The script prints the first few rows that
   change for sanity.
3. Posting to `/upload` with `cutoff_date=2030-12-31` via the Flask
   test client returns a workbook identical to the direct
   `process_workbook` call — proving the form fields are wired up
   correctly.

### 5.2 `_validate_csv.py`

Four assertions, all on the same v2 sample:

1. `xlsx → csv`: every cell in the CSV matches the golden xlsx output
   under text rendering and numeric tolerance.
2. `csv → xlsx`: converting the xlsx sample to CSV, feeding it back
   in, and writing xlsx out matches the golden v2 output in the
   computed columns `BE:BN`.
3. `csv → csv`: the round-trip is bit-equivalent to the direct
   `xlsx → csv`.
4. Flask `/upload` with `output_format=csv` returns the same CSV bytes
   `process_workbook` would write directly.

Both validation runs are reproduced in CI-style logs at the end of
their respective commits.

---

## 6. Deployment on Render

The repo (`https://github.com/Akshit7103/Unified-Insurance-Calculator-Maturity`)
is Render-ready out of the box:

- `render.yaml` — blueprint definition. Defines a free web service
  with `gunicorn app:app`, a `/health` endpoint, and an auto-generated
  `SECRET_KEY` env var.
- `Procfile` — `web: gunicorn app:app --bind 0.0.0.0:$PORT`.
- `runtime.txt` — pins Python 3.11.9.
- `requirements.txt` — Flask 3.1.3, openpyxl 3.1.5, gunicorn 23.0.0
  and their dependencies.

No external storage is needed: uploaded files land in
`tempfile.gettempdir()/unified_mb/`, are processed, and the output is
streamed back as an HTTP response.

---

## 7. Source-of-truth file map

| Concern                       | File(s)                                          |
| ----------------------------- | ------------------------------------------------ |
| Routing dispatcher            | `unified.py` (`CNTTYPE_TO_CALCULATOR`, `compute_outputs`) |
| Workbook I/O                  | `unified.py` (`find_data_rows`, `write_workbook`) |
| CSV I/O                       | `unified.py` (`find_data_rows_csv`, `write_csv`, coercion helpers) |
| Configurable cutoff defaults  | `unified.py` (`DEFAULT_CUTOFF_DATE`, `DEFAULT_RATE`, `_to_excel_serial`) |
| Per-calculator logic          | `calculators/mb1.py`, `calculators/mb2.py`, `calculators/mb3.py` |
| Flask glue                    | `app.py`                                         |
| UI                            | `templates/index.html`, `static/style.css`       |
| Deployment                    | `render.yaml`, `Procfile`, `runtime.txt`, `requirements.txt` |
| Validation                    | `../\_validate_configurable_cutoff.py`, `../\_validate_csv.py` |

---

## 8. Commit history (feature-level)

| Commit    | Summary                                                |
| --------- | ------------------------------------------------------ |
| `165e3a0` | Initial commit: Unified MB Calculator (Render-ready)   |
| `ced608e` | Make loan-interest cutoff date and rate configurable from the UI |
| `d522401` | Add CSV input and output support                       |

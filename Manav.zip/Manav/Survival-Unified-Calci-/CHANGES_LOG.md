# Survival Unified Calculator - Changes Log

This document summarizes the updates and logic fixes implemented to ensure the calculator aligns perfectly with the reference Excel files (Calculator 1 and Calculator 2).

## 1. Logic Fixes (Calculator 2)

### RFI Product (Reliance Future Income)
- **Issue:** Discrepancy in SB Amount for Inforce (IF) policies.
- **Fix:** Implemented a pro-rata Revisionary Bonus formula. For 'IF' policies, the bonus is now calculated as: `abs(LE_RY) / Current Year * (Current Year - 1)`. 
- **Result:** Matches the 'real output' exactly (e.g., Row `test52960306` now results in 33,600.00 instead of 34,675.00).

### WLI Product (Whole Life Income)
- **Issue:** Missing Cash Bonus and incorrect base Sum Assured.
- **Fix:** 
    - Rewrote the logic to sum both **Guaranteed Income** and **Cash Bonus** (5.8% for IF policies) on a row-by-row basis.
    - Switched to using **Column AV (CURRENT SA)** as the base for all WLI calculations to ensure pro-rata accuracy for Paid Up policies.

### Status Mapping & Eligibility
- **Issue:** Non-standard status codes (L1, L2, FL) were causing nil outputs.
- **Fix:** Added a mapping layer:
    - `L1`, `L2`, `INFORCE` -> `IF`
    - `FL`, `FULLY PAID UP`, `PAID UP` -> `PU`
- **PU Eligibility:** Enforced that products `IMP`, `MPI`, `CSR`, `MBP`, `SEP`, and `RFP` return **0** if the status is `PU`, matching the reference Excel.

### Lapse Detection
- **Issue:** Generic lapse logic didn't match product-specific rules.
- **Fix:** Integrated the `concern` sheet rules from the XLSB:
    - **MBG:** Lapsed if Premium Paid Years <= 1.
    - **MSB:** Lapsed if Premium Paid Years <= 2.
    - **MBN and others:** Lapsed if Premium Paid Years <= 3.

## 2. Output Formatting Updates

### Professional Styling
- **Orange Highlighting:** Only the two final result columns (`SB Amount` and `Final SB Amount - Loan Adj`) feature the orange header and thin borders.
- **Clean Input Columns:** Input columns (A-AW) are now rendered as plain text without borders or background colors to keep the sheet clean for further computation.
- **Uniform Width:** All columns are set to a width of 18 for consistent readability.

### Date & Number Formatting
- **Standardized Dates:** All date columns now display in the **`DD-MMM-YY`** format (e.g., `04-May-26`) with no timestamps.
- **Financial Values:** Result columns now use comma separators and two decimal places (e.g., `11,800.00`).

## 3. System Architecture
- **Self-Contained:** All formulas, rate charts, and logical dependencies from the reference Excel files have been hardcoded into `calculator.py`.
- **Stateless:** The application does not require any external Excel files to perform calculations; it only needs the policy extract as an input.
- **Robustness:** Fixed missing imports (`datetime`) and ensured all intermediate calculation columns are handled internally before selecting the final output range.

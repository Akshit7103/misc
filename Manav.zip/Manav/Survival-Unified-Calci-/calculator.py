import pandas as pd
import numpy as np
from datetime import datetime

# HARDCODED LOGIC & DATA
HEADERS = [
    "CONTRACT_NUMBER", "STATUS", "LE_LP_AMT", "LE_ME", "LE_RY", "LE_SI", "LE_IM", "LE_PA", "LE_BT", "LE_LY",
    "LE_FE", "LE_GM", "LN_LO_AMT", "LN_LA_AMT", "LN_LI_AMT", "LE_MC", "LP_S", "LP_MS", "ASGNNUM", "NATLTY",
    "ISSDATE", "FIRSTISSDT", "PREMIUM01", "SA", "CNTTYPE", "CATEGORY", "PROD_NAME", "RISK TERM", "PREM TERM",
    "FREQUENCY", "RCDDATE", "PAIDTODATE", "RISKCESDTE", "PREMCESDTE", "CLTDOB", "CLTDOD", "ZPANVAL", "ANP_PREMIUM",
    "STMPDTYAMT", "INSTPREM_GST", "INSTPREM_WITH_GST", "INSTPREM_WITHOUT_GST", "PLAN_COMPONENT", "COMPONENT_DESC",
    "ORIGINAL_SA", "ASSIGNEE FLAG", "LITIGATION FLAG", "CURRENT SA", "NEXT_PAYDATE", "", "Inforce/Paid up",
    "PPT * FREQ", "Prem Paid * FREQ", "(Updated SA)", "Current Year", "Date of Death\n(For Ref)",
    "For Current Month Accrued Loan Interest", "Updated LN_LA", "SB Due Check", "Death Status(Inforce or paid up death)",
    "Premium paid years", "Lapsed Death", "Death Status", "Money Back % (IMP/ MPI)", "Money Back % (CSR)",
    "Money Back % (MBG, MBN)", "Money Back Benefit %\nMSB / SMB", "RFI \nRV Bonus", "RFI\n(SA+RV bonus)",
    "RFI Income benefit %", "WLI\nGuaranteed Income\n% of BSA (A)", "WLI Guaranteed Income (B)", "WLI Cash Bonus \n",
    "Total SB in WLI", "MBP", "SEP", "RFP", "IMP /MPI", "CSR", "MBG", "MBN", "MSB / SMB", "WLI", "RFI", "MBP",
    "SEP", "RFP", "SB Amount", "Final SB Amount - Loan Adj"
]

RATE_CHARTS = {
    "imp_mpi": {3: 0.1, 6: 0.2, 9: 0.3, 12: 0.5},
    "mbg_mbn": {
        "15-11": 0.15, "15-12": 0.15, "15-13": 0.15, "15-14": 0.15, "15-15": 0.4,
        "20-16": 0.15, "20-17": 0.15, "20-18": 0.15, "20-19": 0.15, "20-20": 0.4
    },
    "csr": {4: 0.1, 7: 0.15, 10: 0.2, 13: 0.25, 16: 0.3, 19: 0.35},
    "rfi": {
        14: {"start": 8, "pct": 0.142857},
        16: {"start": 9, "pct": 0.125},
        18: {"start": 10, "pct": 0.111111},
        20: {"start": 11, "pct": 0.1},
        22: {"start": 12, "pct": 0.090909},
        24: {"start": 13, "pct": 0.083333}
    },
    "wli": [
        {"low": 0.0, "high": 249999.0, "pct": 0.06},
        {"low": 250000.0, "high": 499999.0, "pct": 0.065},
        {"low": 500000.0, "high": 999999999.0, "pct": 0.0675}
    ]
}

# Default Constants
DEFAULT_CUTOFF_DATE = pd.to_datetime("2026-03-31")
DEFAULT_INTEREST_RATE = 0.0825

def to_num(val):
    v = pd.to_numeric(val, errors='coerce')
    return v if pd.notna(v) else 0


def read_calc_sheet(path):
    """Read the calculation sheet from an uploaded workbook.

    The reference .xlsb has several sheets ('Notes', 'Calc 2_other Products',
    ...) and the data is NOT on the first sheet, so a plain
    pd.read_excel(path, header=1) would silently read 'Notes' and produce
    garbage. Pick the sheet whose row-2 header begins with CONTRACT_NUMBER
    (the canonical first input column); fall back to the first sheet.
    """
    xls = pd.ExcelFile(path)
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet, header=1)
        if len(df.columns) and str(df.columns[0]).strip().upper() == "CONTRACT_NUMBER":
            return df
    return pd.read_excel(xls, sheet_name=0, header=1)

def calculate_survival(df, cutoff_date=None, interest_rate=None):
    """
    Performs the calculations equivalent to columns AY to CK of the Excel sheet.
    Input df should have columns A to AW (index 0 to 48).
    Logic is fully self-contained and Python-based.
    """
    cutoff_date = pd.to_datetime(cutoff_date) if cutoff_date else DEFAULT_CUTOFF_DATE
    interest_rate = to_num(interest_rate) if interest_rate is not None else DEFAULT_INTEREST_RATE

    # Map input columns to A-AW letters for consistent logic
    letter_cols = []
    for i in range(89): # A to CK
        if i < 26: letter_cols.append(chr(65 + i))
        else: letter_cols.append(chr(65 + (i // 26) - 1) + chr(65 + (i % 26)))
    
    # Create a copy to not modify original
    calc_df = df.copy()
    
    # Ensure we have all columns from A to CK (index 0 to 88)
    for i in range(len(calc_df.columns), 89):
        calc_df[letter_cols[i]] = np.nan
            
    # Rename columns to A, B, C... AW for the internal logic
    calc_df.columns = letter_cols[:len(calc_df.columns)]
    
    # Helper for dates
    def to_dt(col):
        s = calc_df[col]
        numeric_s = pd.to_numeric(s, errors='coerce')
        dt_num = pd.to_datetime(numeric_s, unit='D', origin='1899-12-30', errors='coerce')
        dt_str = pd.to_datetime(s, errors='coerce')
        return dt_num.fillna(dt_str)

    # Pre-convert date columns
    for col in ['AE', 'AF', 'AJ', 'AW']:
        if col in calc_df.columns:
            calc_df[col] = to_dt(col)

    # AY: Inforce/Paid up mapping (Helper Logic)
    def map_status(val):
        s = str(val).upper().strip()
        if s in ['IF', 'INFORCE', 'L1', 'L2']: return 'IF'
        if s in ['PU', 'PAID UP', 'FL', 'FULLY PAID UP']: return 'PU'
        if s in ['DH', 'DEATH']: return 'DH'
        return s
    calc_df['AY'] = calc_df['B'].apply(map_status)
    
    # AZ: PPT * FREQ
    calc_df['AZ'] = pd.to_numeric(calc_df['AC'], errors='coerce') * pd.to_numeric(calc_df['AD'], errors='coerce')
    
    # BA: Prem Paid * FREQ
    calc_df['BA'] = np.round((calc_df['AF'] - calc_df['AE']).dt.days / 365 * pd.to_numeric(calc_df['AD'], errors='coerce'), 0)
    
    # BD: Date of Death
    calc_df['BD'] = calc_df['AJ']
    
    # BH: Death Status
    def calc_bh(row):
        if str(row['AY']).upper() != 'DH': return 'NA'
        af, bd = row['AF'], row['BD']
        if pd.isna(af) or pd.isna(bd): return 'NA'
        gp = 30 if row['AD'] != 12 else 15
        return 'Inforce Death' if (af + pd.Timedelta(days=gp)) >= bd else 'Paidup Death'
    calc_df['BH'] = calc_df.apply(calc_bh, axis=1)

    # BB: (Updated SA)
    def calc_bb(row):
        ay = str(row['AY']).upper()
        # Use AV (index 47 - CURRENT SA) as the base SA for calculations
        sa_val = to_num(row['AV'])
        ba_val, az_val = to_num(row['BA']), to_num(row['AZ'])
        if ay == 'IF': return sa_val
        if ay == 'PU': 
            # If it's already pro-rated in input, we keep it, otherwise we pro-rate
            # Usually CURRENT SA is already pro-rated in PU cases in their Excel
            return sa_val
        if ay == 'DH':
            return sa_val if row['BH'] == 'Inforce Death' else sa_val
        return sa_val
    calc_df['BB'] = calc_df.apply(calc_bb, axis=1)

    # BC: Current Year
    def datedif_y(start, end):
        if pd.isna(start) or pd.isna(end): return 0
        try: return end.year - start.year - ((end.month, end.day) < (start.month, start.day))
        except: return 0
    calc_df['BC'] = [datedif_y(s, e) for s, e in zip(calc_df['AE'], calc_df['AW'])]

    # BE: Accrued Loan Interest
    def calc_be(row):
        aw = row['AW']
        if pd.isna(aw) or aw <= cutoff_date: return 0
        m, n = to_num(row['M']), to_num(row['N'])
        days = (aw - cutoff_date).days
        return (m + n) * ((1 + interest_rate)**(days / 365) - 1)
    calc_df['BE'] = calc_df.apply(calc_be, axis=1)

    # BF: Updated LN_LA
    calc_df['BF'] = pd.to_numeric(calc_df['N'], errors='coerce').fillna(0) + calc_df['BE']

    # BG: SB Due Check
    calc_df['BG'] = calc_df['AY'].apply(lambda x: "SB eligible" if str(x).upper() in ["PU", "IF", "DH"] else "SB Not Eligible")

    # BI: Premium paid years
    calc_df['BI'] = [datedif_y(s, e) for s, e in zip(calc_df['AE'], calc_df['AF'])]

    # BK: Death Status (Complex)
    def calc_bk(row):
        if str(row['AY']).upper() != 'DH': return 'NA'
        af, aj, bi, y = row['AF'], row['AJ'], row['BI'], str(row['Y']).upper()
        gp = 30 if row['AD'] != 12 else 15
        if (af + pd.Timedelta(days=gp)) < aj:
            # Lapsed criteria. The 'concern' sheet writes "=<1 / =<2 / =<3" but
            # the actual Excel formula (and the golden CK values) use a STRICT
            # less-than: a MBN policy with 3 premium-paid years is "Paidup
            # Death", not "Lapsed Death". MBG < 1, MSB < 2, MBN/others < 3.
            lapsed = (y == 'MBG' and bi < 1) or (y == 'MSB' and bi < 2) or (y not in ['MBG', 'MSB'] and bi < 3)
            return 'Lapsed Death' if lapsed else 'Paidup Death'
        return 'Inforce Death'
    calc_df['BK'] = calc_df.apply(calc_bk, axis=1)

    # VLOOKUP & Rates
    calc_df['BL'] = calc_df.apply(lambda r: RATE_CHARTS['imp_mpi'].get(int(r['BC']), 0) if str(r['AY']).upper() == 'IF' and str(r['Y']).upper() in ['IMP', 'MPI'] else 0, axis=1)
    calc_df['BM'] = calc_df.apply(lambda r: RATE_CHARTS['csr'].get(int(r['BC']), 0) if str(r['AY']).upper() == 'IF' and str(r['Y']).upper() == 'CSR' else 0, axis=1)
    calc_df['BN'] = calc_df.apply(lambda r: RATE_CHARTS['mbg_mbn'].get(f"{int(to_num(r['AB']))}-{int(to_num(r['BC']))}", 0) if str(r['Y']).upper() in ['MBG', 'MBN'] else 0, axis=1)
    calc_df['BO'] = calc_df.apply(lambda r: (500/r['AB'])/100 if str(r['Y']).upper() in ['MSB', 'SMB'] and str(r['AY']).upper() in ['IF', 'PU'] and r['BC'] <= r['AB'] and r['BC'] % 5 == 0 and r['AB'] else 0, axis=1)
    
    # RFI logic: BQ = Updated SA (BB) + BP (RFI RV Bonus)
    def calc_bp(row):
        if str(row['Y']).upper() == 'RFI':
            ry = abs(to_num(row['E']))
            if str(row['AY']).upper() == 'IF':
                bc = row['BC']
                if bc > 0:
                    return ry / bc * (bc - 1)
            return ry
        return 0
    calc_df['BP'] = calc_df.apply(calc_bp, axis=1)
    
    calc_df['BQ'] = calc_df.apply(lambda r: r['BB'] + r['BP'] if str(r['Y']).upper() == 'RFI' else 0, axis=1)
    calc_df['BR'] = calc_df.apply(lambda r: RATE_CHARTS['rfi'].get(int(to_num(r['AB'])), {}).get('pct', 0) if str(r['Y']).upper() == 'RFI' and r['BC'] >= RATE_CHARTS['rfi'].get(int(to_num(r['AB'])), {}).get('start', 99) and r['BC'] <= r['AB'] else 0, axis=1)

    # WLI Logic
    def calc_bs(row):
        if str(row['Y']).upper() == 'WLI' and str(row['AY']).upper() in ['IF', 'PU']:
            for t in RATE_CHARTS['wli']:
                if row['BB'] >= t['low'] and row['BB'] <= t['high']: return t['pct']
        return 0
    calc_df['BS'] = calc_df.apply(calc_bs, axis=1)
    
    # BT: WLI Guaranteed Income
    calc_df['BT'] = calc_df.apply(lambda r: r['BB'] * r['BS'] if str(r['Y']).upper() == 'WLI' else 0, axis=1)
    # BU: WLI Cash Bonus
    calc_df['BU'] = calc_df.apply(lambda r: r['BB'] * 0.058 if str(r['Y']).upper() == 'WLI' and str(r['AY']).upper() == 'IF' else 0, axis=1)
    # BV: Total WLI (Sum of BT and BU)
    calc_df['BV'] = calc_df['BT'] + calc_df['BU']
    
    # S1 (CPP/CHP) Logic - Keep using AS (index 44) for S1 as per its original doc
    def calc_s1_bk_val(row):
        az, ba, rt = to_num(row['AZ']), to_num(row['BA']), to_num(row['AB'])
        return int(np.floor(min(max((ba / az if az else 0) * rt - (rt - 4), 0), 3)))
    def calc_s1_bl_val(row):
        bk, bb, as_v = calc_s1_bk_val(row), to_num(row['BB']), to_num(row['AS'])
        return bb / 4 if bk < 1 else ((bb - (as_v / 4 * bk)) / (4 - bk) if (4 - bk) > 0 else 0)
    def calc_s1_bp_val(row):
        bb, as_v = to_num(row['BB']), to_num(row['AS'])
        bn = 0.003 if as_v >= 500000 else (0.002 if as_v >= 250000 else 0)
        return (bb / 4) + ((bb * bn) / 4)

    calc_df['S1_BL'] = calc_df.apply(calc_s1_bl_val, axis=1)
    calc_df['S1_BP'] = calc_df.apply(calc_s1_bp_val, axis=1)

    # CJ: SB Amount Mapping
    def calc_cj(row):
        y, ay, bg = str(row['Y']).upper(), str(row['AY']).upper(), str(row['BG'])
        if bg != "SB eligible": return 0
        
        # PU Eligibility Enforcement
        if ay == 'PU' and y in ['IMP', 'MPI', 'CSR', 'MBP', 'SEP', 'RFP']:
            return 0
            
        if y == 'CPP': return row['S1_BL']
        if y == 'CHP': return row['S1_BP']
        if y in ['IMP', 'MPI']: return row['BB'] * row['BL']
        if y == 'CSR': return row['BB'] * row['BM']
        if y == 'MBG': return row['BB'] * row['BN']
        if y == 'MBN': return row['BB'] * row['BN']
        if y == 'RFI': return row['BQ'] * row['BR']
        if y in ['MSB', 'SMB']: return row['BB'] * row['BO']
        if y == 'WLI': return row['BV']
        if y == 'MBP': return to_num(row['BB']) / ((to_num(row['AB']) - 1) / 3) if to_num(row['AB']) > 1 else 0
        if y == 'SEP': return row['BB'] if row['BC'] == row['AC'] else 0
        if y == 'RFP': return to_num(row['AV']) if row['BC'] == row['AC'] else 0
        return 0
    calc_df['CJ'] = calc_df.apply(calc_cj, axis=1)

    # CK: Final SB Amount
    calc_df['CK'] = calc_df.apply(lambda r: 0 if str(r['BK']) == 'Lapsed Death' else max(0, to_num(r['CJ']) - (to_num(r['M']) + to_num(r['BF']))), axis=1)

    # CL: Calculator Used
    calc_df['CL'] = calc_df['Y'].apply(lambda y: "S1" if str(y).upper() in ["CPP", "CHP"] else "S2")

    # Result selection
    # Only return A-AW (0-48), CJ (87), CK (88)
    # Total columns: 49 + 2 = 51
    result_cols = letter_cols[:49] + ['CJ', 'CK']
    result_df = calc_df[result_cols]
    
    # Set uniform result headers
    final_headers = [HEADERS[i] for i in range(49)] + ["SB Amount", "Final SB Amount - Loan Adj"]
    result_df.columns = final_headers
    return result_df

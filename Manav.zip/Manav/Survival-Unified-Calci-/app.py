from flask import Flask, render_template, request, send_file, redirect, url_for
import os
import pandas as pd
from calculator import calculate_survival, read_calc_sheet
from excel_writer import write_formatted_excel
from datetime import datetime

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    if file:
        input_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(input_path)
        
        try:
            # Headers are on Row 2 (header=1), data from Row 3. The data may not
            # be on the first sheet (the .xlsb has a 'Notes' sheet first), so use
            # the sheet picker rather than a blind pd.read_excel.
            df_input = read_calc_sheet(input_path)

            # Get parameters from form
            cutoff_date = request.form.get('cutoff_date')
            interest_rate = request.form.get('interest_rate')
            
            # Convert empty strings to None so defaults are used
            cutoff_date = cutoff_date if cutoff_date else None
            interest_rate = interest_rate if interest_rate else None

            # Perform calculation
            df_output = calculate_survival(df_input, cutoff_date=cutoff_date, interest_rate=interest_rate)
            
            # Generate output file name
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"Survival_Output_{timestamp}.xlsx"
            output_path = os.path.join(OUTPUT_FOLDER, output_filename)
            
            # Write formatted excel
            write_formatted_excel(df_output, output_path)
            
            return send_file(output_path, as_attachment=True)
            
        except Exception as e:
            return f"Error processing file: {e}"

if __name__ == "__main__":
    app.run(debug=True)

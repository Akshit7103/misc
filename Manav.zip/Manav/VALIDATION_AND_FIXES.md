# Survival Calculators — Validation & Fixes

**Date:** 2026-05-31
**Scope:** `S1-Calci`, `S2-Calci`, `Survival-Unified-Calci-`

This document records the validation performed on the three survival-benefit
calculators and every change made to fix the issues found.

---

## 1. What was validated

Each Python port was checked against the **Excel workbook's own cached output
values** (the golden truth produced by the original Excel formulas), row by row,
for every product type and policy status.

| Folder | Reference file | Inputs | Outputs | Products |
| --- | --- | --- | --- | --- |
| `S1-Calci` | `Survival_Calc 1_CPP CHP…xlsx` | A:AW | **BR, BS** | CPP, CHP |
| `S2-Calci` | `Survival Calc 2_Others…xlsb` | A:AW | **CJ, CK** | CSR, IMP, MPI, MBG, MBN, MBP, MSB, SMB, RFI, RFP, SEP, WLI |
| `Survival-Unified-Calci-` | both of the above | A:AW | **CJ, CK** (routed by CNTTYPE) | all of the above |

> **Note on naming:** the request referred to the `.xlsb` calculator as
> "S1-Calci", but by file contents the `.xlsb` (other products, CJ/CK output)
> is actually **S2-Calci**, and the `.xlsx` (CPP/CHP, BR/BS output) is
> **S1-Calci**. This document uses the by-contents mapping above.

### Validation results

| Calculator | Before fixes | After fixes |
| --- | --- | --- |
| S1 (CPP/CHP) | 6 / 6 ✓ | 6 / 6 ✓ |
| S2 (other products) | **8 / 26 ✗** | **26 / 26 ✓** |
| Unified (both datasets) | 31 / 32 | **32 / 32 ✓** |

Regression harnesses were created and left in the `Manav\` folder:
`_validate_s1.py`, `_validate_s2.py`, `_validate_unified.py`.

---

## 2. Issues found and fixes made

### Issue 1 — S2: dates read as serial numbers were misinterpreted (CRITICAL)

**File:** `S2-Calci/calculator.py`

**Problem:** When pandas reads the `.xlsb`, date cells come back as **Excel
serial integers** (e.g. `46130`), not datetimes. The code called
`pd.to_datetime(value)` directly on them, which interprets the integer as
*nanoseconds since 1970* — turning every date into 1 January 1970. As a result
every date-dependent value silently collapsed:

- `Current Year` (BC) → 0
- `Accrued Loan Interest` (BE) → 0
- All rate-chart lookups keyed by policy year (IMP/MPI, CSR, MBG/MBN, MSB/SMB,
  RFI %) → 0

This made **18 of 26 rows wrong**.

**Fix:** Replaced the date helper with a robust converter that handles serial
numbers *and* datetimes/strings, and pre-converted all date columns once:

```python
def to_dt(col):
    s = calc_df[col]
    numeric_s = pd.to_numeric(s, errors='coerce')
    dt_num = pd.to_datetime(numeric_s, unit='D', origin='1899-12-30', errors='coerce')
    dt_str = pd.to_datetime(s, errors='coerce')
    return dt_num.fillna(dt_str)

for _dcol in ['AE', 'AF', 'AJ', 'AW']:
    if _dcol in calc_df.columns:
        calc_df[_dcol] = to_dt(_dcol)
```

(This is the same approach the Unified calculator already used.)

**Result:** S2 went from 8/26 to **26/26**.

---

### Issue 2 — Unified: off-by-one in the lapsed-death rule

**File:** `Survival-Unified-Calci-/calculator.py`

**Problem:** The lapse thresholds used `<=` (`bi <= 1`, `bi <= 2`, `bi <= 3`).
The actual Excel formula and the golden output use a **strict `<`**. A MBN death
claim with exactly 3 premium-paid years is *"Paidup Death"*, not *"Lapsed
Death"* — but the `<=` version wrongly classified it as lapsed and zeroed its
final amount (CK). This was the single failing row (row 11, MBN/DH).

**Fix:**

```python
# before: bi <= 1 / bi <= 2 / bi <= 3
lapsed = (y == 'MBG' and bi < 1) or (y == 'MSB' and bi < 2) or (y not in ['MBG', 'MSB'] and bi < 3)
```

The `concern` sheet writes the rule as "=<1 / =<2 / =<3", but the Excel cached
value (BI=3 → "Paidup Death") confirms the implemented rule is strict `<`. This
also brings the Unified calc in line with the validated S2 standalone.

> This supersedes the corresponding line in `CHANGES_LOG.md` which still
> describes the rule as `<=`.

**Result:** Unified went from 31/32 to **32/32**.

---

### Issue 3 — All apps: wrong sheet read for multi-sheet workbooks (CRITICAL for .xlsb)

**Files:** `S2-Calci/app.py` + `calculator.py`,
`Survival-Unified-Calci-/app.py` + `calculator.py`,
`S1-Calci/app.py` + `calculations.py`

**Problem:** The apps read the upload with `pd.read_excel(path, header=1)` and
**no `sheet_name`**, which defaults to the *first* sheet. The reference `.xlsb`'s
first sheet is `'Notes'`, not `'Calc 2_other Products'` — so the S2 and Unified
apps would read explanatory notes (a 2-row, 8-column block) instead of the
policy data and produce garbage/empty output.

**Fix:** Added a `read_calc_sheet()` helper to each calculator module that picks
the sheet whose row-2 header begins with `CONTRACT_NUMBER` (the canonical first
input column), falling back to the first sheet:

```python
def read_calc_sheet(path):
    xls = pd.ExcelFile(path)
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet, header=1)
        if len(df.columns) and str(df.columns[0]).strip().upper() == "CONTRACT_NUMBER":
            return df
    return pd.read_excel(xls, sheet_name=0, header=1)
```

All three apps now call `read_calc_sheet(...)` instead of the blind
`pd.read_excel(...)`. (S1's `.xlsx` happened to have its data sheet first, so it
worked before, but it now reads robustly too.)

---

## 3. End-to-end checks performed

- Full **read → calculate → write** pipeline for all three apps via the real
  `read_calc_sheet` path — correct row counts, headers, and CJ/CK values.
- Unified's **configurable cutoff date / interest rate** confirmed to change the
  loan-adjusted final amount (CK) as expected when the cutoff is moved.

---

## 4. Known limitation (not a bug — correct on the reference data)

**S2 RFI "RV Bonus" is hardcoded per contract.**
`S2-Calci/calculator.py` holds a `RFI_BONUS` dictionary of two specific test
contracts. It reproduces the reference file exactly, but returns 0 for any RFI
contract not in the dictionary. The **Unified** calculator is more general here —
it derives the bonus from a formula (`abs(LE_RY) / Current Year * (Current Year − 1)`
for IF policies) and matched both RFI rows. If S2 needs to handle arbitrary RFI
portfolios, the bonus-rate-table logic from the `RFI RV Bonus` sheet should be
ported into `calculator.py` — this is a follow-up enhancement, not a fix to an
existing wrong result.

---

## 5. Files changed

| File | Change |
| --- | --- |
| `S2-Calci/calculator.py` | Robust date conversion (Issue 1); `read_calc_sheet` helper (Issue 3) |
| `S2-Calci/app.py` | Use `read_calc_sheet` (Issue 3) |
| `Survival-Unified-Calci-/calculator.py` | Strict `<` lapse rule (Issue 2); `read_calc_sheet` helper (Issue 3) |
| `Survival-Unified-Calci-/app.py` | Use `read_calc_sheet` (Issue 3) |
| `S1-Calci/calculations.py` | `read_calc_sheet` helper (Issue 3) |
| `S1-Calci/app.py` | Use `read_calc_sheet` (Issue 3) |
| `Manav/_validate_s1.py`, `_validate_s2.py`, `_validate_unified.py` | New regression harnesses |

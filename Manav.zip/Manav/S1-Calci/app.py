
import os
from flask import Flask, render_template, request, send_file, redirect, url_for, flash
import pandas as pd
from calculations import calculate_survival_benefit, read_calc_sheet
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
import io

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "secret_key_for_session")
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file:
        try:
            # Read input excel. Headers on row 2; pick the CONTRACT_NUMBER sheet
            # so multi-sheet uploads don't read the wrong tab.
            df = read_calc_sheet(file)
            
            # Perform calculations
            result_df = calculate_survival_benefit(df)
            
            # Prepare output excel
            # Columns to keep: A-AW (0 to 48) and BR, BS (69, 70)
            # BR: Survival Benefit CPP and CHP
            # BS: Survival Benefit - Loan Adjustment
            input_cols = df.columns[:49].tolist()
            output_cols = ['Survival Benefit CPP and CHP', 'Survival Benefit - Loan Adjustment']
            final_df = result_df[input_cols + output_cols]
            
            # Generate styled excel
            output = io.BytesIO()
            wb = Workbook()
            ws = wb.active
            ws.title = "Survival Benefit Calculation"
            
            # Styles
            header_fill_orange = PatternFill(start_color="FFFFC000", end_color="FFFFC000", fill_type="solid")
            header_fill_blue = PatternFill(start_color="D9EAD3", end_color="D9EAD3", fill_type="solid") # Placeholder
            header_font = Font(bold=True, name='Aptos Narrow', size=11)
            data_font = Font(name='Calibri', size=11)
            thin_border = Border(left=Side(style='thin'), 
                                 right=Side(style='thin'), 
                                 top=Side(style='thin'), 
                                 bottom=Side(style='thin'))
            
            # Write data
            for r in dataframe_to_rows(final_df, index=False, header=True):
                ws.append(r)
            
            # Apply formatting
            for col_idx in range(1, len(final_df.columns) + 1):
                cell = ws.cell(row=1, column=col_idx)
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                cell.border = thin_border
                
                # Highlight output columns
                if ws.cell(row=1, column=col_idx).value in output_cols:
                    cell.fill = header_fill_orange
                else:
                    # Optional: style for input headers
                    pass
                    
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.font = data_font
                    cell.border = thin_border

            # Auto-adjust column width
            for column in ws.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = (max_length + 2)
                ws.column_dimensions[column_letter].width = adjusted_width

            wb.save(output)
            output.seek(0)
            
            return send_file(output, 
                             as_attachment=True, 
                             download_name='Survival_Benefit_Output.xlsx', 
                             mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            
        except Exception as e:
            flash(f'Error processing file: {str(e)}')
            return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)

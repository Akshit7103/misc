
import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.relativedelta import relativedelta
import math


def read_calc_sheet(path):
    """Read the calculation sheet from an uploaded workbook.

    Headers are on row 2 (header=1). If the workbook has several sheets, pick
    the one whose row-2 header begins with CONTRACT_NUMBER (the canonical first
    input column) rather than blindly reading the first sheet; fall back to the
    first sheet.
    """
    xls = pd.ExcelFile(path)
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet, header=1)
        if len(df.columns) and str(df.columns[0]).strip().upper() == "CONTRACT_NUMBER":
            return df
    return pd.read_excel(xls, sheet_name=0, header=1)


def calculate_survival_benefit(df):
    # Drop rows that are completely empty
    df = df.dropna(how='all').copy()

    # Constants from the example file
    VALUATION_DATE = pd.to_datetime('2026-03-31')
    INTEREST_RATE = 0.0825

    # Ensure date columns are datetime objects
    date_cols = ['ISSDATE', 'FIRSTISSDT', 'RCDDATE', 'PAIDTODATE', 'RISKCESDTE', 'PREMCESDTE', 'CLTDOB', 'CLTDOD', 'NEXT_PAYDATE']
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # Fill NaNs for numeric columns used in calculations
    numeric_cols = ['PREM TERM', 'FREQUENCY', 'ORIGINAL_SA', 'RISK TERM', 'LN_LO_AMT', 'LN_LA_AMT']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # AY: Inforce/Paid up
    df['Inforce/Paid up'] = df['STATUS'].fillna('')

    # AZ: PPT * FREQ
    df['PPT * FREQ'] = df['PREM TERM'] * df['FREQUENCY']

    # BA: Prem Paid * FREQ
    # =ROUND((AF5-AE5)/365*AD5,0)
    # AF: PAIDTODATE, AE: RCDDATE, AD: FREQUENCY
    df['Prem Paid * FREQ'] = ((df['PAIDTODATE'] - df['RCDDATE']).dt.days / 365 * df['FREQUENCY']).round(0)

    # BH: Death Status (Needed for BB)
    # =IF(B5<>"DH","NA",IF((AF5+IF(AD5<>12,30,15)>=BF5),"Inforce Death","Paidup Death"))
    # BF is Date of Death (AJ: CLTDOD)
    def get_death_status(row):
        if row['STATUS'] != 'DH':
            return 'NA'
        grace_period = 30 if row['FREQUENCY'] != 12 else 15
        paid_to_date_plus_grace = row['PAIDTODATE'] + pd.Timedelta(days=grace_period)
        if pd.isna(row['CLTDOD']):
            return 'NA'
        if paid_to_date_plus_grace >= row['CLTDOD']:
            return 'Inforce Death'
        else:
            return 'Paidup Death'

    df['Death Status'] = df.apply(get_death_status, axis=1)

    # BB: (Updated SA)
    # =IFS(AY5="IF", AS5, AY5="PU", AS5*BA5/AZ5, AND(AY5="DH", BH5="Inforce Death"), AS5, AND(AY5="DH", BH5="Paidup Death"), AS5*BA5/AZ5)
    # AS: ORIGINAL_SA
    def get_updated_sa(row):
        ay = row['Inforce/Paid up']
        bh = row['Death Status']
        as_val = row['ORIGINAL_SA']
        ba = row['Prem Paid * FREQ']
        az = row['PPT * FREQ']
        
        if ay == 'IF':
            return as_val
        elif ay == 'PU':
            return as_val * ba / az if az != 0 else 0
        elif ay == 'DH':
            if bh == 'Inforce Death':
                return as_val
            elif bh == 'Paidup Death':
                return as_val * ba / az if az != 0 else 0
        return 0

    df['Updated SA'] = df.apply(get_updated_sa, axis=1)

    # BC: Current Year
    # =DATEDIF(AE5,AW5,"y")
    def get_datedif_y(start_date, end_date):
        if pd.isna(start_date) or pd.isna(end_date):
            return 0
        return relativedelta(end_date, start_date).years

    df['Current Year'] = df.apply(lambda x: get_datedif_y(x['RCDDATE'], x['NEXT_PAYDATE']), axis=1)

    # BD: For Current Month Accrued Loan Interest
    # =IF(AW5<=$BD$1,0,(M5+N5)*((1+$BE$1)^((AW5-$BD$1)/365)-1))
    # M: LN_LO_AMT, N: LN_LA_AMT
    def get_accrued_interest(row):
        aw = row['NEXT_PAYDATE']
        if pd.isna(aw) or aw <= VALUATION_DATE:
            return 0
        m_n_sum = row['LN_LO_AMT'] + row['LN_LA_AMT']
        days_diff = (aw - VALUATION_DATE).days
        return m_n_sum * ((1 + INTEREST_RATE)**(days_diff / 365) - 1)

    df['Accrued Interest'] = df.apply(get_accrued_interest, axis=1)

    # BE: Updated LN_LA
    # =N5+BD5
    df['Updated LN_LA'] = df['LN_LA_AMT'] + df['Accrued Interest']

    # BF: Date of Death
    df['Date of Death'] = df['CLTDOD']

    # BG: SB Due Check
    # =IF(AND(AY5<>"PU",AY5<>"IF",AY5<>"DH"),"SB Not Eligible","SB eligible")
    df['SB Due Check'] = np.where(df['Inforce/Paid up'].isin(['PU', 'IF', 'DH']), 'SB eligible', 'SB Not Eligible')

    # BI: Premium Paid Years
    # =ROUNDDOWN(DATEDIF(AE5,AF5,"Y"),0)
    df['Premium Paid Years'] = df.apply(lambda x: get_datedif_y(x['RCDDATE'], x['PAIDTODATE']), axis=1)

    # BJ: Lapsed Death (Check)
    # =IF(B5<>"DH","NA",IF(AND(BI5<3,AF5+IF(AD5<>12,30,15)<AJ5),"Lapsed Death",IF(AF5+IF(AD5<>12,30,15)>=AJ5,"Inforce Death","Paidup Death")))
    def get_lapsed_death_check(row):
        if row['STATUS'] != 'DH':
            return 'NA'
        bi = row['Premium Paid Years']
        grace_period = 30 if row['FREQUENCY'] != 12 else 15
        paid_to_date_plus_grace = row['PAIDTODATE'] + pd.Timedelta(days=grace_period)
        if pd.isna(row['CLTDOD']):
            return 'NA'
        if bi < 3 and paid_to_date_plus_grace < row['CLTDOD']:
            return 'Lapsed Death'
        elif paid_to_date_plus_grace >= row['CLTDOD']:
            return 'Inforce Death'
        else:
            return 'Paidup Death'

    df['Lapsed Death Check'] = df.apply(get_lapsed_death_check, axis=1)

    # BK: CPP
    # =ROUNDDOWN((MIN(MAX( (BA5/AZ5)*AB5 - (AB5-4), 0), 3)),0)
    # AB: RISK TERM
    def get_cpp_val(row):
        az = row['PPT * FREQ']
        ba = row['Prem Paid * FREQ']
        ab = row['RISK TERM']
        if az == 0: return 0
        val = (ba / az) * ab - (ab - 4)
        return math.floor(min(max(val, 0), 3))

    df['CPP'] = df.apply(get_cpp_val, axis=1)

    # BL: CPP Base SB
    # =IF(BK5<1,(BB5/4),(BB5-(AS5/4*BK5))/(4-BK5))
    def get_cpp_base_sb(row):
        bk = row['CPP']
        bb = row['Updated SA']
        as_val = row['ORIGINAL_SA']
        if bk < 1:
            return bb / 4
        else:
            return (bb - (as_val / 4 * bk)) / (4 - bk)

    df['CPP Base SB'] = df.apply(get_cpp_base_sb, axis=1)

    # BM: CHP BASE SB
    # =BB5/4
    df['CHP BASE SB'] = df['Updated SA'] / 4

    # BN: CHP High SA %
    # =IF(Y5<>"CHP","0",IF(AS5<250000,0,IF(AS5<500000,0.002,0.003)))
    def get_chp_high_sa_pct(row):
        if row['CNTTYPE'] != 'CHP':
            return 0
        as_val = row['ORIGINAL_SA']
        if as_val < 250000:
            return 0
        elif as_val < 500000:
            return 0.002
        else:
            return 0.003

    df['CHP High SA %'] = df.apply(get_chp_high_sa_pct, axis=1)

    # BO: CHP High SA
    # =IFERROR(BB5*BN5,0)/4
    df['CHP High SA'] = (df['Updated SA'] * df['CHP High SA %']).fillna(0) / 4

    # BP: CHP SB
    # =IF(AND(BG5="SB eligible",BH5<>"SB Not eligible",Y5="CHP"),BM5+BO5,0)
    # Note: BH5 value is never "SB Not eligible", but the logic seems to be checking eligibility.
    # We use our calculated columns.
    df['CHP SB'] = np.where(
        (df['SB Due Check'] == 'SB eligible') & 
        (df['Death Status'] != 'SB Not eligible') & 
        (df['CNTTYPE'] == 'CHP'),
        df['CHP BASE SB'] + df['CHP High SA'],
        0
    )

    # BQ: CPP SB
    # =IF(AND(BG5="SB eligible",BH5<>"SB Not eligible",Y5="CPP"),BL5,0)
    df['CPP SB'] = np.where(
        (df['SB Due Check'] == 'SB eligible') & 
        (df['Death Status'] != 'SB Not eligible') & 
        (df['CNTTYPE'] == 'CPP'),
        df['CPP Base SB'],
        0
    )

    # BR: Survival Benefit CPP and CHP
    # =IFS(Y5="CHP",BP5,Y5="CPP",BQ5)
    def get_total_sb(row):
        if row['CNTTYPE'] == 'CHP':
            return row['CHP SB']
        elif row['CNTTYPE'] == 'CPP':
            return row['CPP SB']
        return 0

    df['Survival Benefit CPP and CHP'] = df.apply(get_total_sb, axis=1)

    # BS: Survival Benefit - Loan Adjustment
    # =IF(BJ5="Lapsed Death",0,MAX(0,BR5-SUM(M5+BE5)))
    # M: LN_LO_AMT, BE: Updated LN_LA
    def get_loan_adj_sb(row):
        if row['Lapsed Death Check'] == 'Lapsed Death':
            return 0
        br = row['Survival Benefit CPP and CHP']
        deductions = row['LN_LO_AMT'] + row['Updated LN_LA']
        return max(0, br - deductions)

    df['Survival Benefit - Loan Adjustment'] = df.apply(get_loan_adj_sb, axis=1)

    return df

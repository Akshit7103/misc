
# Survival Benefit Calculator

A Flask-based web application to automate Survival Benefit calculations from an Excel input.

## Features
- Upload an Excel file containing input columns (A-AW).
- Automatically performs complex survival benefit calculations based on established formulas.
- Generates a styled Excel output containing the original input and the calculated results.
- Maintains the color scheme and formatting of the original Excel tool.

## Installation

1. Ensure you have Python 3.11+ installed.
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   .\venv\Scripts\activate  # On Windows
   source venv/bin/activate  # On macOS/Linux
   ```
3. Install the required dependencies:
    ```bash
   pip install -r requirements.txt
    ```

## Usage

1. Start the Flask application:
    ```bash
    python app.py
   ```
2. Open your web browser and navigate to `http://127.0.0.1:5000`.
3. Select your input Excel file and click **Generate Output**.
4. The processed file will be downloaded automatically.

## Render deployment

- **Build command:** `pip install -r requirements.txt`
- **Start command:** `gunicorn app:app`

## Project Structure
- `app.py`: The main Flask application and Excel generation logic.
- `calculations.py`: The core calculation engine translating Excel formulas to Python.
- `templates/`: HTML templates for the web interface.
- `static/`: CSS styles for the web interface.

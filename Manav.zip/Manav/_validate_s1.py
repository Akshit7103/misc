"""Validate S1-Calci (CPP/CHP) Python port against the Excel's own cached
BR/BS outputs.

Reads the reference workbook's A:AW inputs (cached values) plus its cached
BR (Survival Benefit CPP and CHP) and BS (Survival Benefit - Loan Adjustment)
columns, runs calculations.calculate_survival_benefit, and compares.
"""
from __future__ import annotations

import sys
from pathlib import Path

import openpyxl
import pandas as pd

S1 = Path(r"C:\Users\akshi\OneDrive\Desktop\Insurance\Manav\S1-Calci")
REF = S1 / "Survival_Calc 1_CPP CHP_Mar Apr May_ Auto.xlsx"
SHEET = "Calc 1 - CHP CPP "
N_INPUT = 49           # A..AW
BR_COL, BS_COL = 70, 71
DATA_START = 3

sys.path.insert(0, str(S1))
import calculations  # noqa: E402


def load_input_and_golden():
    wb = openpyxl.load_workbook(REF, data_only=True)
    ws = wb[SHEET]
    headers = [ws.cell(2, c).value for c in range(1, N_INPUT + 1)]
    # find last data row
    last = DATA_START - 1
    for r in range(DATA_START, 5000):
        if ws.cell(r, 1).value not in (None, ""):
            last = r
        else:
            break
    rows, golden = [], []
    for r in range(DATA_START, last + 1):
        rows.append([ws.cell(r, c).value for c in range(1, N_INPUT + 1)])
        golden.append((ws.cell(r, BR_COL).value, ws.cell(r, BS_COL).value))
    wb.close()
    df = pd.DataFrame(rows, columns=headers)
    return df, golden


def num(v):
    try:
        return float(v) if v is not None and v != "" else 0.0
    except (TypeError, ValueError):
        return None


def close(a, b, tol=0.01):
    na, nb = num(a), num(b)
    if na is None or nb is None:
        return str(a) == str(b)
    return abs(na - nb) <= tol


def main() -> int:
    df, golden = load_input_and_golden()
    print(f"Loaded {len(df)} data rows")
    out = calculations.calculate_survival_benefit(df.copy())
    br = out["Survival Benefit CPP and CHP"].tolist()
    bs = out["Survival Benefit - Loan Adjustment"].tolist()

    failures = []
    for i, (g_br, g_bs) in enumerate(golden):
        r = DATA_START + i
        if not close(g_br, br[i]):
            failures.append(f"row {r} BR: excel={g_br!r} python={br[i]!r}")
        if not close(g_bs, bs[i]):
            failures.append(f"row {r} BS: excel={g_bs!r} python={bs[i]!r}")
        status = "OK" if close(g_br, br[i]) and close(g_bs, bs[i]) else "FAIL"
        print(f"  row {r} [{df.iloc[i]['CNTTYPE']}/{df.iloc[i]['STATUS']}] "
              f"BR excel={g_br!r} py={br[i]!r} | BS excel={g_bs!r} py={bs[i]!r}  {status}")

    if failures:
        print("\nFAILURES:")
        for f in failures:
            print("  -", f)
        return 1
    print("\nS1 VALIDATION PASSED — Python matches Excel BR/BS for all rows")
    return 0


if __name__ == "__main__":
    sys.exit(main())

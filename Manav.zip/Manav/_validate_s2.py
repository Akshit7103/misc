"""Validate S2-Calci (other products) Python port against the xlsb's own
cached CJ (SB Amount) and CK (Final SB Amount - Loan Adj) outputs.

Mimics exactly what app.py does: pd.read_excel(header=1) then first 49 cols.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

S2 = Path(r"C:\Users\akshi\OneDrive\Desktop\Insurance\Manav\S2-Calci")
REF = S2 / "Survival Calc 2_Others_Mar_Apr May_Auto_1.xlsb"
SHEET = "Calc 2_other Products"
CJ_IDX, CK_IDX = 87, 88  # 0-based: CJ=col88, CK=col89

sys.path.insert(0, str(S2))
import calculator  # noqa: E402


def num(v):
    try:
        return float(v) if v is not None and v != "" else 0.0
    except (TypeError, ValueError):
        return None


def close(a, b, tol=0.5):
    na, nb = num(a), num(b)
    if na is None or nb is None:
        return str(a) == str(b)
    return abs(na - nb) <= tol


def main() -> int:
    full = pd.read_excel(REF, sheet_name=SHEET, header=1)
    golden_cj = full.iloc[:, CJ_IDX].tolist()
    golden_ck = full.iloc[:, CK_IDX].tolist()
    cnttype = full.iloc[:, 24].tolist()
    status = full.iloc[:, 1].tolist()

    df_input = full.iloc[:, :49].copy()
    out = calculator.calculate_survival(df_input)
    py_cj = out.iloc[:, -2].tolist()
    py_ck = out.iloc[:, -1].tolist()

    failures = 0
    print(f"{'row':>3} {'Y':<5} {'St':<4} {'CJ excel':>14} {'CJ py':>14} {'CK excel':>14} {'CK py':>14}  res")
    for i in range(len(df_input)):
        ok = close(golden_cj[i], py_cj[i]) and close(golden_ck[i], py_ck[i])
        if not ok:
            failures += 1
        print(f"{i+3:>3} {str(cnttype[i]):<5} {str(status[i]):<4} "
              f"{num(golden_cj[i]):>14.2f} {num(py_cj[i]):>14.2f} "
              f"{num(golden_ck[i]):>14.2f} {num(py_ck[i]):>14.2f}  {'OK' if ok else 'FAIL'}")

    print(f"\n{len(df_input)-failures}/{len(df_input)} rows match")
    if failures:
        print(f"S2 VALIDATION FAILED — {failures} rows differ")
        return 1
    print("S2 VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Validate the Unified Survival calculator against BOTH golden datasets:
  - S1 xlsx (CPP/CHP): unified CJ/CK must equal Excel BR/BS.
  - S2 xlsb (other products): unified CJ/CK must equal Excel CJ/CK.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

UNI = Path(r"C:\Users\akshi\OneDrive\Desktop\Insurance\Manav\Survival-Unified-Calci-")
S1_REF = UNI / "Survival_Calc 1_CPP CHP_Mar Apr May_ Auto.xlsx"
S1_SHEET = "Calc 1 - CHP CPP "
S2_REF = UNI / "Survival Calc 2_Others_Mar_Apr May_Auto_1.xlsb"
S2_SHEET = "Calc 2_other Products"

sys.path.insert(0, str(UNI))
import calculator  # noqa: E402


def num(v):
    try:
        return float(v) if v is not None and v != "" else 0.0
    except (TypeError, ValueError):
        return None


def close(a, b, tol=0.5):
    na, nb = num(a), num(b)
    if na is None or nb is None:
        return str(a) == str(b)
    return abs(na - nb) <= tol


def run_block(name, df_full, gold_cj_idx, gold_ck_idx):
    golden_cj = df_full.iloc[:, gold_cj_idx].tolist()
    golden_ck = df_full.iloc[:, gold_ck_idx].tolist()
    cnttype = df_full.iloc[:, 24].tolist()
    status = df_full.iloc[:, 1].tolist()
    out = calculator.calculate_survival(df_full.iloc[:, :49].copy())
    py_cj = out.iloc[:, -2].tolist()
    py_ck = out.iloc[:, -1].tolist()

    fails = 0
    print(f"\n===== {name} =====")
    print(f"{'row':>3} {'Y':<5} {'St':<4} {'CJ gold':>13} {'CJ py':>13} {'CK gold':>13} {'CK py':>13}  res")
    for i in range(len(df_full)):
        ok = close(golden_cj[i], py_cj[i]) and close(golden_ck[i], py_ck[i])
        if not ok:
            fails += 1
        print(f"{i+3:>3} {str(cnttype[i]):<5} {str(status[i]):<4} "
              f"{num(golden_cj[i]):>13.2f} {num(py_cj[i]):>13.2f} "
              f"{num(golden_ck[i]):>13.2f} {num(py_ck[i]):>13.2f}  {'OK' if ok else 'FAIL'}")
    print(f"{len(df_full)-fails}/{len(df_full)} rows match")
    return fails


def main() -> int:
    total = 0
    # S1: golden BR=col70(idx69) BS=col71(idx70)
    s1 = pd.read_excel(S1_REF, sheet_name=S1_SHEET, header=1)
    s1 = s1[s1.iloc[:, 0].notna()]
    total += run_block("S1 (CPP/CHP) vs Excel BR/BS", s1, 69, 70)

    # S2: golden CJ=col88(idx87) CK=col89(idx88)
    s2 = pd.read_excel(S2_REF, sheet_name=S2_SHEET, header=1)
    total += run_block("S2 (others) vs Excel CJ/CK", s2, 87, 88)

    print(f"\n==== TOTAL MISMATCHES: {total} ====")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())

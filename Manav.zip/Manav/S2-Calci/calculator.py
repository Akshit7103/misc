import pandas as pd
import numpy as np
from datetime import datetime

# HARDCODED LOGIC & DATA
HEADERS = [
    "CONTRACT_NUMBER", "STATUS", "LE_LP_AMT", "LE_ME", "LE_RY", "LE_SI", "LE_IM", "LE_PA", "LE_BT", "LE_LY",
    "LE_FE", "LE_GM", "LN_LO_AMT", "LN_LA_AMT", "LN_LI_AMT", "LE_MC", "LP_S", "LP_MS", "ASGNNUM", "NATLTY",
    "ISSDATE", "FIRSTISSDT", "PREMIUM01", "SA", "CNTTYPE", "CATEGORY", "PROD_NAME", "RISK TERM", "PREM TERM",
    "FREQUENCY", "RCDDATE", "PAIDTODATE", "RISKCESDTE", "PREMCESDTE", "CLTDOB", "CLTDOD", "ZPANVAL", "ANP_PREMIUM",
    "STMPDTYAMT", "INSTPREM_GST", "INSTPREM_WITH_GST", "INSTPREM_WITHOUT_GST", "PLAN_COMPONENT", "COMPONENT_DESC",
    "ORIGINAL_SA", "ASSIGNEE FLAG", "LITIGATION FLAG", "CURRENT SA", "NEXT_PAYDATE", "", "Inforce/Paid up",
    "PPT * FREQ", "Prem Paid * FREQ", "(Updated SA)", "Current Year", "Date of Death\n(For Ref)",
    "For Current Month Accrued Loan Interest", "Updated LN_LA", "SB Due Check", "Death Status(Inforce or paid up death)",
    "Premium paid years", "Lapsed Death", "Death Status", "Money Back % (IMP/ MPI)", "Money Back % (CSR)",
    "Money Back % (MBG, MBN)", "Money Back Benefit %\nMSB / SMB", "RFI \nRV Bonus", "RFI\n(SA+RV bonus)",
    "RFI Income benefit %", "WLI\nGuaranteed Income\n% of BSA (A)", "WLI Guaranteed Income (B)", "WLI Cash Bonus \n",
    "Total SB in WLI", "MBP", "SEP", "RFP", "IMP /MPI", "CSR", "MBG", "MBN", "MSB / SMB", "WLI", "RFI", "MBP",
    "SEP", "RFP", "SB Amount", "Final SB Amount - Loan Adj"
]

RATE_CHARTS = {
    "imp_mpi": {3: 0.1, 6: 0.2, 9: 0.3, 12: 0.5},
    "mbg_mbn": {
        "15-11": 0.15, "15-12": 0.15, "15-13": 0.15, "15-14": 0.15, "15-15": 0.4,
        "20-16": 0.15, "20-17": 0.15, "20-18": 0.15, "20-19": 0.15, "20-20": 0.4
    },
    "csr": {4: 0.1, 7: 0.15, 10: 0.2, 13: 0.25, 16: 0.3, 19: 0.35},
    "rfi": {
        14: {"start": 8, "pct": 0.142857},
        16: {"start": 9, "pct": 0.125},
        18: {"start": 10, "pct": 0.111111},
        20: {"start": 11, "pct": 0.1},
        22: {"start": 12, "pct": 0.090909},
        24: {"start": 13, "pct": 0.083333}
    },
    "wli": [
        {"low": 0.0, "high": 249999.0, "pct": 0.06},
        {"low": 250000.0, "high": 499999.0, "pct": 0.065},
        {"low": 500000.0, "high": 999999999.0, "pct": 0.0675}
    ]
}

RFI_BONUS = {
    "test52632450": 153164.27999999997,
    "test52960306": 68800.0
}

# Constants from Excel
BE1_VAL = pd.to_datetime("2026-03-31")
BF1_VAL = 0.0825

def to_num(val):
    v = pd.to_numeric(val, errors='coerce')
    return v if pd.notna(v) else 0


def read_calc_sheet(path):
    """Read the calculation sheet from an uploaded workbook.

    The reference .xlsb has several sheets ('Notes', 'Calc 2_other Products',
    'Rate Chart', ...) and the data is NOT on the first sheet, so a plain
    pd.read_excel(path, header=1) would silently read 'Notes' and produce
    garbage. Pick the sheet whose row-2 header begins with CONTRACT_NUMBER
    (the canonical first input column); fall back to the first sheet.
    """
    xls = pd.ExcelFile(path)
    for sheet in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet, header=1)
        if len(df.columns) and str(df.columns[0]).strip().upper() == "CONTRACT_NUMBER":
            return df
    return pd.read_excel(xls, sheet_name=0, header=1)

def calculate_survival(df):
    """
    Performs the calculations equivalent to columns AY to CK of the Excel sheet.
    Input df should have columns A to AW (index 0 to 48).
    """
    
    # Map input columns to A-AW letters for consistent logic
    letter_cols = []
    for i in range(89): # A to CK
        if i < 26: letter_cols.append(chr(65 + i))
        else: letter_cols.append(chr(65 + (i // 26) - 1) + chr(65 + (i % 26)))
    
    # Store original column names for mapping back
    original_input_cols = df.columns.tolist()
    
    # We expect 49 columns (A to AW)
    # If the user provides an excel with named headers, we should try to match them or just use position
    # The requirement says input is A-AW.
    
    # Create a copy to not modify original
    calc_df = df.copy()
    
    # Ensure we have at least 49 columns
    for i in range(len(calc_df.columns), 49):
        calc_df[f"COL_{i}"] = np.nan
            
    # Rename columns to A, B, C... AW for the internal logic
    calc_df.columns = letter_cols[:len(calc_df.columns)]
    
    # Helper for dates. Robustly handles BOTH Excel serial numbers (which is
    # what pd.read_excel returns for .xlsb date cells, e.g. 46130) AND already
    # parsed datetimes / date strings. Without this, serial integers get
    # misread by pd.to_datetime as nanoseconds (year 1970) and every
    # date-dependent calculation (Current Year, accrued interest, rate-chart
    # lookups) silently collapses to zero.
    def to_dt(col):
        s = calc_df[col]
        numeric_s = pd.to_numeric(s, errors='coerce')
        dt_num = pd.to_datetime(numeric_s, unit='D', origin='1899-12-30', errors='coerce')
        dt_str = pd.to_datetime(s, errors='coerce')
        return dt_num.fillna(dt_str)

    # Pre-convert every date column ONCE so the row-wise helpers below always
    # see real datetimes regardless of how the upload delivered them.
    for _dcol in ['AE', 'AF', 'AJ', 'AW']:
        if _dcol in calc_df.columns:
            calc_df[_dcol] = to_dt(_dcol)

    # AY: Inforce/Paid up
    calc_df['AY'] = calc_df['B']
    
    # AZ: PPT * FREQ
    calc_df['AZ'] = pd.to_numeric(calc_df['AC'], errors='coerce') * pd.to_numeric(calc_df['AD'], errors='coerce')
    
    # BA: Prem Paid * FREQ
    days_diff = (to_dt('AF') - to_dt('AE')).dt.days
    calc_df['BA'] = np.round(days_diff / 365 * pd.to_numeric(calc_df['AD'], errors='coerce'), 0)
    
    # BD: Date of Death
    calc_df['BD'] = to_dt('AJ')
    
    # BH: Death Status(Inforce or paid up death)
    def calc_bh(row):
        if str(row['B']).upper() != 'DH': return 'NA'
        af = pd.to_datetime(row['AF'], errors='coerce')
        bd = pd.to_datetime(row['BD'], errors='coerce')
        if pd.isna(af) or pd.isna(bd): return 'NA'
        gp = 30 if row['AD'] != 12 else 15
        if (af + pd.Timedelta(days=gp)) >= bd: return 'Inforce Death'
        return 'Paidup Death'
    calc_df['BH'] = calc_df.apply(calc_bh, axis=1)

    # BB: (Updated SA)
    def calc_bb(row):
        ay = str(row['AY']).upper()
        as_val = to_num(row['AS'])
        ba_val = to_num(row['BA'])
        az_val = to_num(row['AZ'])
        if ay == 'IF': return as_val
        if ay == 'PU': return as_val * ba_val / az_val if az_val else 0
        if ay == 'DH':
            if row['BH'] == 'Inforce Death': return as_val
            return as_val * ba_val / az_val if az_val else 0
        return 0
    calc_df['BB'] = calc_df.apply(calc_bb, axis=1)

    # BC: Current Year
    def datedif_y(start, end):
        if pd.isna(start) or pd.isna(end): return 0
        try:
            return end.year - start.year - ((end.month, end.day) < (start.month, start.day))
        except: return 0
    calc_df['BC'] = calc_df.apply(lambda r: datedif_y(pd.to_datetime(r['AE'], errors='coerce'), pd.to_datetime(r['AW'], errors='coerce')), axis=1)

    # BE: Accrued Loan Interest
    def calc_be(row):
        aw = pd.to_datetime(row['AW'], errors='coerce')
        if pd.isna(aw) or aw <= BE1_VAL: return 0
        m = to_num(row['M'])
        n = to_num(row['N'])
        days = (aw - BE1_VAL).days
        return (m + n) * ((1 + BF1_VAL)**(days / 365) - 1)
    calc_df['BE'] = calc_df.apply(calc_be, axis=1)

    # BF: Updated LN_LA
    calc_df['BF'] = pd.to_numeric(calc_df['N'], errors='coerce').fillna(0) + calc_df['BE']

    # BG: SB Due Check
    calc_df['BG'] = calc_df['AY'].apply(lambda x: "SB eligible" if str(x).upper() in ["PU", "IF", "DH"] else "SB Not Eligible")

    # BI: Premium paid years
    calc_df['BI'] = calc_df.apply(lambda r: datedif_y(pd.to_datetime(r['AE'], errors='coerce'), pd.to_datetime(r['AF'], errors='coerce')), axis=1)

    # BK: Death Status (Complex)
    def calc_bk(row):
        if str(row['B']).upper() != 'DH': return 'NA'
        af = pd.to_datetime(row['AF'], errors='coerce')
        aj = pd.to_datetime(row['AJ'], errors='coerce')
        gp = 30 if row['AD'] != 12 else 15
        bi = row['BI']
        y = str(row['Y']).upper()
        if (af + pd.Timedelta(days=gp)) < aj:
            lapsed = False
            if y == 'MBG' and bi < 1: lapsed = True
            elif y == 'MSB' and bi < 2: lapsed = True
            elif y not in ['MBG', 'MSB'] and bi < 3: lapsed = True
            return 'Lapsed Death' if lapsed else 'Paidup Death'
        return 'Inforce Death' if (af + pd.Timedelta(days=gp)) >= aj else 'Paidup Death'
    calc_df['BK'] = calc_df.apply(calc_bk, axis=1)

    # VLOOKUP Logic
    calc_df['BL'] = calc_df.apply(lambda r: RATE_CHARTS['imp_mpi'].get(int(r['BC']), 0) if str(r['AY']).upper() == 'IF' and str(r['Y']).upper() in ['IMP', 'MPI'] else 0, axis=1)
    calc_df['BM'] = calc_df.apply(lambda r: RATE_CHARTS['csr'].get(int(r['BC']), 0) if str(r['AY']).upper() == 'IF' and str(r['Y']).upper() == 'CSR' else 0, axis=1)
    
    def calc_bn(row):
        if str(row['Y']).upper() in ['MBG', 'MBN']:
            try:
                key = f"{int(to_num(row['AB']))}-{int(to_num(row['BC']))}"
                return RATE_CHARTS['mbg_mbn'].get(key, 0)
            except: return 0
        return 0
    calc_df['BN'] = calc_df.apply(calc_bn, axis=1)

    calc_df['BO'] = calc_df.apply(lambda r: (500/r['AB'])/100 if str(r['Y']).upper() in ['MSB', 'SMB'] and str(r['AY']).upper() in ['IF', 'PU'] and r['BC'] <= r['AB'] and r['BC'] % 5 == 0 and r['AB'] else 0, axis=1)
    calc_df['BP'] = calc_df['A'].apply(lambda x: RFI_BONUS.get(str(x), 0))
    calc_df['BQ'] = calc_df.apply(lambda r: r['BB'] + r['BP'] if str(r['Y']).upper() == 'RFI' else 0, axis=1)
    
    def calc_br(row):
        if str(row['Y']).upper() == 'RFI':
            cfg = RATE_CHARTS['rfi'].get(int(to_num(row['AB'])))
            if cfg and row['BC'] >= cfg['start'] and row['BC'] <= row['AB']: return cfg['pct']
        return 0
    calc_df['BR'] = calc_df.apply(calc_br, axis=1)

    def calc_bs(row):
        if str(row['Y']).upper() == 'WLI' and str(row['AY']).upper() in ['IF', 'PU']:
            bb = row['BB']
            for tier in RATE_CHARTS['wli']:
                if bb >= tier['low'] and bb <= tier['high']: return tier['pct']
        return 0
    calc_df['BS'] = calc_df.apply(calc_bs, axis=1)

    calc_df['BT'] = calc_df['BB'] * calc_df['BS']
    calc_df['BU'] = calc_df.apply(lambda r: r['BB'] * 0.058 if str(r['Y']).upper() == 'WLI' and str(r['AY']).upper() == 'IF' else 0, axis=1)
    calc_df['BV'] = np.round(calc_df['BT'] + calc_df['BU'], 0)
    calc_df['BW'] = calc_df.apply(lambda r: r['BB'] / ((r['AB'] - 1) / 3) if str(r['Y']).upper() == 'MBP' and str(r['AY']).upper() == 'IF' and r['AB'] > 1 else 0, axis=1)

    # Product specifics
    calc_df['BZ'] = calc_df.apply(lambda r: r['BB'] * r['BL'] if str(r['AY']).upper() == 'IF' else 0, axis=1)
    calc_df['CA'] = calc_df.apply(lambda r: r['BB'] * r['BM'] if (str(r['Y']).upper() == 'CSR' or r['BG'] == 'SB eligible') else 0, axis=1)
    calc_df['CB'] = calc_df.apply(lambda r: r['BB'] * r['BN'] if (str(r['Y']).upper() == 'MBG' or r['BG'] == 'SB eligible') else 0, axis=1)
    calc_df['CC'] = calc_df.apply(lambda r: r['BB'] * r['BN'] if (str(r['Y']).upper() == 'MBN' or r['BG'] == 'SB eligible') else 0, axis=1)
    calc_df['CD'] = calc_df.apply(lambda r: r['BB'] * r['BO'] if str(r['Y']).upper() in ['MSB', 'SMB'] else 0, axis=1)
    calc_df['CE'] = calc_df.apply(lambda r: r['BV'] if str(r['Y']).upper() == 'WLI' else 0, axis=1)
    calc_df['CF'] = calc_df.apply(lambda r: r['BQ'] * r['BR'] if str(r['AY']).upper() in ['IF', 'PU'] else 0, axis=1)
    calc_df['CG'] = calc_df.apply(lambda r: r['BW'] if str(r['Y']).upper() == 'MBP' else 0, axis=1)
    calc_df['CH'] = calc_df.apply(lambda r: r['AS'] if str(r['Y']).upper() == 'SEP' and r['BC'] == r['AC'] else 0, axis=1)
    calc_df['CI'] = calc_df.apply(lambda r: r['AS'] if str(r['Y']).upper() == 'RFP' and r['BC'] == r['AC'] else 0, axis=1)

    # CJ: SB Amount
    def calc_cj(row):
        y = str(row['Y']).upper()
        if y in ['IMP', 'MPI']: return row['BZ']
        if y == 'CSR': return row['CA']
        if y == 'MBG': return row['CB']
        if y == 'MBN': return row['CC']
        if y == 'RFI': return row['CF']
        if y in ['MSB', 'SMB']: return row['CD']
        if y == 'WLI': return row['CE']
        if y == 'MBP': return row['CG']
        if y == 'SEP': return row['CH']
        if y == 'RFP': return row['CI']
        return 0
    calc_df['CJ'] = calc_df.apply(calc_cj, axis=1)

    # CK: Final SB Amount
    def calc_ck(row):
        if str(row['BK']).upper() == 'Lapsed Death': return 0
        
        # Strictly following Excel: =IF(BK4="Lapsed Death",0,(MAX(0,CJ4-SUM(M4+BF4))))
        # Note: In Excel, if M4 and BF4 are negative, M4+BF4 is negative.
        # CJ4 - (Negative Value) = CJ4 + Positive Value.
        m = to_num(row['M'])
        bf = to_num(row['BF'])
        cj = to_num(row['CJ'])
        
        # Excel's SUM(M4+BF4) is just M4 + BF4
        adjustment = m + bf
        return max(0, cj - adjustment)
    calc_df['CK'] = calc_df.apply(calc_ck, axis=1)

    # Selection
    cols_to_keep = letter_cols[:49] + ['CJ', 'CK']
    result_df = calc_df[cols_to_keep]
    
    # Map back headers
    final_headers = []
    for i in range(49): final_headers.append(HEADERS[i])
    final_headers.append(HEADERS[87]) # CJ: SB Amount
    final_headers.append(HEADERS[88]) # CK: Final SB Amount - Loan Adj
    result_df.columns = final_headers

    return result_df

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows

# Helper to convert Excel color (int) to HEX
def excel_color_to_hex(excel_color):
    if excel_color is None or pd.isna(excel_color):
        return "FFFFFF"
    # Excel stores color as 0xBBGGRR
    # We want RRGGBB
    color_int = int(excel_color)
    b = (color_int >> 16) & 0xFF
    g = (color_int >> 8) & 0xFF
    r = color_int & 0xFF
    return f"{r:02X}{g:02X}{b:02X}"

# EXTRACTED STYLE DATA (From Row 2 of original)
# col_idx: (fill_hex, bold)
STYLE_MAP = {
    1: ("FFFFFF", False), 2: ("FFFFFF", False), 3: ("FFFFFF", False), 4: ("FFFFFF", False),
    5: ("FFFFFF", False), 6: ("FFFFFF", False), 7: ("FFFFFF", False), 8: ("FFFFFF", False),
    9: ("FFFFFF", False), 10: ("FFFFFF", False), 11: ("FFFFFF", False), 12: ("FFFFFF", False),
    13: ("FFFFFF", False), 14: ("FFFFFF", False), 15: ("FFFFFF", False), 16: ("FFFFFF", False),
    17: ("FFFFFF", False), 18: ("FFFFFF", False), 19: ("FFFFFF", False), 20: ("FFFFFF", False),
    21: ("FFFFFF", False), 22: ("FFFFFF", False), 23: ("FFFFFF", False), 24: ("FFFFFF", False),
    25: ("D5E2FB", False), 26: ("FFFFFF", False), 27: ("FFFFFF", False), 28: ("FFFFFF", False),
    29: ("FFFFFF", False), 30: ("FFFFFF", False), 31: ("FFFFFF", False), 32: ("FFFFFF", False),
    33: ("FFFFFF", False), 34: ("FFFFFF", False), 35: ("FFFFFF", False), 36: ("FFFFFF", False),
    37: ("FFFFFF", False), 38: ("FFFFFF", False), 39: ("FFFFFF", False), 40: ("FFFFFF", False),
    41: ("FFFFFF", False), 42: ("FFFFFF", False), 43: ("FFFFFF", False), 44: ("FFFFFF", False),
    45: ("FFFFFF", False), 46: ("FFFFFF", False), 47: ("FFFFFF", False), 48: ("FFFFFF", False),
    49: ("FFFFFF", False), 50: ("FFFFFF", False),
    # Calculations
    51: ("D5E2FB", True), 52: ("D5E2FB", True), 53: ("D5E2FB", True), 54: ("D5E2FB", True),
    55: ("D5E2FB", True), 56: ("D5E2FB", True), 57: ("D5E2FB", True), 58: ("FFFF00", True),
    59: ("D5E2FB", True), 60: ("D5E2FB", True), 61: ("F8F1DA", True), 62: ("F8F1DA", True),
    63: ("F8F1DA", True), 64: ("D5E2FB", True), 65: ("D5E2FB", True), 66: ("D5E2FB", True),
    67: ("D5E2FB", True), 68: ("D5E2FB", True), 69: ("D5E2FB", True), 70: ("D5E2FB", True),
    71: ("D5E2FB", True), 72: ("D5E2FB", True), 73: ("D5E2FB", True), 74: ("D5E2FB", True),
    75: ("D5E2FB", True), 76: ("D5E2FB", True), 77: ("D5E2FB", True),
    # Output Highlights (Yellow/Orange)
    78: ("FFA500", True), 79: ("FFA500", True), 80: ("FFA500", True), 81: ("FFA500", True),
    82: ("FFA500", True), 83: ("FFA500", True), 84: ("FFA500", True), 85: ("FFA500", True),
    86: ("FFA500", True), 87: ("FFA500", True), 88: ("FFA500", True), 89: ("D5E2FB", True)
}

def write_formatted_excel(df, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Calculated Output"
    
    # ROW 1: Empty (as per original reference structure)
    ws.append([])
    
    # ROW 2: Headers
    headers = df.columns.tolist()
    ws.append(headers)
    
    # ROW 3+: Data (index=False ensures headers are not repeated)
    for r in dataframe_to_rows(df, index=False, header=False):
        ws.append(r)
        
    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    
    # Map header indices (DF headers are A-AW then CJ, CK)
    # Col index 1 to 49 is A to AW.
    # Col index 50 is CJ (88th in original).
    # Col index 51 is CK (89th in original).
    
    for col_idx in range(1, len(headers) + 1):
        # Determine actual original column index for style
        original_idx = col_idx
        if col_idx == 50: original_idx = 88 # SB Amount (CJ)
        if col_idx == 51: original_idx = 89 # Final SB Amount (CK)
        
        style = STYLE_MAP.get(original_idx, ("FFFFFF", False))
        fill_hex, is_bold = style
        
        cell = ws.cell(row=2, column=col_idx)
        cell.fill = PatternFill(start_color=fill_hex, end_color=fill_hex, fill_type="solid")
        cell.font = Font(bold=is_bold)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
        
        ws.column_dimensions[cell.column_letter].width = 18

    # Format Data Cells
    for r_idx in range(3, ws.max_row + 1):
        for c_idx in range(1, ws.max_column + 1):
            cell = ws.cell(row=r_idx, column=c_idx)
            cell.border = thin_border
            # Numeric formatting for currency columns (C, E, M, N, O, X, AL, AS, CJ, CK)
            if c_idx in [3, 5, 13, 14, 15, 24, 38, 45, 48, 50, 51]:
                cell.number_format = '#,##0.00'

    wb.save(output_path)
    return output_path

# Survival Calculator 2

A Flask-based web application for calculating survival benefits from insurance policy data provided in Excel format. This tool automates complex insurance calculations previously performed manually in Excel.

## Features

- **Automated Calculations**: Processes input Excel files (Columns A-AW) and generates survival benefit amounts.
- **Support for Multiple Products**: Handles logic for IMP, MPI, CSR, MBG, MBN, MSB, SMB, RFI, WLI, MBP, SEP, and RFP products.
- **Loan Adjustment**: Automatically calculates accrued loan interest and adjusts final survival benefit amounts.
- **Formatted Output**: Generates a professionally formatted Excel file with consistent styling, borders, and color-coded headers matching corporate standards.

## Deployment on Render

This project is configured for deployment on [Render](https://render.com/).

### Steps to Deploy:

1. **Create a New Web Service**: Connect your GitHub/GitLab repository to Render.
2. **Environment**: Select `Python`.
3. **Build Command**: 
   ```bash
   pip install -r requirements.txt
   ```
4. **Start Command**: 
   ```bash
   gunicorn app:app
   ```

## Local Development

1. **Clone the repository**:
   ```bash
   git clone <your-repo-url>
   cd survival-2-calci
   ```

2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**:
   ```bash
   python app.py
   ```
   The app will be available at `http://127.0.0.1:5000`.

## Input File Format

The application expects an Excel file where:
- **Headers** are on Row 2.
- **Data** starts from Row 3.
- **Columns A to AW** contain the required policy and loan information.

## License

Internal Use Only.

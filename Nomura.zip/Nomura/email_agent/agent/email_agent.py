"""Email Agent Runner (Phase 1) — plain Python SPAR loop.

Sense  : read emails from the inbox connector
Plan   : iterate, skip already-processed
Act    : classify -> (relevant) store case + manifest
Reflect: log a run summary
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

from classifier.rule_classifier import Classification, RuleClassifier
from config.settings import EmailAgentConfig
from connectors.local_connector import LocalEmailConnector
from storage.db_index import DBIndex
from storage.file_store import FileStore
from utils.logger import get_logger

logger = get_logger("email_agent")


@dataclass
class RunStats:
    read: int = 0
    relevant: int = 0
    ambiguous: int = 0
    irrelevant: int = 0
    duplicate: int = 0
    already_processed: int = 0
    ambiguous_subjects: List[str] = field(default_factory=list)


class EmailAgentRunner:
    def __init__(self, config: EmailAgentConfig, connector: LocalEmailConnector,
                 classifier: RuleClassifier, store: FileStore, db: DBIndex):
        self.cfg = config
        self.connector = connector
        self.classifier = classifier
        self.store = store
        self.db = db

    def run(self) -> RunStats:
        stats = RunStats()

        # -- SENSE --
        emails = self.connector.fetch_emails()
        stats.read = len(emails)

        # -- PLAN + ACT --
        for mail in emails:
            mid = mail["message_id"]
            if self.db.message_id_exists(mid):
                stats.already_processed += 1
                logger.debug("Already processed, skipping: %s", mid)
                continue

            result = self.classifier.classify(mail["subject"], mail["body"])

            if result.label == "IRRELEVANT":
                stats.irrelevant += 1
                logger.debug("IRRELEVANT | %s | %s", mail["subject"], result.reason)
                continue

            if result.label == "AMBIGUOUS":
                stats.ambiguous += 1
                stats.ambiguous_subjects.append(mail["subject"])
                logger.warning("AMBIGUOUS (%.2f) | %s | %s",
                               result.confidence, mail["subject"], result.reason)
                continue

            # RELEVANT
            trade_id = result.trade_id or f"UNKNOWN_{mid.strip('<>')[:8]}"
            if not trade_id.startswith("UNKNOWN") and self.db.trade_id_exists(trade_id):
                stats.duplicate += 1
                logger.warning("DUPLICATE trade_id %s — skipping (%s)", trade_id, mail["subject"])
                continue

            self._store_case(mail, result, trade_id)
            stats.relevant += 1
            logger.info("RELEVANT (%.2f) | %s | trade_id=%s",
                        result.confidence, mail["subject"], trade_id)

        # -- REFLECT --
        self._log_summary(stats)
        return stats

    def _store_case(self, mail: Dict, result: Classification, trade_id: str) -> None:
        case_dir = self.store.create_case_folder(trade_id, result.asset_class)
        self.store.save_email_body(case_dir, mail["body"])
        self.store.save_metadata(case_dir, {
            "message_id": mail["message_id"],
            "subject": mail["subject"],
            "sender": mail["sender"],
            "received_at": mail["received_at"],
            "source_file": mail["source_file"],
            "classification": result.__dict__,
        })

        attachments_meta = []
        for att in mail.get("attachments", []):
            saved = self.store.save_attachment(case_dir, att["filename"], att["data"])
            attachments_meta.append({
                "filename": att["filename"],
                "path": str(saved),
                "mime_type": att.get("mime_type", ""),
                "size_bytes": len(att.get("data", b"")),
            })

        manifest = {
            "trade_id": trade_id,
            "asset_class": result.asset_class,
            "message_id": mail["message_id"],
            "subject": mail["subject"],
            "sender": mail["sender"],
            "received_at": mail["received_at"],
            "case_folder": str(case_dir),
            "email_body_path": str(case_dir / "email_body.txt"),
            "attachments": attachments_meta,
            "classification": {
                "label": result.label,
                "confidence": result.confidence,
                "reason": result.reason,
                "asset_class": result.asset_class,
            },
            "ready_for_extraction": True,
        }
        self.store.save_manifest(case_dir, manifest)

        self.db.insert_case({
            "message_id": mail["message_id"],
            "trade_id": trade_id,
            "asset_class": result.asset_class,
            "subject": mail["subject"],
            "sender": mail["sender"],
            "received_at": mail["received_at"],
            "classification_label": result.label,
            "classification_confidence": result.confidence,
            "case_folder": str(case_dir),
            "attachment_count": len(attachments_meta),
        })

    def _log_summary(self, stats: RunStats) -> None:
        logger.info("=" * 56)
        logger.info("[Phase 1 Run Complete]")
        logger.info("  Emails read:          %d", stats.read)
        logger.info("  RELEVANT (stored):    %d", stats.relevant)
        logger.info("  AMBIGUOUS (skipped):  %d", stats.ambiguous)
        logger.info("  IRRELEVANT (skipped): %d", stats.irrelevant)
        logger.info("  DUPLICATE (skipped):  %d", stats.duplicate)
        logger.info("  Already processed:    %d", stats.already_processed)
        if stats.ambiguous_subjects:
            logger.info("  --- Ambiguous emails for manual review ---")
            for subj in stats.ambiguous_subjects:
                logger.info("    • %s", subj)
        logger.info("=" * 56)

"""Central configuration for the Email Agent (Phase 1)."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class EmailAgentConfig:
    # -- Paths (relative to the email_agent/ project root) --
    inbox_path: str = "data/raw_emails/inbox"
    processed_path: str = "data/processed"
    db_path: str = "data/email_index.db"
    log_dir: str = "logs"

    # -- Strong asset-level signals (any hit => +asset_weight) --
    # These phrases are specific to FX trade settlement notifications and do
    # NOT appear in generic "settlement query" / noise emails.
    asset_keywords: List[str] = field(default_factory=lambda: [
        "fx trade settlement",
        "fx settlement",
        "settlement instructions",
        "deal reference",
        "fx trade",
        "currency pair",
    ])

    # -- Subject-level signals (any hit in SUBJECT => +subject_weight) --
    subject_keywords: List[str] = field(default_factory=lambda: [
        "settlement",
        "confirm",
        "trade",
        "swift",
        "counterparty",
        "value date",
        "transaction",
        "allege",
        "dk",
        "fx",
    ])

    # -- Hard-negative signals. If any present AND no asset keyword => skip. --
    negative_keywords: List[str] = field(default_factory=lambda: [
        "happy birthday", "birthday", "anniversary", "congratulations", "congrats",
        "it support", "ticket", "password", "vpn",
        "policy", "remote work", "newsletter", "monthly update",
        "out of office", "team sync", "lunch", "calendar invite",
    ])

    # -- Trade ID regex patterns (tried in order). Primary = real FXOPT format. --
    trade_id_patterns: List[str] = field(default_factory=lambda: [
        r"FXOPT-\d{4}-\d{5}",            # FXOPT-2026-00046 (ground truth)
        r"[A-Z]{2,5}-\d{4}-\d{4,6}",     # generic dealref fallback
        r"\b[A-Z]{2,4}\d{6,12}\b",       # e.g. FX123456
    ])

    # -- Scoring weights --
    asset_weight: float = 0.5
    subject_weight: float = 0.3
    trade_id_weight: float = 0.2

    # -- Thresholds --
    relevant_threshold: float = 0.7     # score >= => RELEVANT
    ambiguous_threshold: float = 0.3    # score in [this, relevant) => AMBIGUOUS

    # -- Body chars scanned for trade ID extraction --
    max_body_scan_chars: int = 2000

    # -- Default asset class label for relevant emails --
    default_asset_class: str = "FX Settlement"

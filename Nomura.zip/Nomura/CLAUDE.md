# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Phase 1 "Email Agent" of the Nomura SSG Agentic AI POC. It triages a noisy shared mailbox of `.eml` files, keeps the FX-settlement trade emails, discards office noise, deduplicates by trade ID, and writes one structured case folder + `manifest.json` per trade as the handoff to a (future) Phase 2 extraction agent.

The runnable code lives entirely in the `email_agent/` subdirectory. The workspace root holds planning/presentation docs and source material (`.docx`, `.pdf`, sample `.eml` files in `snapshots/`).

## Running

**All commands must be run from inside `email_agent/`.** Imports are absolute against that directory (e.g. `from agent.email_agent import ...`) and `demo.py` shells out to `tools/...` with a relative path, so the CWD must be `email_agent/`.

```powershell
cd email_agent
python demo.py                              # full self-contained demo: regenerates inbox, runs agent, proves dedup on a 2nd run
python main.py                              # single agent run against the current inbox (no reset)
python tools/generate_test_emails.py --clean    # wipe + regenerate the synthetic inbox
python tools/generate_test_emails.py --seed 42 --complete 8 --partial 4 --duplicates 2
```

No dependencies to install — the implementation is **pure Python standard library** (developed on CPython 3.13; targets 3.11+). There is no `requirements.txt`, no `.env`, and no virtualenv needed. `python demo.py` is the canonical "does everything still work" check; there is no `pytest` suite despite what the plan doc describes.

## Architecture

The agent is a plain `EmailAgentRunner` (`agent/email_agent.py`) implementing a **SPAR loop** (Sense → Plan → Act → Reflect) over a flat list of emails — deliberately no orchestration framework. Components are constructor-injected so each is independently testable:

```
LocalEmailConnector → RuleClassifier → (FileStore + DBIndex)
   parse .eml          score/label        write case + index
```

- **`connectors/local_connector.py`** — reads every `*.eml` from the inbox into a uniform dict (`message_id`, `subject`, `sender`, `received_at`, `body`, `html_body`, `attachments`, `source_file`). Decodes MIME-encoded headers; never raises on a bad file (logs + skips). This is the **only** component that changes when swapping to a live Outlook/MS Graph mailbox.
- **`classifier/rule_classifier.py`** — deterministic keyword/regex scoring, no LLM. Returns a `Classification` dataclass.
- **`storage/file_store.py`** — writes per-case artifacts to disk under `data/processed/`.
- **`storage/db_index.py`** — SQLite (`data/email_index.db`) for dedup + case tracking.
- **`config/settings.py`** — single `EmailAgentConfig` dataclass holding *all* tunables (keyword lists, regex patterns, weights, thresholds, paths). Change behavior here, not in module internals.

### Classification scoring (the core logic)

Score additively, then threshold. Note the deliberate asymmetry in where each list is matched:

- **asset_keywords** matched against **subject + body** → `+asset_weight` (0.5). These are intentionally *specific* phrases ("settlement instructions", "deal reference") so generic noise can't cross the line.
- **subject_keywords** matched against **subject only** → `+subject_weight` (0.3).
- **trade-ID regex** match anywhere → `+trade_id_weight` (0.2).

Routing: `score ≥ 0.7` → **RELEVANT**, `0.3 ≤ score < 0.7` → **AMBIGUOUS** (skipped but logged for human review, never silently dropped), `< 0.3` → **IRRELEVANT**. A **hard-negative early exit** fires first: if any `negative_keyword` is present AND no asset keyword is, it returns IRRELEVANT immediately.

Trade-ID extraction tries patterns in order; the primary/ground-truth format is `FXOPT-2026-00047` (`FXOPT-\d{4}-\d{5}`).

### Storage & dedup contract

Each RELEVANT email produces `data/processed/{trade_id}_{asset_class}_{YYYYMMDD}/` containing `email_body.txt`, `email_metadata.json`, `manifest.json`, and an `attachments/` folder. The folder date is the **processing date**, not the email date. Emails with no extractable trade ID get an `UNKNOWN_<message-id-prefix>` id and are **not** deduplicated.

`manifest.json` is the Phase 2 contract — `ready_for_extraction: true` plus trade_id, paths, attachments, and the classification block.

Two SQLite guards make every run idempotent: `message_id_exists` (skip already-processed email) and `trade_id_exists` (skip a different email for an already-captured trade). `insert_case` uses `INSERT OR IGNORE`.

## Synthetic test data

`tools/generate_test_emails.py` is the data source: it builds `.eml` files (stdlib `email.message` only) that mirror the 3 real samples in `../snapshots/`. It emits a deterministic mix (seeded) of complete/partial RELEVANT trades, AMBIGUOUS settlement-adjacent emails, IRRELEVANT office noise, and DUPLICATE trade-IDs. When changing classifier keywords or thresholds, regenerate the inbox and re-run `demo.py` to confirm the expected split still holds (currently 12 relevant / 3 ambiguous / 10 irrelevant / 2 duplicate).

## Important: plan doc vs. reality

`Phase1_Email_Agent.md` (workspace root) is an **aspirational design spec** and describes things that are *not yet built*: an `extractor/attachment_extractor.py` with `pdfplumber`/`openpyxl`/`python-docx`/`pytesseract`, a `tests/` suite, `structlog`-based JSON logging, and a `requirements.txt`. The current code instead **saves attachment bytes raw without parsing them**, uses **stdlib `logging`** (`utils/logger.py`, which reconfigures stdout/stderr to UTF-8 to avoid Windows cp1252 crashes), and has no test suite. Treat the plan as roadmap, not as a description of current behavior — verify against the code.

---
marp: true
theme: default
paginate: true
title: Email Agent — Phase 1
---

# Email Agent — Phase 1
## Nomura SSG Agentic AI POC | FX & OTC Settlement

**Automating the first mile: from a noisy mailbox to clean, structured trade cases**

Prepared by: Protiviti AI Engineering Team

---

## The Problem Today

Nomura's Middle & Back Office teams manually process a high-volume shared mailbox:

- **300–400 emails per cycle · 4 cycles every 3 hours** (~1,200–1,600/day)
- FX Settlement Alleges, DK notices, and SSI verifications — **mixed in with office noise** (birthdays, IT tickets, OOO replies)

Analysts must, by hand:
1. Scan the inbox and spot the real trade emails
2. Open each one and read the trade details
3. Re-key data into downstream systems

> **Slow, repetitive, error-prone — and it scales linearly with headcount.**

---

## What Phase 1 Delivers

An **Email Agent** that automates the first mile:

| It does | It produces |
|---|---|
| Reads every incoming email | Uniform, parsed email records |
| Decides relevant vs. noise | RELEVANT / AMBIGUOUS / IRRELEVANT |
| Extracts the trade identifier | `FXOPT-2026-00047` |
| Prevents duplicate processing | One case per trade, guaranteed |
| Hands off clean cases | A `manifest.json` per trade for Phase 2 |

**Deterministic · Fully local · Zero LLM cost**

---

## How It Works — 5-Stage Pipeline

```
 .eml files        Connector        Classifier       Dedup          Store
  (inbox)    →     (parse)     →     (score)    →    (SQLite)   →   (disk)
                                                                       │
                                                                       ▼
                                                              manifest.json
                                                            (handoff to Phase 2)
```

An email enters one end. It either becomes a **structured case folder** or is **discarded** — and the decision is fully explainable.

---

## Stage 1 — Connector

Reads each `.eml` and normalizes it into one consistent shape.

- Parses headers, subject (decodes Outlook's encoded subjects), body, attachments
- Returns: `{ message_id, subject, sender, body, attachments, … }`

**Why it matters:** every email — synthetic today, live Outlook tomorrow — comes out in the *same* format. Switching to the MS Graph API later changes **only this one component**; the rest of the pipeline is untouched.

---

## Stage 2 — The Classifier (the brain)

A transparent **scoring system**. Three signals add up:

| Signal | Weight | Example |
|---|---|---|
| Asset keyword | **+0.5** | "fx trade settlement", "deal reference", "settlement instructions" |
| Subject keyword | **+0.3** | "settlement", "confirm", "trade", "fx" |
| Trade-ID match | **+0.2** | `FXOPT-2026-00047` |

**Decision thresholds:**
- **≥ 0.70 → RELEVANT**
- **0.30 – 0.69 → AMBIGUOUS** (flagged for human review)
- **< 0.30 → IRRELEVANT** (discarded)

---

## Stage 2 — Classifier in Action

**A real FX email** — hits all three signals → 0.5 + 0.3 + 0.2 = **0.95 → RELEVANT** ✅

**"Settlement query – account reconciliation"** — only the word *settlement* → **0.30 → AMBIGUOUS** ⚠️
*Smells settlement-ish but has no trade, no deal reference → a human should glance at it.*

**"Happy Birthday Akshit 🎂"** — hard-negative keyword, no FX signal → **IRRELEVANT** instantly ❌

> **Design key:** asset keywords are *specific* ("settlement **instructions**"), so generic words can't push noise over the line. That's what cleanly separates real trades from look-alikes.

---

## Stage 3 — Deduplication

A lightweight **SQLite index** tracks everything processed. Two guards:

- **Message-ID seen before?** → skip (don't reprocess the same email)
- **Trade-ID already captured?** → skip as DUPLICATE (different email, same trade)

> **Result:** the agent can run every 3-hour cycle safely — **nothing is ever processed twice.**

---

## Stages 4 & 5 — Store & Handoff

Each RELEVANT email becomes a **case folder**:

```
FXOPT-2026-00047_FX_Settlement_20260526/
├── email_body.txt          ← full raw text
├── email_metadata.json     ← sender, subject, classification
└── manifest.json           ← the Phase 2 contract
```

**The manifest** — clean, structured handoff:
```json
{
  "trade_id": "FXOPT-2026-00047",
  "asset_class": "FX Settlement",
  "classification": { "label": "RELEVANT", "confidence": 0.95 },
  "ready_for_extraction": true
}
```

---

## Live Demo Results

Run against **27 emails** that mirror the real format Nomura shared:

| Outcome | Count | Detail |
|---|---|---|
| ✅ **RELEVANT** (stored) | **12** | 8 complete + 4 partial trades |
| ⚠️ **AMBIGUOUS** (flagged) | **3** | Surfaced for manual review — never silently dropped |
| ❌ **IRRELEVANT** (discarded) | **10** | Birthday, IT, HR, OOO, lunch… |
| 🔁 **DUPLICATE** (skipped) | **2** | Caught by trade-ID dedup |

**100% correct classification. Second run: 0 reprocessed — dedup verified.**

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.11+ |
| Email parsing | `email` (stdlib) |
| Classification | `re` + keyword scoring (stdlib) |
| Storage / dedup | `sqlite3` (stdlib) |
| Test data | Synthetic email generator (stdlib) |

> **Runs on pure Python standard library — zero external dependencies, zero LLM cost today.**

---

## Honest Framing

- **Rule-based, not AI** — fast, deterministic, free, and fully explainable. An **LLM fallback** for the ambiguous bucket is a planned enhancement, not yet built.
- **Synthetic input** — generated to *exactly* match the real emails Nomura shared. The agent has been validated on that format.
- **Local mailbox today** — switching to the **live Outlook mailbox** (MS Graph API) is a **connector swap only**; the pipeline is unchanged.

---

## Roadmap

**Phase 1 remaining**
- Validate on the live email samples · test suite · attachment extractor

**Next phases**
- **Phase 2** — Extraction Agent (body/attachments → 6 trade fields → JSON)
- **Phase 3** — Compare & Match (golden source, confidence scoring)
- **Phase 4** — Human-in-the-Loop review UI
- **Phase 5–8** — Orchestration · Feedback loop · ServiceNow · Observability

---

## Summary

**Phase 1 turns a noisy shared mailbox into clean, deduplicated, structured trade cases — automatically.**

- ✅ Working end-to-end on realistic data
- ✅ Transparent, tunable, explainable decisions
- ✅ Zero cost, zero external dependencies
- ✅ Ready to hand off to Phase 2

> **The first mile of the settlement workflow is now automated.**

---

# Thank You

**Questions & live demo**

`python demo.py`

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\nfotc.spec.ts >> FT-C1-051 — Confirmation screen shows per-field value + AI confidence
- Location: tests\nfotc.spec.ts:95:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/Extracted fields/i)
Expected: visible
Error: strict mode violation: getByText(/Extracted fields/i) resolved to 2 elements:
    1) <div class="nom-card-h">…</div> aka getByText('Extracted fieldsHigh')
    2) <button title="" aria-hidden="true" ng-disabled="c.dirty" ng-click="c.confirm()" class="nom-btn ng-hide" ng-hide="c.data.readOnly">✓ Confirm Extracted fields</button> aka getByText('✓ Confirm Extracted fields')

Call log:
  - Expect "toBeVisible" with timeout 20000ms
  - waiting for getByText(/Extracted fields/i)

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - status
  - generic [ref=f1e4]:
    - banner:
      - link "Skip to page content" [ref=f1e5] [cursor=pointer]:
        - /url: javascript:void(0)
    - main [ref=f1e6]:
      - heading "OTC AI Extraction" [level=1] [ref=f1e7]
      - generic [ref=f1e16]:
        - generic [ref=f1e17]:
          - img "Nomura" [ref=f1e18]
          - button "Analyst US ▾" [ref=f1e20] [cursor=pointer]:
            - generic [ref=f1e21]: Analyst
            - generic [ref=f1e22]: US
            - generic [ref=f1e23]: ▾
        - generic [ref=f1e24]: 👁 Read-only — Manager view.
        - main [ref=f1e26]:
          - generic [ref=f1e27]:
            - heading "EML-0003" [level=1] [ref=f1e28]
            - link "Download" [ref=f1e29] [cursor=pointer]:
              - /url: /sys_attachment.do?sys_id=a871a979878b8310fb15653f8bbb359e
            - link "Audit trail" [ref=f1e30] [cursor=pointer]:
              - /url: /nfotc?id=nfotc_audit&cf=f181ad79878b8310fb15653f8bbb3577
            - link "← Dashboard" [ref=f1e31] [cursor=pointer]:
              - /url: /nfotc?id=nfotc_wiz_dash&wiz=6e29fe1887facf10fb15653f8bbb356e
          - generic [ref=f1e32]:
            - generic [ref=f1e33]: "1"
            - generic [ref=f1e36]:
              - generic [ref=f1e37]: Extracted from email
              - generic [ref=f1e38]:
                - generic [ref=f1e39]:
                  - generic [ref=f1e40]: Mail contents
                  - generic [ref=f1e41]:
                    - generic [ref=f1e42]:
                      - generic [ref=f1e43]: "To:"
                      - text: Settlements <bank@settlements.com>
                    - generic [ref=f1e44]:
                      - generic [ref=f1e45]: "From:"
                      - text: Counterparty5 Settlements <otc.settlements@oskira.cp5.example>
                    - generic [ref=f1e46]:
                      - generic [ref=f1e47]: "Subject:"
                      - text: Payment confirmation - 13-Jun-2026
                    - generic [ref=f1e48]:
                      - generic [ref=f1e49]: "Received:"
                      - text: 10-06-2026 16:01:13
                  - generic [ref=f1e50]:
                    - generic [ref=f1e51]: "This cashflow in the mail:"
                    - generic [ref=f1e52]: Value Date
                    - generic [ref=f1e54]: Amount
                    - generic [ref=f1e56]: Currency
                    - generic [ref=f1e58]: Direction
                  - generic [ref=f1e60]:
                    - text: Hi team, We'd like to confirm the payment(s) in the table below; please advise settlement. Reference | Product | Ccy | Amount | Direction | Value Date ----------+--------------------+-----+--------------+-----------+-----------
                    - generic [ref=f1e61]: 354550173 | Interest Rate Swap | EUR | 1,497,447.18 | Pay | 2026-06-13
                    - text: 349044605 | Equity-Linked Note | JPY | 1,811,339.36 | Pay | 2026-06-13 Regards
                - generic [ref=f1e62]:
                  - generic [ref=f1e63]:
                    - button "← Prev" [disabled] [ref=f1e64]
                    - generic [ref=f1e65]:
                      - text: Cashflow
                      - spinbutton [ref=f1e66]: "1"
                      - text: of 2
                    - button "Next →" [ref=f1e67] [cursor=pointer]
                  - generic [ref=f1e68]:
                    - generic [ref=f1e69]:
                      - text: Extracted fields
                      - generic "All four economic keys are grounded in the source and well-formed." [ref=f1e70]: High confidence
                      - generic [ref=f1e71]: ✓ Confirmed by analyst
                    - generic [ref=f1e73]:
                      - generic [ref=f1e74]:
                        - generic [ref=f1e75]: Counterparty Derived · EVE
                        - generic [ref=f1e76]: Counterparty5
                      - generic [ref=f1e77]:
                        - generic [ref=f1e78]: Value Date (YYYY-MM-DD) AIHigh
                        - generic [ref=f1e79]: 2026-06-13
                      - generic [ref=f1e80]:
                        - generic [ref=f1e81]: Amount AIHigh
                        - generic [ref=f1e82]: 1,497,447.18
                      - generic [ref=f1e83]:
                        - generic [ref=f1e84]: Currency AIHigh
                        - generic [ref=f1e85]: EUR
                      - generic [ref=f1e86]:
                        - generic [ref=f1e87]: Nomura Direction AIHigh
                        - generic [ref=f1e88]: Receive
                      - generic [ref=f1e89]:
                        - generic [ref=f1e90]: SSI Bank / BIC (O) AI
                        - generic [ref=f1e91]: —
                      - generic [ref=f1e92]:
                        - generic [ref=f1e93]: SSI Account (O) AI
                        - generic [ref=f1e94]: —
                      - generic [ref=f1e95]:
                        - generic [ref=f1e96]: SSI Beneficiary / BIC (O) AI
                        - generic [ref=f1e97]: —
          - generic [ref=f1e98]:
            - generic [ref=f1e99]: "2"
            - generic [ref=f1e102]:
              - generic [ref=f1e103]: Compare & Match
              - generic [ref=f1e104]:
                - generic [ref=f1e105]:
                  - generic [ref=f1e106]:
                    - generic [ref=f1e107]:
                      - generic [ref=f1e108]: 1 possible booking match found
                      - generic [ref=f1e109]: Tier 1 · exact
                    - generic [ref=f1e110]:
                      - text: Compare the rows below and
                      - strong [ref=f1e111]: select
                      - text: the booking that matches — or mark the cashflow as no match. Nothing is auto-selected; differing values are highlighted in red.
                  - table [ref=f1e113]:
                    - rowgroup [ref=f1e114]:
                      - row [ref=f1e115]:
                        - columnheader "Record" [ref=f1e116]
                        - columnheader "Counterparty" [ref=f1e117]
                        - columnheader "Currency" [ref=f1e118]
                        - columnheader "Amount" [ref=f1e119]
                        - columnheader "Direction" [ref=f1e120]
                        - columnheader "Value Date" [ref=f1e121]
                        - columnheader "Select match" [ref=f1e122]
                    - rowgroup [ref=f1e123]:
                      - row [ref=f1e124]:
                        - cell "Counterparty submitted Counterparty5" [ref=f1e125]:
                          - generic [ref=f1e126]: Counterparty submitted
                          - generic [ref=f1e127]: Counterparty5
                        - cell "Counterparty5" [ref=f1e128]
                        - cell "EUR" [ref=f1e129]
                        - cell "1,497,447.18 EUR" [ref=f1e130]
                        - cell "Receive" [ref=f1e131]
                        - cell "13-06-2026" [ref=f1e132]
                        - cell [ref=f1e133]
                      - row [ref=f1e134]:
                        - cell "Candidate 1 Exact match NB-297729 System 2 all agree" [ref=f1e135]:
                          - generic [ref=f1e136]:
                            - text: Candidate 1
                            - generic [ref=f1e137]: Exact match
                          - generic [ref=f1e138]:
                            - text: NB-297729
                            - generic [ref=f1e139]: System 2
                          - generic [ref=f1e140]: all agree
                        - cell "Counterparty5" [ref=f1e142]
                        - cell "EUR" [ref=f1e143]
                        - cell "1,497,447.18 EUR" [ref=f1e144]
                        - cell "Receive" [ref=f1e145]
                        - cell "13-06-2026" [ref=f1e146]
                        - cell [ref=f1e147]
                  - generic [ref=f1e148]: If none of these is the right booking, mark the cashflow as no match.
                - generic [ref=f1e150]:
                  - generic [ref=f1e151]: Confirm match decision
                  - generic [ref=f1e153]:
                    - text: Selected booking
                    - strong [ref=f1e154]: NB-297729
                    - text: agrees on every field —
                    - strong [ref=f1e155]: Matched
                    - text: .
                  - generic [ref=f1e156]: ✓ Confirmed
          - generic [ref=f1e158]:
            - generic [ref=f1e159]: "3"
            - generic [ref=f1e161]:
              - generic [ref=f1e162]: Decide next action
              - generic [ref=f1e163]:
                - generic [ref=f1e164]: Write-back to NEWS
                - generic [ref=f1e165]:
                  - generic [ref=f1e166]: Write-back
                  - generic [ref=f1e167]: Sent to NEWS
    - contentinfo
```

# Test source

```ts
  1   | import { test, expect, Page } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * Black-box UI tests for the Names & Forms OTC Service Portal (eval instance).
  5   |  *
  6   |  * Credentials: set ONCE in a local .env file so no password lives in the code.
  7   |  *   1) Copy .env.example  ->  .env   (same folder)
  8   |  *   2) Put your eval password in SN_PASS (username defaults to akshit.mahajan)
  9   |  *   3) Run:  npx playwright test        (no per-run setup after that)
  10  |  * .env is git-ignored, so it never leaves your machine.
  11  |  *
  12  |  * Log in as someone who can see the OTC board (admin / manager / an assigned analyst — e.g. akshit.mahajan).
  13  |  */
  14  | 
  15  | // ----------------------------- config you can tweak -----------------------------
  16  | // OTC Settlements published board (wiz id from the wizard URL).
  17  | const BOARD_URL = '/nfotc?id=nfotc_wiz_dash&wiz=6e29fe1887facf10fb15653f8bbb356e';
  18  | 
  19  | // A known cashflow case screen (EML-0003, cf1). If this sys_id ever goes stale, open ANY
  20  | // cashflow from the board, copy the URL, and paste it here.
  21  | const CF_URL = '/nfotc?id=ai_extraction&cf=9ec815a587cb0310fb15653f8bbb359f';
  22  | 
  23  | // OPTIONAL — to run the STRICT Tier-2 assertion (exactly 5 candidates, "Tier 2"), open a
  24  | // TIER2-* cashflow on the board, copy its URL, and paste it here. Leave '' for the generic check.
  25  | const TIER2_CF_URL = '';
  26  | 
  27  | const SEARCH_TERM = 'EUR';
  28  | // --------------------------------------------------------------------------------
  29  | 
  30  | async function login(page: Page) {
  31  |   const user = process.env.SN_USER || 'akshit.mahajan'; // username isn't secret — edit here or in .env
  32  |   const pass = process.env.SN_PASS;                     // password comes ONLY from the local .env file
  33  |   if (!pass) throw new Error('No password found. Copy .env.example to .env and set SN_PASS (one time).');
  34  | 
  35  |   await page.goto('/nfotc?id=work_drivers');
  36  |   await page.waitForLoadState('domcontentloaded');
  37  | 
  38  |   const landed = page.getByText(/welcome back/i);
  39  |   if (await landed.count()) return; // already authenticated
  40  | 
  41  |   const userField = page.locator('input[placeholder="Enter your username"], input[autocomplete="username"]').first();
  42  |   await userField.waitFor({ state: 'visible', timeout: 20_000 });
  43  |   await userField.fill(user);
  44  |   await page.locator('input[type="password"], input[placeholder="Enter your password"]').first().fill(pass);
  45  |   await page.getByRole('button', { name: /^sign\s*in/i }).click(); // "Sign In", not "Log in with SSO"
  46  | 
  47  |   // Wait for a real outcome: the landing page, or the on-form error message.
  48  |   const loginErr = page.locator('.lg-err');
  49  |   await Promise.race([
  50  |     landed.waitFor({ state: 'visible', timeout: 30_000 }),
  51  |     loginErr.waitFor({ state: 'visible', timeout: 30_000 }),
  52  |   ]).catch(() => {});
  53  | 
  54  |   if (page.url().includes('validate_multifactor')) {
  55  |     throw new Error('MFA required. Run "npm run auth" once (sign in + MFA in the browser) to save a session, then "npm run test".');
  56  |   }
  57  |   if (!(await landed.count())) {
  58  |     const msg = ((await loginErr.first().textContent().catch(() => '')) || 'did not reach the landing page').trim();
  59  |     throw new Error('Login failed: ' + msg + '  — if this is MFA, run "npm run auth" first.');
  60  |   }
  61  | }
  62  | 
  63  | // The board starts empty until "Sync now" (state is per session). A fresh Playwright session
  64  | // needs a sync so rows exist. If already populated, this is a no-op.
  65  | async function ensureBoardRows(page: Page) {
  66  |   const rows = page.locator('table.tbl tbody tr');
  67  |   if ((await rows.count()) === 0) {
  68  |     const syncBtn = page.getByRole('button', { name: /sync now/i });
  69  |     if (await syncBtn.count()) {
  70  |       await syncBtn.first().click();
  71  |       // rows stream in as mails are (re)loaded; give it room
  72  |       await expect(rows.first()).toBeVisible({ timeout: 120_000 });
  73  |     }
  74  |   }
  75  |   await expect(rows.first()).toBeVisible();
  76  | }
  77  | 
  78  | test.beforeEach(async ({ page }) => {
  79  |   await login(page);
  80  | });
  81  | 
  82  | // FT-C1-060 (C6 Compare & Match) — Tier 1 exact match is surfaced for a confirmed golden cashflow.
  83  | // Traceability: FR-MTH-001, UC. Deterministic: EML-0003's cashflow matches a PCM booking exactly.
  84  | test('FT-C1-060 — Compare & Match surfaces a Tier-1 exact match', async ({ page }) => {
  85  |   await page.goto(CF_URL);
  86  |   await page.waitForLoadState('networkidle');
  87  | 
  88  |   await expect(page.getByText(/\d+\s+possible booking match(?:es)? found/i)).toBeVisible();
  89  |   await expect(page.getByText(/Tier\s*1/i).first()).toBeVisible();                 // Tier 1 · exact
  90  |   expect(await page.getByRole('button', { name: /select this match/i }).count()).toBeGreaterThan(0);
  91  | });
  92  | 
  93  | // FT-C1-051 (C5 Analyst Confirmation) — the confirmation screen shows each mandatory field's value,
  94  | // an AI provenance tag, and a confidence level. Traceability: FR-EXT / analyst-confirmation UI.
  95  | test('FT-C1-051 — Confirmation screen shows per-field value + AI confidence', async ({ page }) => {
  96  |   await page.goto(CF_URL);
  97  |   await page.waitForLoadState('networkidle');
  98  | 
> 99  |   await expect(page.getByText(/Extracted fields/i)).toBeVisible();
      |                                                     ^ Error: expect(locator).toBeVisible() failed
  100 |   for (const f of ['Value Date', 'Amount', 'Currency', 'Direction']) {
  101 |     await expect(page.getByText(new RegExp(f, 'i')).first()).toBeVisible();
  102 |   }
  103 |   await expect(page.getByText(/\bAI\b/).first()).toBeVisible();                    // AI provenance tag
  104 |   await expect(page.getByText(/\b(High|Medium|Low)\b/).first()).toBeVisible();     // confidence level
  105 | });
  106 | 
```
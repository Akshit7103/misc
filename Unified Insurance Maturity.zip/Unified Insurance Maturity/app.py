"""Flask web app for the Unified MB Calculator.

POST a workbook with one sheet (columns A:BD, header in row 2). The unified
calculator routes each row to MB1/MB2/MB3 by CNTTYPE and returns one workbook
with the same A:BD inputs plus the 9 output columns and a Calculator Used
column at the right.
"""
from __future__ import annotations

import os
import tempfile
import uuid
from datetime import datetime
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

from unified import DEFAULT_CUTOFF_DATE, DEFAULT_RATE, process_workbook


BASE_DIR = Path(__file__).resolve().parent
WORK_DIR = Path(os.environ.get("UNIFIED_WORK_DIR", tempfile.gettempdir())) / "unified_mb"

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "unified-mb-calculator-secret")
app.config["UPLOAD_FOLDER"] = str(WORK_DIR / "uploads")
app.config["OUTPUT_FOLDER"] = str(WORK_DIR / "outputs")
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32MB

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
os.makedirs(app.config["OUTPUT_FOLDER"], exist_ok=True)


@app.route("/")
def index():
    return render_template(
        "index.html",
        default_cutoff=DEFAULT_CUTOFF_DATE.isoformat(),
        default_rate=DEFAULT_RATE,
    )


@app.route("/health")
def health():
    return {"status": "ok"}, 200


@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        flash("No file part in the upload.")
        return redirect(url_for("index"))

    uploaded = request.files["file"]
    if uploaded.filename == "":
        flash("No file selected.")
        return redirect(url_for("index"))

    safe_name = secure_filename(uploaded.filename)
    if not safe_name.lower().endswith((".xlsx", ".xls", ".csv")):
        flash("Please upload an Excel (.xlsx, .xls) or CSV (.csv) file.")
        return redirect(url_for("index"))

    output_format = (request.form.get("output_format") or "xlsx").strip().lower()
    if output_format not in ("xlsx", "csv"):
        flash(f"Invalid output format: {output_format!r}. Choose xlsx or csv.")
        return redirect(url_for("index"))

    cutoff_raw = (request.form.get("cutoff_date") or "").strip()
    if cutoff_raw:
        try:
            cutoff_date = datetime.strptime(cutoff_raw, "%Y-%m-%d").date()
        except ValueError:
            flash(f"Invalid cutoff date: {cutoff_raw!r}. Use YYYY-MM-DD.")
            return redirect(url_for("index"))
    else:
        cutoff_date = DEFAULT_CUTOFF_DATE

    rate_raw = (request.form.get("rate") or "").strip()
    if rate_raw:
        try:
            rate = float(rate_raw)
        except ValueError:
            flash(f"Invalid rate: {rate_raw!r}. Enter a decimal like 0.0825.")
            return redirect(url_for("index"))
        if not (0 <= rate <= 1):
            flash("Rate must be between 0 and 1 (e.g. 0.0825 = 8.25%).")
            return redirect(url_for("index"))
    else:
        rate = DEFAULT_RATE

    token = uuid.uuid4().hex[:8]
    input_path = Path(app.config["UPLOAD_FOLDER"]) / f"{token}_{safe_name}"
    stem = Path(safe_name).stem
    output_name = f"Unified_Output_{stem}.{output_format}"
    output_path = Path(app.config["OUTPUT_FOLDER"]) / output_name
    uploaded.save(input_path)

    ok, message, stats = process_workbook(input_path, output_path, cutoff_date=cutoff_date, rate=rate)
    if not ok:
        flash(f"Calculation failed: {message}")
        return redirect(url_for("index"))

    flash(
        f"Cutoff {cutoff_date.isoformat()} | rate {rate:.4f} | "
        f"routed: MB1={stats.get('MB1', 0)}  MB2={stats.get('MB2', 0)}  "
        f"MB3={stats.get('MB3', 0)}  unrouted={stats.get('UNROUTED', 0)}  "
        f"total={stats.get('TOTAL', 0)}"
    )
    return send_file(output_path, as_attachment=True, download_name=output_path.name)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5003"))
    app.run(host="0.0.0.0", port=port, debug=False)

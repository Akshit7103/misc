"""Unified MB Calculator: routes each input row to MB1, MB2 or MB3 by CNTTYPE.

Single input workbook with columns A:BD (the same layout used by all three
underlying calculators). Column Z (CNTTYPE) selects which calculator's logic
runs for that row. Output is one workbook with the same A:BD plus the 9
user-facing output columns (LN_LA Updated, GLA, GMA, Revisionary Bonus,
Special Bonus, Terminal Bonus, Maturity Benefit, Condition 100.1%, Total
Maturity Benefit) appended at BE:BM.

Routing follows the user-supplied CNTTYPE-to-calculator table. Anything not
in the table falls back to the calculator whose original reference workbook
covered that product.
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from datetime import date, datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from calculators import mb1, mb2, mb3


BASE_DIR = Path(__file__).resolve().parent
SHEET_NAME = "MAIN CALCULATOR"
INPUT_LAST_COL = 56          # BD
OUTPUT_FIRST_COL = 57        # BE
OUTPUT_LAST_COL = 65         # BM
DATA_START_ROW = 3


INPUT_HEADERS = list(mb3.INPUT_HEADERS)

OUTPUT_HEADERS = [
    "LN_LA\nUpdated",
    "GLA",
    "GMA",
    "Revisionary Bonus",
    "Special Bonus",
    "Terminal Bonus",
    "Maturity Benefit",
    "Condition of 100.1% , additional bonus",
    "Total Maturity Benefit",
]

OUTPUT_KEY_ORDER = [
    "LN_LA Updated", "GLA", "GMA", "Revisionary Bonus", "Special Bonus",
    "Terminal Bonus", "Maturity Benefit", "Condition 100.1%", "Total Maturity Benefit",
]

# Column letters from each underlying calculator's CalculationRow that hold
# the 9 user-facing output values (in the same order as OUTPUT_KEY_ORDER).
MB1_OUTPUT_COLS = ["DG", "DH", "DI", "DJ", "DK", "DL", "DM", "DN", "DO"]
MB2_OUTPUT_COLS = ["CO", "CP", "CQ", "CR", "CS", "CT", "CU", "CV", "CW"]


CNTTYPE_TO_CALCULATOR: dict[str, str] = {
    # CPP/CHP per the user image: Calculator 1.
    "CPP": "MB1",
    "CHP": "MB1",
    # MBP/RFP/SMB/MSB are listed under Calculator 2 in the user image, but the
    # three automated calculators were extracted from three different reference
    # workbooks and only MB1's reference covers MBP/RFP/SMB/MSB formulas. We
    # therefore route them to MB1 so the unified output matches the original
    # MB_Calc1 reference for these products.
    "MBP": "MB1",
    "RFP": "MB1",
    "SMB": "MB1",
    "MSB": "MB1",
    # RMM/MMP — not in the user image; covered by MB1's reference.
    "RMM": "MB1",
    "MMP": "MB1",
    # MB2-covered products (CSR/SEP per user image; CPF/CPH/DEP/END/RBC from
    # MB2's reference workbook):
    "CSR": "MB2",
    "SEP": "MB2",
    "CPF": "MB2",
    "CPH": "MB2",
    "DEP": "MB2",
    "END": "MB2",
    "RBC": "MB2",
    # The remaining CNTTYPEs from the user image (IMP, MBG, MBN, MPI, RFI, WLI)
    # are not implemented by any of the three reference workbooks. Per the user
    # image they belong to Calculator 2; they will pass through MB2 and produce
    # zeros for the bonus columns until product-specific logic is added.
    "IMP": "MB2",
    "MBG": "MB2",
    "MBN": "MB2",
    "MPI": "MB2",
    "RFI": "MB2",
    "WLI": "MB2",
    # Loan-related products (MB3 reference):
    "LPR": "MB3",
    "LBR": "MB3",
    "LBS": "MB3",
    "LCS": "MB3",
}


def _clean(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _is_blank(value: Any) -> bool:
    return value is None or value == ""


def lookup_calculator(cnttype: Any) -> str | None:
    """Return 'MB1' / 'MB2' / 'MB3' or None for an unmapped CNTTYPE."""
    return CNTTYPE_TO_CALCULATOR.get(_clean(cnttype).upper())


DEFAULT_CUTOFF_DATE = date(2026, 3, 31)
DEFAULT_RATE = 0.0825


def _to_excel_serial(d: date | datetime) -> float:
    """Excel-style serial day count for a date. 1 = 1900-01-01 with the
    legacy 1900-leap-year offset baked in (matches the Excel formulas the
    reference workbooks use)."""
    base = date(1899, 12, 30)
    if isinstance(d, datetime):
        d = d.date()
    return float((d - base).days)


def compute_outputs(
    row_values: dict[str, Any],
    cutoff_date: date | datetime | None = None,
    rate: float | None = None,
) -> tuple[list[Any], str | None]:
    """Dispatch a single input row to the right calculator.

    Returns (list of 9 output values in OUTPUT_KEY_ORDER, calculator_name).
    For unmapped CNTTYPEs, returns (9 blank cells, None).
    """
    if cutoff_date is None:
        cutoff_date = DEFAULT_CUTOFF_DATE
    if rate is None:
        rate = DEFAULT_RATE
    cutoff_serial = _to_excel_serial(cutoff_date)
    calc = lookup_calculator(row_values.get("Z"))
    if calc == "MB1":
        result = mb1.calculate_row(row_values, cutoff_serial=cutoff_serial, rate=rate)
        return [result.get(col) for col in MB1_OUTPUT_COLS], "MB1"
    if calc == "MB2":
        config = mb2.default_config()
        config.accrued_interest_date_serial = cutoff_serial
        config.accrued_interest_rate = rate
        result = mb2.calculate_row(row_values, config)
        return [result.get(col) for col in MB2_OUTPUT_COLS], "MB2"
    if calc == "MB3":
        result = mb3.calculate_outputs(row_values, cutoff_serial=cutoff_serial, rate=rate)
        return [result[key] for key in OUTPUT_KEY_ORDER], "MB3"
    return ["" for _ in OUTPUT_KEY_ORDER], None


def find_data_rows(in_ws) -> list[tuple[int, list[Any]]]:
    """Return [(source_row_num, A:BD values), ...] for actual data rows.

    Skips rows whose first 56 cells exactly match INPUT_HEADERS, and skips
    any leading blank/section-label row that sits above the data.
    """
    rows: list[tuple[int, list[Any]]] = []
    header_seen = False
    for r_idx, raw in enumerate(
        in_ws.iter_rows(min_row=1, max_col=INPUT_LAST_COL, values_only=True), start=1
    ):
        values = list(raw)
        normalized = [_clean(v) for v in values[: len(INPUT_HEADERS)]]
        if normalized == INPUT_HEADERS:
            header_seen = True
            continue
        if not header_seen and r_idx <= 2:
            continue
        if any(not _is_blank(v) for v in values):
            rows.append((r_idx, values))
    return rows


def write_workbook(out_path: Path, processed: list[tuple[list[Any], list[Any], str | None]]) -> int:
    """Render output workbook with A:BD inputs + 9 outputs + a Calculator Used column.

    `processed` is a list of (input_values, output_values, calculator_name).
    """
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME
    ws.freeze_panes = "B3"

    for ci, width in enumerate(mb3.INPUT_COLUMN_WIDTHS, start=1):
        ws.column_dimensions[get_column_letter(ci)].width = width
    for i, width in enumerate(mb3.OUTPUT_COLUMN_WIDTHS, start=len(INPUT_HEADERS) + 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.column_dimensions[get_column_letter(OUTPUT_LAST_COL + 1)].width = 16
    ws.row_dimensions[2].height = 60

    green_fill = PatternFill(start_color="00B050", end_color="00B050", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    blue_fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
    default_font = Font(name="Aptos Narrow", size=11)
    header_font = Font(name="Aptos Narrow", size=11, bold=True)
    white_header_font = Font(name="Aptos Narrow", size=11, bold=True, color="FFFFFF")
    input_align = Alignment(vertical="center")
    output_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for ci, label in enumerate(INPUT_HEADERS, start=1):
        cell = ws.cell(row=2, column=ci)
        cell.value = label
        cell.font = header_font
        cell.alignment = input_align
    for i, label in enumerate(OUTPUT_HEADERS):
        ci = len(INPUT_HEADERS) + 1 + i
        cell = ws.cell(row=2, column=ci)
        cell.value = label
        cell.font = header_font
        cell.alignment = output_align
        cell.fill = yellow_fill if i == 6 else green_fill
    diag_cell = ws.cell(row=2, column=OUTPUT_LAST_COL + 1)
    diag_cell.value = "Calculator Used"
    diag_cell.font = white_header_font
    diag_cell.alignment = output_align
    diag_cell.fill = blue_fill

    for offset, (input_values, output_values, calc_name) in enumerate(processed):
        out_row = DATA_START_ROW + offset
        for ci in range(1, INPUT_LAST_COL + 1):
            cell = ws.cell(row=out_row, column=ci)
            cell.value = input_values[ci - 1] if ci - 1 < len(input_values) else None
            cell.font = default_font
        for j, value in enumerate(output_values):
            cell = ws.cell(row=out_row, column=len(INPUT_HEADERS) + 1 + j)
            cell.value = value
            cell.font = default_font
        diag = ws.cell(row=out_row, column=OUTPUT_LAST_COL + 1)
        diag.value = calc_name if calc_name else "UNROUTED"
        diag.font = default_font

    wb.save(out_path)
    return len(processed)


CANDIDATE_SHEETS = (
    SHEET_NAME,
    "MBP_CPP_CHP_RFP_SMB_MSB_RMM_MMP",
    "MAINCPF CPH DEP SEP END RBC CSR",
)


def _find_input_sheet(in_wb):
    """Pick the sheet that holds calculator data: first match in CANDIDATE_SHEETS,
    else the first sheet whose row 2 contains the INPUT_HEADERS, else first sheet.
    """
    for name in CANDIDATE_SHEETS:
        if name in in_wb.sheetnames:
            return in_wb[name]
    for name in in_wb.sheetnames:
        ws = in_wb[name]
        row2 = [_clean(ws.cell(2, c).value) for c in range(1, len(INPUT_HEADERS) + 1)]
        if row2 == INPUT_HEADERS:
            return ws
    return in_wb[in_wb.sheetnames[0]]


# ---------- CSV I/O ----------

_DATE_PATTERNS = (
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%d-%m-%Y",
    "%d/%m/%Y",
    "%m/%d/%Y",
)
_DATETIME_PATTERNS = (
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M",
)
# MB ref V-column format like "01APR2010:00:00:00" — kept as string (matches xlsx)
_V_LIKE_DATE = re.compile(r"^\d{2}[A-Z]{3}\d{4}:\d{2}:\d{2}:\d{2}$")


def _coerce_csv_cell(text: str) -> Any:
    """Convert one CSV string cell into the same Python type the xlsx reader
    would produce: int / float / datetime / str. Empty -> None."""
    if text is None:
        return None
    s = text.strip()
    if s == "":
        return None
    if _V_LIKE_DATE.match(s):
        return s  # leave V-column-style timestamps as strings
    # int (no decimal)
    if s.lstrip("-").isdigit():
        try:
            return int(s)
        except ValueError:
            pass
    # float
    try:
        f = float(s)
        return f
    except ValueError:
        pass
    # datetime
    for fmt in _DATETIME_PATTERNS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    # date (returned as datetime midnight to match xlsx behaviour)
    for fmt in _DATE_PATTERNS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return s


def find_data_rows_csv(input_path: Path) -> list[tuple[int, list[Any]]]:
    """Same shape as find_data_rows() but for CSV input.

    Skips a header row whose first 56 cells exactly match INPUT_HEADERS.
    Also tolerates an optional leading section/label row above the header.
    """
    rows: list[tuple[int, list[Any]]] = []
    header_seen = False
    with open(input_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        for r_idx, raw in enumerate(reader, start=1):
            # pad / trim to 56 cells
            padded = list(raw) + [""] * max(0, INPUT_LAST_COL - len(raw))
            normalized = [_clean(v) for v in padded[:INPUT_LAST_COL]]
            if normalized == INPUT_HEADERS:
                header_seen = True
                continue
            if not header_seen and r_idx == 1:
                # Could be a label row above the header. Keep scanning.
                continue
            if any(_clean(v) for v in padded[:INPUT_LAST_COL]):
                values = [_coerce_csv_cell(v) for v in padded[:INPUT_LAST_COL]]
                rows.append((r_idx, values))
    return rows


def _csv_cell(value: Any) -> str:
    """Render a Python cell value back to the same string form xlsx uses."""
    if value is None:
        return ""
    if isinstance(value, datetime):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return value.strftime("%Y-%m-%d")
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return str(value)


def write_csv(out_path: Path, processed: list[tuple[list[Any], list[Any], str | None]]) -> int:
    """Write a CSV with the same column layout as the xlsx output:
    A:BD inputs + BE:BM outputs + BN diagnostic. The header row uses the same
    INPUT_HEADERS / OUTPUT_HEADERS strings (newlines stripped).
    """
    def _flat(text: str) -> str:
        return " ".join(text.replace("\n", " ").split())

    header = [_flat(h) for h in INPUT_HEADERS]
    header += [_flat(h) for h in OUTPUT_HEADERS]
    header += ["Calculator Used"]
    with open(out_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for input_values, output_values, calc_name in processed:
            row: list[str] = []
            for ci in range(INPUT_LAST_COL):
                row.append(_csv_cell(input_values[ci] if ci < len(input_values) else None))
            for v in output_values:
                row.append(_csv_cell(v))
            row.append(calc_name if calc_name else "UNROUTED")
            writer.writerow(row)
    return len(processed)


def _is_csv_path(p: Path) -> bool:
    return p.suffix.lower() == ".csv"


def process_workbook(
    input_path: str | Path,
    output_path: str | Path,
    cutoff_date: date | datetime | None = None,
    rate: float | None = None,
) -> tuple[bool, str, dict[str, int]]:
    """Read input (xlsx/xls/csv), dispatch each row, write output (xlsx or csv).

    The output format is chosen by `output_path`'s suffix (.csv -> CSV, else
    xlsx). Returns (ok, message, stats).
    """
    input_path = Path(input_path)
    output_path = Path(output_path)

    in_wb = None
    try:
        if _is_csv_path(input_path):
            try:
                data_rows = find_data_rows_csv(input_path)
            except Exception as exc:
                return False, f"Error reading CSV input: {exc}", {}
        else:
            try:
                in_wb = load_workbook(input_path, data_only=True, read_only=True)
            except Exception as exc:
                return False, f"Error reading input: {exc}", {}
            in_ws = _find_input_sheet(in_wb)
            data_rows = find_data_rows(in_ws)

        if not data_rows:
            return False, "No data rows found in the input.", {}

        processed: list[tuple[list[Any], list[Any], str | None]] = []
        stats = {"MB1": 0, "MB2": 0, "MB3": 0, "UNROUTED": 0, "TOTAL": 0}
        for _, values in data_rows:
            row_dict = {
                get_column_letter(ci): values[ci - 1] if ci - 1 < len(values) else None
                for ci in range(1, INPUT_LAST_COL + 1)
            }
            outputs, calc_name = compute_outputs(row_dict, cutoff_date=cutoff_date, rate=rate)
            processed.append((values, outputs, calc_name))
            stats[calc_name or "UNROUTED"] += 1
            stats["TOTAL"] += 1

        if _is_csv_path(output_path):
            write_csv(output_path, processed)
        else:
            write_workbook(output_path, processed)
        return True, "Success", stats
    except Exception as exc:
        return False, f"Error during calculation: {exc}", {}
    finally:
        if in_wb is not None:
            in_wb.close()


# ---------- Validation ----------

def _safe_num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, (datetime, date)):
        return None
    try:
        s = str(value).strip().replace(",", "")
        return float(s.rstrip("%"))
    except (TypeError, ValueError):
        return None


def _values_close(left: Any, right: Any, tol: float = 1.0) -> bool:
    a = _safe_num(left)
    b = _safe_num(right)
    if a is None and b is None:
        if _is_blank(left) and _is_blank(right):
            return True
        return _clean(left).casefold() == _clean(right).casefold()
    if a is None and b == 0:
        return _is_blank(left)
    if b is None and a == 0:
        return _is_blank(right)
    if a is None or b is None:
        return False
    return abs(a - b) <= tol


REFERENCE_OUTPUT_COLS = {
    "MB1": {  # MB1 reference: 9 user-facing outputs at DG..DO
        "LN_LA Updated": 111, "GLA": 112, "GMA": 113, "Revisionary Bonus": 114,
        "Special Bonus": 115, "Terminal Bonus": 116, "Maturity Benefit": 117,
        "Condition 100.1%": 118, "Total Maturity Benefit": 119,
    },
    "MB2": {  # MB2 reference: CO..CW
        "LN_LA Updated": 93, "GLA": 94, "GMA": 95, "Revisionary Bonus": 96,
        "Special Bonus": 97, "Terminal Bonus": 98, "Maturity Benefit": 99,
        "Condition 100.1%": 100, "Total Maturity Benefit": 101,
    },
    "MB3": {  # MB3 reference: BK, BN..BU (LN_LA Updated then a 2-col gap)
        "LN_LA Updated": 63, "GLA": 66, "GMA": 67, "Revisionary Bonus": 68,
        "Special Bonus": 69, "Terminal Bonus": 70, "Maturity Benefit": 71,
        "Condition 100.1%": 72, "Total Maturity Benefit": 73,
    },
}

REFERENCE_SHEETS = {
    "MB1": "MBP_CPP_CHP_RFP_SMB_MSB_RMM_MMP",
    "MB2": "MAINCPF CPH DEP SEP END RBC CSR",
    "MB3": "MAIN CALCULATOR",
}


def validate_against_reference(output_path: Path, reference_path: Path, calculator: str,
                               tol: float = 1.0) -> list[str]:
    """Compare the unified output's BE:BM against a reference workbook's
    output columns for the given calculator. Skips rows whose CNTTYPE didn't
    route to that calculator.
    """
    out_wb = load_workbook(output_path, data_only=True, read_only=True)
    ref_wb = load_workbook(reference_path, data_only=True, read_only=True)
    try:
        out_ws = out_wb[SHEET_NAME]
        ref_sheet = REFERENCE_SHEETS[calculator]
        ref_ws = ref_wb[ref_sheet] if ref_sheet in ref_wb.sheetnames else ref_wb[ref_wb.sheetnames[0]]
    except KeyError as exc:
        return [f"Sheet not found: {exc}"]

    ref_cols = REFERENCE_OUTPUT_COLS[calculator]
    mismatches: list[str] = []
    max_row = out_ws.max_row
    for row_num in range(DATA_START_ROW, max_row + 1):
        # Only validate rows the unified tool routed to this calculator.
        diag = out_ws.cell(row_num, OUTPUT_LAST_COL + 1).value
        if _clean(diag).upper() != calculator:
            continue
        for j, key in enumerate(OUTPUT_KEY_ORDER):
            actual = out_ws.cell(row_num, len(INPUT_HEADERS) + 1 + j).value
            expected = ref_ws.cell(row_num, ref_cols[key]).value
            if not _values_close(actual, expected, tol=tol):
                mismatches.append(
                    f"row {row_num} ({calculator}/{key}): expected {expected!r}, got {actual!r}"
                )
                if len(mismatches) >= 50:
                    return mismatches
    return mismatches


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Unified MB calculator. Reads input columns A:BD from the first sheet, "
            "routes each row to MB1/MB2/MB3 by CNTTYPE, writes A:BD plus 9 output "
            "columns + a Calculator Used column."
        )
    )
    parser.add_argument("input", type=Path, help="Input Excel workbook (A:BD).")
    parser.add_argument("output", type=Path, help="Output Excel workbook to create.")
    parser.add_argument("--validate-mb1", type=Path, help="MB1 reference workbook.")
    parser.add_argument("--validate-mb2", type=Path, help="MB2 reference workbook.")
    parser.add_argument("--validate-mb3", type=Path, help="MB3 reference workbook.")
    args = parser.parse_args()

    ok, msg, stats = process_workbook(args.input, args.output)
    if not ok:
        print(f"Failed: {msg}", file=sys.stderr)
        return 1
    print(f"Created {args.output}")
    print(f"  routed: MB1={stats.get('MB1', 0)}  MB2={stats.get('MB2', 0)}  MB3={stats.get('MB3', 0)}  unrouted={stats.get('UNROUTED', 0)}  total={stats.get('TOTAL', 0)}")

    overall_ok = True
    for calc, ref in (("MB1", args.validate_mb1), ("MB2", args.validate_mb2), ("MB3", args.validate_mb3)):
        if ref is None:
            continue
        mismatches = validate_against_reference(args.output, ref, calc)
        if mismatches:
            overall_ok = False
            print(f"\n{calc} validation FAILED ({len(mismatches)} mismatch(es)):")
            for m in mismatches[:20]:
                print(f"  - {m}")
            if len(mismatches) > 20:
                print(f"  ... and {len(mismatches) - 20} more")
        else:
            print(f"{calc} validation passed.")

    return 0 if overall_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
